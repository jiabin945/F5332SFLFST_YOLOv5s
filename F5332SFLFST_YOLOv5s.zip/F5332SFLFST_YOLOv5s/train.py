#--cfg acmix.yaml --acmix
# YOLOv5 🚀 by Ultralytics, GPL-3.0 license
#python命令（train）：--data data/VOC.yaml --cfg models/yolov5s.yaml --weights weights/yolov5s.pt --batch-size 16 --epochs 1

"""
    这个文件是yolov5的训练脚本。
    抓住 数据 + 模型 + 学习率 + 优化器 + 训练这五步即可。
    Train a YOLOv5 model on a custom dataset.

Models and datasets download automatically from the latest YOLOv5 release.
Models: https://github.com/ultralytics/yolov5/tree/master/models
Datasets: https://github.com/ultralytics/yolov5/tree/master/data
Tutorial: https://github.com/ultralytics/yolov5/wiki/Train-Custom-Data

Usage:两种
    1有预训练，第一行是在加载yolov5s的权重基础上进行训练，
    $ python path/to/train.py --data coco128.yaml --weights yolov5s.pt --img 640  # from pretrained (RECOMMENDED)
    2没有预训练，即没有yolov5s.pt，则需要给一个配置文件cfg yolov5s.yaml，即模型描述文件
    第二行是在配置yolov5s网络结构后，从零开始搭建一个模型，然后从头开始训练。
    $ python path/to/train.py --data coco128.yaml --weights '' --cfg yolov5s.yaml --img 640  # from scratch
"""
#-----------------------1导入所需要的库函数和包。基本配置定义ROOT-------------------------
import argparse
import math
import os
import random
import sys
import time
from copy import deepcopy
from datetime import datetime
from pathlib import Path

import numpy as np
import torch
import torch.distributed as dist
import torch.nn as nn
import yaml
from torch.cuda import amp  #利用这个混合精度amp训练，训练速度提高3-4倍
from torch.nn.parallel import DistributedDataParallel as DDP#单机单卡，多机多卡，但是没用到
from torch.optim import SGD, Adam, AdamW, lr_scheduler
from tqdm import tqdm #进度条显示

#将/home/lhcz/sdb/jiabin/jb_project/yolov5-6.1/train.py加入系统的环境变量  该脚本结束后失效
# __file__:指的是当前文件(即train.py)，.resolve():获取绝对路径：
# /home/lhcz/sdb/jiabin/jb_project/yolov5-6.1/train.py
#from models.common import BiFPN_Add2, BiFPN_Add3

FILE = Path(__file__).resolve()
#当前文件的父目录：/home/lhcz/sdb/jiabin/jb_project/yolov5-6.1
ROOT = FILE.parents[0]  # YOLOv5 root directory
#假如当前项目不在该路径中,就无法运行其中的模块,所以就需要加载路径
# sys.path是即当前python环境可以运行的路径，是一个列表list
#sys.path:其实是为了from models.yolo import Model、from utils.等，因为这些是作者自己写的
#所以把他们导入进来，需要告诉python解释器它具体路径在哪，即去sys.path中找，如果找到则顺利加载进来它，找不到就会报错
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))  # add ROOT to PATH
#相对路径
#这一部分的主要作用有两个:
#将当前项目添加到系统路径上,以使得项目中的模块可以调用.  2将当前项目的相对路径保存在ROOT中,便于寻找
# 项目中的文件
ROOT = Path(os.path.relpath(ROOT, Path.cwd()))  # relative

import val  # for end-of-epoch mAP
from models.experimental import attempt_load
from models.yolo import Model
from utils.autoanchor import check_anchors
from utils.autobatch import check_train_batch_size
from utils.callbacks import Callbacks
from utils.datasets import create_dataloader
from utils.downloads import attempt_download
from utils.general import (LOGGER, check_dataset, check_file, check_git_status, check_img_size, check_requirements,
                           check_suffix, check_yaml, colorstr, get_latest_run, increment_path, init_seeds,
                           intersect_dicts, labels_to_class_weights, labels_to_image_weights, methods, one_cycle,
                           print_args, print_mutation, strip_optimizer)
from utils.loggers import Loggers
from utils.loggers.wandb.wandb_utils import check_wandb_resume
from utils.loss import ComputeLoss
from utils.metrics import fitness
from utils.plots import plot_evolve, plot_labels
from utils.torch_utils import EarlyStopping, ModelEMA, de_parallel, select_device, torch_distributed_zero_first

#下面这三个参数主要用于分布式训练，对于我们初学者而言，一般都是默认参数。
#rank是指在整个分布式任务中进程的序号；local_rank是指在一个node（机器）上进程的相对序号
#在整个分布式中的序号，每个进程都有一个rank和一个local_rank，rank是相对整个分布式而言（就是序号从0开始一直到整个分布式中最后一个GPU的数，类似于range(0,整个分布式GPU数量），这里不是相对于一个node而言，是所有node的GPU总和），local_rank是每个进程或者GPU相对属于哪个node而言的编号。另外，rank=0代表主进程
#WORLD_SIZE：全局（一个分布式任务）中，rank（gpu）的数量。 world_size表示总共有n个进程  1
#即：单机单卡环境  local_rank=-1（这里是）或者0，即为主进程
LOCAL_RANK = int(os.getenv('LOCAL_RANK', -1))  # 这个 Worker 是这台机器上的第几个 Worker(进程编号)  LOCAL_RANK ：-1
RANK = int(os.getenv('RANK', -1))# 这个 Worker 是全局第几个 Worker（进程编号） RANK:-1
WORLD_SIZE = int(os.getenv('WORLD_SIZE', 1))# 总共有几个 Worker  WORLD_SIZE:1

#---------------------------------------5训练------------------------------------------
def train(hyp,  # path/to/hyp.yaml or hyp dictionary
          opt,
          device,
          callbacks
          ):
    # ----------------------------------------------- 5.1初始化参数和基本配置信息 ----------------------------------------------
    # 初始化pt参数 + 路径信息 +  保存opt、hyp + 加载数据配置信息 + 打印日志信息(logger + wandb) + 其他参数(plots、cuda、nc、names、is_coco)

    #将 opt传入的参数拿出来
    #save:runs/train/exp155
    save_dir, epochs, batch_size, weights, single_cls, evolve, data, cfg, resume, noval, nosave, workers, freeze = \
        Path(opt.save_dir), opt.epochs, opt.batch_size, opt.weights, opt.single_cls, opt.evolve, opt.data, opt.cfg, \
        opt.resume, opt.noval, opt.nosave, opt.workers, opt.freeze

    # 生成权重路径+创建此路径的文件夹+保存训练权重结果的目录
    w = save_dir / 'weights'  # weights dir  保存权重的路径 如runs/train/exp155/weights
    (w.parent if evolve else w).mkdir(parents=True, exist_ok=True)  # make dir
    last, best = w / 'last.pt', w / 'best.pt' #runs/train/exp155/weights/last.pt   runs/train/exp155/weights/best.pt

    # Hyperparameters超参数：加载超参信息+打印  # isinstance()是否是已知类型
    if isinstance(hyp, str):#执行，因为yaml是str形式
        #读取文件 - ----With Open，用with，则不用最后再加f.close()关闭文件了
        #open()函数还接收一个errors参数，errors=‘ignore’ 表示遇到编码错误的时候直接忽略
        with open(hyp, errors='ignore') as f:
            hyp = yaml.safe_load(f)  #  将超参yaml格式文件转换为python值-字典形式，即：{'gama': 0.001, 'sigma': 8.5}。因为dict keys 具备保留插入顺序的特性，所以通过 yaml.safe_load 得到的 dict，其 keys 顺序会与原始文件保持一致。


    # 日志输出超参信息 hyperparameters: ...打印出来，因为hyp.items()是字典形式，所以字典形式打印出来
    #例如：hyperparameters: lr0=0.01, lrf=0.01, momentum=0.937, weight_decay=0.0005, warmup_epochs=3.0, warmup_momentum=0.8
    LOGGER.info(colorstr('hyperparameters: ') + ', '.join(f'{k}={v}' for k, v in hyp.items()))

    #在save_dir / 'hyp.yaml'保存超参信息以及在save_dir / 'opt.yaml'保存配置信息，方便后期管理
    # 如果不使用进化训练(默认没有使用)
    if not evolve:
        #因为所有的模型训练参数以及配置文件加载完成，它会把hyp,opt保存到新创建的save_dir（即expx中） / 'hyp.yaml或者save_dir / 'opt.yaml中
        #方便管理
        # 把hyp.yaml文件另外保存到f,即：runs/train/expx/hyp.yaml中，这里hyp.yaml指的是data\hyps\hyp.scratch-low.yaml
        with open(save_dir / 'hyp.yaml', 'w') as f:  #w:表示可写
            yaml.safe_dump(hyp, f, sort_keys=False)  # safe_dump() python字典值转化为yaml序列化。当把 dict 导出为 YAML 字符串时，为 yaml.safe_dump 传递 sort_keys=False 来保留 keys 的顺序。
        # 把opt.yaml文件另外保存到runs/train/expx/opt.yaml中
        with open(save_dir / 'opt.yaml', 'w') as f:
            # vars(opt) 将参数中的每一个成员使用字典的形式进行返回，换句话说就是将对象转换成为一个字典对象，然后safe_dump将字典转换
            yaml.safe_dump(vars(opt), f, sort_keys=False)

    # Loggers
    #Loggers类的作用目前看好像是只是建立了一些方法(将传入的方法以键值对的形式保存下来)，之后把这些方法给callback
    #在Loggers类中管理，因为都在train中管理会显得臃肿
    data_dict = None
    #rank为进程编号, 如果设置为rank = -1并且有多块gpu，则使用DataParallel模式
    # rank=-1且gpu数量=1时,不会进行分布式,使用单机模式
    #local_rank=-1（这里是）或者0，即为主进程
    if RANK in [-1, 0]:
        #Loggers类的作用目前看好像是只是建立了一些方法(将传入的方法以键值对的形式保存下来)，之后把这些方法给callback，
        #保存，Loggers类-启动一个loggers，对一些函数进行管理，将save_dir, weights, opt, hyp, LOGGER保存下来
        #而不影响GPU训练性能  该log实际上是tensorboard。
        loggers = Loggers(save_dir, weights, opt, hyp, LOGGER)  # loggers instance
        #wandb全称Weights & Biases，用来帮助我们跟踪机器学习的项目，通过wandb可以记录模型训练过程中指标的变化情况以及超参的设置，还能够将输出的结果进行可视化的比对，帮助我们更好的分析模型在训练过程中的问题
        #wandb会将训练过程中的参数，上传到服务器上，然后通过登录wandb来进行实时过程模型训练过程中参数和指标的变化
        if loggers.wandb: #为none，则不执行
            data_dict = loggers.wandb.data_dict
            if resume:
                weights, epochs, hyp, batch_size = opt.weights, opt.epochs, opt.hyp, opt.batch_size

        # Register actions，注册操作，即把loggers中的符合条件的methods拿出来（条件在method中定义，即是一个可调用对象且不是以“__”下划线开始的，则会把它取出来），然后把这些方法在callback类中注册，后面就可以根据callback对此昂以及方法名字拿出这个方法
        #methods(loggers)，在gengeal.py中：#在loggers中的f方法如果是一个可调用对象且不是以“__”下划线开始的，则会把它取出来
        for k in methods(loggers):
            #callback=getattr(loggers, k)：从某个类对象loggers中获取k属性对应的值；getattr（x，‘y’）等价于x.y：把x中的y键对应的方法取出来
            #当给定默认参数时，当属性未指定时返回该参数；存在如果没有它，则会在这种情况下引发异常。

            #register_action：注册器机制的引入是为了使工程的扩展性变得更好。当产品增加某个功能需要增加一些新函数或者类时，它可以保证我们可以复用之前的逻辑
            #Register类似于一个dict（实际上是有一个_dict属性），可以set_item和get_item，即将想注册的东西以键值对形式注册进去，下次想用再拿出来
            callbacks.register_action(k, callback=getattr(loggers, k))

    # Config 画图
    plots = not evolve  # create plots #true
    # GPU / CPU
    cuda = device.type != 'cpu' #true
    init_seeds(1 + RANK) # 设置随机种子初始化
    # 加载数据配置信息
    # torch_distributed_zero_first函数的作用是只有主进程来加载数据,其他进程处于等待状态直到主进程加载完数据,
    with torch_distributed_zero_first(LOCAL_RANK):

        #查看数据有没有下载，如果没下载，则到数据对应的yaml文件去下载
        #准备数据集：data_dict包含数据集路径、种类个数、种类名字等等
        #注意：data默认是coco128.yaml，但是命令行优先，所以会执行命令行中的VOC。yaml
        data_dict = data_dict or check_dataset(data)  # check if None
    # 获取训练集（train\val）、测试集图片路径(test)
    train_path, val_path = data_dict['train'], data_dict['val']
    # nc: number of classes  数据集有多少种类别
    nc = 1 if single_cls else int(data_dict['nc'])  # number of classes

    # names: 数据集所有类别的名字
    names = ['item'] if single_cls and len(data_dict['names']) != 1 else data_dict['names']  # class names
    #判断类别长度和文件是否对应
    assert len(names) == nc, f'{len(names)} names found for nc={nc} dataset in {data}'  # check
    # 当前数据集是否是coco数据集(80个类别)
    is_coco = isinstance(val_path, str) and val_path.endswith('coco/val2017.txt')  # COCO dataset

    #model
    # ==============5.2. train函数——模型加载/断点训练 =================================================
    # 载入模型(预训练/不预训练) + 检查数据集 + 设置数据集路径参数(train_path、test_path) + 冻结权重层
    # 检查weight的后缀是否为.pt
    check_suffix(weights, '.pt')  # check weights
    # 加载预训练权重 yolov5提供了5个不同的预训练权重，大家可以根据自己的模型选择预训练权重
    pretrained = weights.endswith('.pt')
    #如果weight在本地（在服务器上执行则在服务器上的本地），则用预训练权重
    if pretrained:
        # torch_distributed_zero_first函数的作用是只有主进程来加载数据,其他进程处于等待状态直到主进程加载完数据,
        with torch_distributed_zero_first(LOCAL_RANK):
            # 如果本地不存在就从网站上下载  weights：'weights/yolov5s.pt'
            # 这里下载是去google云盘下载, 一般会下载失败,所以建议自行去github中下载再放到weights下
            weights = attempt_download(weights)  # download if not found locally
        # 加载模型以及参数（加载权重给ckpt）
        ckpt = torch.load(weights, map_location='cpu')  # load checkpoint to CPU to avoid CUDA memory leak
        """
                两种加载模型的方式: opt.cfg / ckpt['model'].yaml（即权重中的'model'.yaml,即模型配置文件）
                使用resume-断点训练:  opt.cfg设为空，选择ckpt['model']yaml创建模型,# 这也影响了下面是否除去anchor的key(也就是不加载anchor)
                使用断点训练时,保存的模型会保存anchor,所以不需要加载
                """
        # 原因: 保存的模型会保存anchors，有时候用户自定义了anchor之后，再resume，则原来基于coco数据集的anchor会自己覆盖自己设定的anchor
        # 详情参考: https://github.com/ultralytics/yolov5/issues/459
        # 所以下面设置intersect_dicts()就是忽略exclude
        #这里若给cfg则根据cfg加载yaml,没有则根据ckpt加载yaml，即构造模型-
        model = Model(cfg or ckpt['model'].yaml, ch=3, nc=nc, anchors=hyp.get('anchors')).to(device)  # create
        exclude = ['anchor'] if (cfg or hyp.get('anchors')) and not resume else []  # exclude keys
        #state_dict():返回一个包含module的所有state的dictionary
        #csd：把ckpt中预训练模型的state_dict()取出来，即模型结构
        csd = ckpt['model'].float().state_dict()  # checkpoint state_dict as FP32
        # 把csd,与model.state_dict()二者做一个对比，intersect_dicts即二者相同的部分取出来，
        # 筛选字典中的键值对  把exclude删除，因为断点续训时候，自定义anchor在加载预训练权重时会被冲洗掉
        #原来的默认coco数据集anchor会覆盖现在的anchor,所以要将exclude中的删除
        csd = intersect_dicts(csd, model.state_dict(), exclude=exclude)  # intersect

        #是将加载出来的数据csd（预训练模型与想要得到的模型相同的部分）加载到state_dic中
        #相同的取出来后加载到load_state_dict中去（因为预训练模型与想要得到的模型并不完全一致，比如只有backbone一致
        # 改了的部分用预训练权重加载会加载不进来，这里把相同的部分找出来，不同的部分就不用加载了）
        model.load_state_dict(csd, strict=False)  # load
        #例如：Transferred 342/349 items from weights/yolov5s.pt
        LOGGER.info(f'Transferred {len(csd)}/{len(model.state_dict())} items from {weights}')  # report
    else:  # 不使用预训练,建立模型
        model = Model(cfg, ch=3, nc=nc, anchors=hyp.get('anchors')).to(device)  # create

#----------------------------5.3 train函数——冻结训练/冻结层设置---------------------------
    #很多时候会用一个预训练模型，在自己数据集上进行迁移学习，就想把某些层冻结住（这里没有执行）
    # 冻结训练的网络层  冻结权重层
    # 这里只是给了冻结权重层的一个例子, 但是作者并不建议冻结权重层, 训练全部层参数, 可以得到更好的性能, 当然也会更慢
    #这里len(freeze)为0，则range(freeze[0]),即0,即freeze=[]
    freeze = [f'model.{x}.' for x in (freeze if len(freeze) > 1 else range(freeze[0]))]  # layers to freeze
    #k:'model.0.conv.weight'  v:一系列值 torch.Size([32, 3, 6, 6])
    for k, v in model.named_parameters():
        v.requires_grad = True  # train all layers
        #x层（freeze层）的字符的一部分在k中则把它对应的值v.requires_grad = False
        #freeze层若是k字符的一部分，则v.requires_grad = False。相当于冻结住，梯度回传时不会用梯度把它更新到对应层的权重当中，达到冻结目的
        if any(x in k for x in freeze):
            LOGGER.info(f'freezing {k}')
            # 冻结训练的层梯度不更新
            v.requires_grad = False

#-----------------------------5.4 train函数——图片大小/batchsize设置--------------------------
    # Image size
    # gs: 获取模型最大stride=32   另外[32 16 8]（stride是三个下采样的倍数）
    gs = max(int(model.stride.max()), 32)  # grid size (max stride)
    # 检查opt.imgsz是否能被gs（32）整除  imgsz：640
    imgsz = check_img_size(opt.imgsz, gs, floor=gs * 2)  # verify imgsz is gs-multiple

    # Batch size（自己设定好大小就不会进入）
    #RANK == -1：单gpu；如果没有自己设定bat，则会根据显卡等相关属性自行设置bat大小
    if RANK == -1 and batch_size == -1:  # single-GPU only, estimate best batch size
        batch_size = check_train_batch_size(model, imgsz)
        loggers.on_params_update({"batch_size": batch_size})

#--------------------------------------5.5 train函数——优化器选择 / 分组优化设置
    # Optimizer
    # 参数设置(nbs、accumulate、hyp[‘weight_decay’]) + 分组优化w,b(g0、g1、g2) + 选择优化器 + 为三个优化器选择优化方式 + 打印参数

    # nbs 标称的batch_size,模拟的batch_size，当自己设定的bat=16,实际是不更新的，但是如果累计到nbs(64),才会更新更新一次模型
    # 也就是模型梯度累计 64/16=4(accumulate) 次之后就更新一次模型，bs=16不进行更新 等于变相的扩大了batch_size，目的是让权重更能稳定更新
    nbs = 64  # nominal batch size
    # 假设batch_size为16，则意思是迭代64/16=4次batch以后才更新一组参数：变相的增加batch_size，相当于迭代了64个才更新一次参数的更新。
    accumulate = max(round(nbs / batch_size), 1)  # accumulate loss before optimizing
    # 根据accumulate设置超参: 权重衰减参数
    hyp['weight_decay'] *= batch_size * accumulate / nbs  # scale weight_decay
    #就是为了显示此时的weight_decay是多少
    LOGGER.info(f"Scaled weight_decay = {hyp['weight_decay']}")

    # 将模型参数分为三组(weights、biases、bn)来进行分组优化
    #g0存放weight(bn中的，即没有权重衰减的weight)。g1存放weight（比如卷积中的，有权重衰减的）。g2存放bias(bn中的，因为卷积没有bias)
    g0, g1, g2 = [], [], []  # optimizer parameter groups
    #每次循环看小括号。刚开始v是最外层Model，不会匹配到下面三条件，因为没有bias BatchNorm2d 'weight'
    # 二循环是得到Sequential这一层，同上没有三个东西
    # 三循环是Conv（即cbs）,,,,也没有那三个
    # 四循环到Conv2d（真正卷积），因为后面用了bn,所以所有Conv2d中bias都置为false，即没有bias，不是bn(因为这里是Conv2d
    # 卷积层),有weight且是parameter类型的会进入第三个if，会把此weight加入到g1
    #五循环到bn，有bn,有weight,bias
    #六到silu层，因为没有参数，所以不会进入下面三个if中
    #注：问：那为什么跟了BN就不用加bias了呢？  答：因为BN的公式求解过程中会将bias抵消掉，而且BN本身x*γ+β 这里β可以等价bias了。
    #总：会把卷积层对应的weight放入到g1，把bn层的weight，bias分别放入到g0,g2
    for v in model.modules():
        #hasattr(v, 'bias') :modules类实例对象v是否包含指定名称的bias。
        #isinstance:判断v.bias是否是nn.Parameter类型
        if hasattr(v, 'bias') and isinstance(v.bias, nn.Parameter):  # bias
            g2.append(v.bias)
        if isinstance(v, nn.BatchNorm2d):  # weight (no decay)
            g0.append(v.weight)
        elif hasattr(v, 'weight') and isinstance(v.weight, nn.Parameter):  # weight (with decay)
            g1.append(v.weight)
        # BiFPN_Concat
        # elif isinstance(v, BiFPN_Add2) and hasattr(v, 'w') and isinstance(v.w, nn.Parameter):
        #     g1.append(v.w)
        # elif isinstance(v, BiFPN_Add3) and hasattr(v, 'w') and isinstance(v.w, nn.Parameter):
        #     g1.append(v.w)

    # 选择优化器 并设置g0(bn中的weight参数)的优化方式 默认sgd，
    if opt.optimizer == 'Adam':
        optimizer = Adam(g0, lr=hyp['lr0'], betas=(hyp['momentum'], 0.999))  # adjust beta1 to momentum
    elif opt.optimizer == 'AdamW':
        optimizer = AdamW(g0, lr=hyp['lr0'], betas=(hyp['momentum'], 0.999))  # adjust beta1 to momentum
    else:
        #g0表示把bn中的weight（没有衰减的）放入进来了，同时告诉它的初始lr以及momentum,还有g1,g2没有加入进来是在下面加进来的
        optimizer = SGD(g0, lr=hyp['lr0'], momentum=hyp['momentum'], nesterov=True)

    #只卷积层的weight加weight_decay进行权重衰减，防止过拟合。而bn层的w与b都不加weight_decay
    optimizer.add_param_group({'params': g1, 'weight_decay': hyp['weight_decay']})  # add g1 with weight_decay
    optimizer.add_param_group({'params': g2})  # add g2 (biases)
    #例如：SGD with parameter groups 57 weight (no decay), 60 weight, 60 bias
    LOGGER.info(f"{colorstr('optimizer:')} {type(optimizer).__name__} with parameter groups "
                f"{len(g0)} weight (no decay), {len(g1)} weight, {len(g2)} bias")
    del g0, g1, g2

#-----------------5.66 train函数——学习率/ema/归一化/单机多卡----------------------

    #1学习率： 线性学习率 + one cycle学习率 + 实例化 scheduler ++ 画出学习率变化曲线

# lr调节器（lr_scheduler）：调整学习率。举例：让lr在第40个epoch进行衰减，新学习率=上一个学习率*衰减系数gamma
#scheduler = lr_scheduler.MultiStepLR(optimizer, milestones=[40], gamma=0.1)
    # 创建动态权重优化的调度器/把group1和group2添加到优化器中
    # Scheduler（对lr的设置）
    # 是否余弦学习率调整方式
    if opt.cos_lr:
        # 使用one cycle（cosine步长衰减） 学习率  https://arxiv.org/pdf/1803.09820.pdf
        #根据hyp['lrf']与 epochs，返回一个lf(lambda function)，one_cycle算出来的lr是余弦似的逐渐减小的
        #即达到一定epoch时，会逐渐达到一个较小的lr，具体：输入值为0epoch时返回1；输入值为epochs时，返回hyp['lrf'],即0.01
        #参数1即y1为1，参数2即y2为hyp['lrf']，总轮数epochs（如设定300lun）
        lf = one_cycle(1, hyp['lrf'], epochs)  # cosine 1->hyp['lrf']
    else:  # 使用线性学习率 x指输入的值 x=0，取值1.0；x=epochs(比如300),取值lrf
        lf = lambda x: (1 - x / epochs) * (1.0 - hyp['lrf']) + hyp['lrf']  # linear
    # 实例化 scheduler（学习率调节器） lr_scheduler:torch中自带的接口，lr是通过LambdaLR计算的
    # 画出学习率变化曲线 plot_lr_scheduler(optimizer, scheduler, epochs)
    scheduler = lr_scheduler.LambdaLR(optimizer, lr_lambda=lf)  # plot_lr_scheduler(optimizer, scheduler, epochs)

    # 训练前最后准备
    # EMA + 使用预训练 + 参数设置(gs、nl、imgsz、imgsz_test) + DP + DDP + SyncBatchNorm

    # 2EMA：单卡训练，因为model做迭代时，受到显卡限制，batchsize不能太大，若很小的bs做权重更新时，数据受到的
    #噪音比较大，使用moving average,相当于把上一次的weight值与下一次的weight值做一个平均，使weight变化更平滑
    # 使用EMA（指数移动平均）对模型的参数做平均, 一种给予近期数据更高权重的平均方法, 以求提高测试指标并增加模型鲁棒。
    ema = ModelEMA(model) if RANK in [-1, 0] else None

    # 3使用预训练
    #start_epoch:开始的epoch    best_fitness：最好的适合数据的epoch的number
    start_epoch, best_fitness = 0, 0.0
    if pretrained:  #如果采用预训练（pt）
        # Optimizer
        if ckpt['optimizer'] is not None:
            optimizer.load_state_dict(ckpt['optimizer'])
            best_fitness = ckpt['best_fitness']

        # EMA
        if ema and ckpt.get('ema'):
            ema.ema.load_state_dict(ckpt['ema'].float().state_dict())
            ema.updates = ckpt['updates']

        # Epochs
        start_epoch = ckpt['epoch'] + 1
        if resume: # 断点训练
            assert start_epoch > 0, f'{weights} training to {epochs} epochs is finished, nothing to resume.'
        if epochs < start_epoch:
            LOGGER.info(f"{weights} has been trained for {ckpt['epoch']} epochs. Fine-tuning for {epochs} more epochs.")
            epochs += ckpt['epoch']  # finetune additional epochs

        del ckpt, csd

    # 4是否使用DP mode(多卡之间的)（现在一般不使用这个而是使用DDP）
    # 若执行此程序事单卡，则不会进入这里；若多卡的话，则一般不使用这个，而是有dp到ddp的转换
    # DP: 单机多卡模式
    # 如果rank=-1且gpu数量>1，则使用DataParallel单机多卡模式，效果并不好（分布不平均）
    if cuda and RANK == -1 and torch.cuda.device_count() > 1:
        LOGGER.warning('WARNING: DP not recommended, use torch.distributed.run for best DDP Multi-GPU results.\n'
                       'See Multi-GPU Tutorial at https://github.com/ultralytics/yolov5/issues/475 to get started.')
        model = torch.nn.DataParallel(model)

    # SyncBatchNorm 是否使用跨卡BN（多卡），训练时是把多模型复制到多张卡中，，做bn时，是把不同卡数据做一个同步
    if opt.sync_bn and cuda and RANK != -1:
        model = torch.nn.SyncBatchNorm.convert_sync_batchnorm(model).to(device)
        LOGGER.info('Using SyncBatchNorm()')

#-----------------------------5.7 train函数——数据加载 / anchor调整-------------------------------
# 加载训练集dataloader、dataset + 参数(mlc、nb) + 加载验证集valloader + 如果不使用断点续训，
# 设置labels相关参数(labels、c) ，plots可视化数据集labels信息，检查anchors(k-means + 遗传进化算法)，model半精度
    #训练集数据加载
    train_loader, dataset = create_dataloader(train_path, imgsz, batch_size // WORLD_SIZE, gs, single_cls,
                                              hyp=hyp, augment=True, cache=None if opt.cache == 'val' else opt.cache,
                                              rect=opt.rect, rank=LOCAL_RANK, workers=workers,
                                              image_weights=opt.image_weights, quad=opt.quad,
                                              prefix=colorstr('train: '), shuffle=True)
    # 获取标签中最大类别值，与类别数作比较，如果小于类别数则表示有问题；第一个0索引表示类别；max：即class最大的值
    #先把dataset的labels放入到list中去，然后由0知是对类的，max即求类最大的值
    #dataset.labels：里面包括五个值：类别、bbox位置以及宽高（小数是因为与imgsize做了归一化）
    #np.concatenate：numpy对在其中的array按照第二位置的维度进行拼接
    #mlc:# 类最大值。例如：19,索引到19，因为voc类别20个
    mlc = int(np.concatenate(dataset.labels, 0)[:, 0].max())  # max label class
    #batch数量：1035，因为train_loader中的每个元素相当于一个分组
    nb = len(train_loader)  # number of batches
    #要训练的图片类别一定小于预训练配置文件中的种类  # 判断编号是否正确
    assert mlc < nc, f'Label class {mlc} exceeds nc={nc} in {data}. Possible class labels are 0-{nc - 1}'

    #rank为[-1, 0]为进行单机模式
    # 验证集数据集加载
    if RANK in [-1, 0]:
        val_loader = create_dataloader(val_path, imgsz, batch_size // WORLD_SIZE * 2, gs, single_cls,
                                       hyp=hyp, cache=None if noval else opt.cache,
                                       rect=True, rank=-1, workers=workers * 2, pad=0.5,
                                       prefix=colorstr('val: '))[0]

        if not resume:#不断点训练
            #concatenate：用来对数列或矩阵进行合并的，0表示在第0个维度进行拼接，
            #即把所有labels拼接到一起，每个label有五个值：类别、中心点坐标、宽高,由16551（图片数）拼接为40058（所有图片中的物体）
            #labels数量（横坐标）代表bbox数量，代表图片中物体的数量，纵坐标是五个维度（类别、中心点坐标、宽高）
            labels = np.concatenate(dataset.labels, 0)
            # c = torch.tensor(labels[:, 0])  # classes
            # cf = torch.bincount(c.long(), minlength=nc) + 1.  # frequency
            # model._initialize_biases(cf.to(device))
            #画出数据的分布
            if plots:
                #画：run/exp/train/labels.jpg、labels_correlogram.jpg
                plot_labels(labels, names, save_dir)

            # Anchors,因为有所有label，它会帮助看设置的anchor合不合理，若不合理则会用kmeans算出来anchor
            # 计算默认锚框anchor与数据集标签框的高宽比
            # 标签的高h宽w与anchor的高h_a宽h_b的比值 即h/h_a, w/w_a都要在(1/hyp['anchor_t'], hyp['anchor_t'])是可以接受的
            # 如果bpr小于98%，则根据k-mean算法聚类新的锚框Anchors
            if not opt.noautoanchor:
                check_anchors(dataset, model=model, thr=hyp['anchor_t'], imgsz=imgsz)
            #f32->16减小模型大小，半精度，为了更好适合auto mix precision设置
            model.half().float()  # pre-reduce anchor precision预降低锚定精度

        callbacks.run('on_pretrain_routine_end')

#-------------------5.8train函数——训练配置/多尺度训练/热身训练----------
    """
            设置/初始化一些训练要用的参数(hyp[‘box’]、hyp[‘cls’]、hyp[‘obj’]、hyp[‘label_smoothing’]、model.nc、model.hyp、model.gr、从训练样本标签
                    得到类别权重model.class_weights、model.names、热身迭代的次数iterationsnw、last_opt_step、初始化maps和results、学习率衰减所进行到的轮次scheduler.last_epoch + 
                    设置amp混合精度训练scaler + 初始化损失函数compute_loss + 打印日志信息) 
        """
#训练
    #1 DDP mode
    # DDP：多卡中使用 注：rank为进程，local_rank为进程中的第几块GPU
    if cuda and RANK != -1:
        model = DDP(model, device_ids=[LOCAL_RANK], output_device=LOCAL_RANK)


    #  Model parameters 模型参数的一些调整  Model attributes
    #model[-1]:表示模型最后一层  de_parallel：用于判断单卡还是多卡(能否并行)多卡返回model.module，单卡返回model
    nl = de_parallel(model).model[-1].nl  # number of detection layers (to scale hyps)
    #  hyp['cls']和hyp['obj']分别为将类别损失系数基于coco数据集进行缩放和将图片缩放到对应输出层，因为配置文件中默认为训练coco数据集的配置参数。即自训练类别大于80，则类别损失加大，否则减少。
    hyp['box'] *= 3 / nl  # scale to layers，因为现在也是3，所以相除为1，不需要scale,参数原来就是在三个检测层做的
    #根据自己数据集的类别数设置分类损失的系数
    #因为原先选定的voc有20类别，现在除以80，所以scale到原来的1/4，作为最终的分类损失系数
    hyp['cls'] *= nc / 80 * 3 / nl  # 根据数据集分类损失系数 scale to classes and layers
    hyp['obj'] *= (imgsz / 640) ** 2 * 3 / nl  # scale to image size and layers
    # 标签平滑
    hyp['label_smoothing'] = opt.label_smoothing
    model.nc = nc  # attach number of classes to model
    model.hyp = hyp  # attach hyperparameters to model
    #labels_to_class_weights：因为不同类别出现的个数往往不均衡，所以这里的这个函数是为了每一个class
    #拿到的权重做一个分配,使比较均衡   # 即从训练样本标签得到类别权重和类别中的目标数成反比，使得权重更平衡）
    model.class_weights = labels_to_class_weights(dataset.labels, nc).to(device) * nc  # attach class weights
    #class名字
    model.names = names

    # Start training
    t0 = time.time()
    # 获取热身迭代的次数iterations：
    #warmup_epochs每个warmup的epoch数量  nb：每个epoch的batch数量
    #所以总体指的是warmup的bat数量
    nw = max(round(hyp['warmup_epochs'] * nb), 1000)  # number of warmup iterations, max(3 epochs, 1k iterations)
    # nw = min(nw, (epochs - start_epoch) / 2 * nb)  # limit warmup to < 1/2 of training
    last_opt_step = -1
    # 初始化maps(每个类别的map)和results
    maps = np.zeros(nc)  # mAP per class
    results = (0, 0, 0, 0, 0, 0, 0)  # P, R, mAP@.5, mAP@.5-.95, val_loss(box, obj, cls)
    # 设置学习率衰减所进行到的轮次，即使打断训练，使用resume接着训练也能正常衔接之前的训练进行学习率衰减
    scheduler.last_epoch = start_epoch - 1  # do not move
    #amp:自动混合精度 在训练一个数值精度为float32的模型时，一部分的算子的精度为float16，具体哪些算子需要16的精度，可以进行自动安排。
    #功能：缩短训练时间、降低存储需求
    # 设置amp混合精度训练    GradScaler函数（因为在做map时候需要对梯度进行scale） + autocast
    #在训练前实例化一个GradScaler对象，使用混合精度是通过1GradScaler函数（放大loss值防止梯度的underflow）
    #这只是bp（后向传播）的时候传递梯度信息使用，真正更新权重时候还是要把放大再缩放回去
    #2autocast:会把tensor的dtype转换为半精度浮点型，从而在不损失训练精度情况下加快运算
    scaler = amp.GradScaler(enabled=cuda)
    #即当连续训练几个epoch时，发现loss没有下降，就会提前停止
    stopper = EarlyStopping(patience=opt.patience)
    # 初始化损失函数
    compute_loss = ComputeLoss(model)  # init loss class
    # 打印日志信息  train_loader.num_workers * WORLD_SIZE：即给dataloader分配的进程数
    #打印训练和测试输入图片分辨率、加载图片时调用的cpu进程数、从哪个epoch开始训练
    #dataloader workers指分配多少个进程
    LOGGER.info(f'Image sizes {imgsz} train, {imgsz} val\n'
                f'Using {train_loader.num_workers * WORLD_SIZE} dataloader workers\n'
                f"Logging results to {colorstr('bold', save_dir)}\n"
                f'Starting training for {epochs} epochs...')

    # 开始训练-----------------------------------------------------------------------------------------------------
    """
         开始训练(注意五点：图片采样策略(默认flase) + Warmup热身训练 + multi_scale多尺度训练(默认flase) + amp混合精度训练（前向）+后向传播 + accumulate 梯度更新策略（当前bat-上次bat>=accu时更新）) + 
                打印训练相关信息(包括当前epoch、显存、损失(box、obj、cls、total)、当前batch的target的数量和图片的size等 + 
                Plot 前三次迭代的barch的标签框再图片中画出来并保存 + wandb ) + 
                validation(一个epoch之后)调整学习率scheduler.step() 、emp val.run()得到results, maps相关信息、
                        将测试结果results写入result.txt中、wandb_logger、Update best mAP 以加权mAP fitness为衡量标准、Save model)
    """

    #从第一个到自己设定的epoch进行训练
    for epoch in range(start_epoch, epochs):  # epoch ------------------------------------------------------------------
        model.train()#一次epoch训练

        # Update image weights (optional, single-GPU only)

        # 如果为True 进行图片采样策略(按数据集各类别权重采样)，即根据上面的class_weights类别权重
        #放入到类别图片权重，则对应类别较少的图片因为权重更大，被选中的概率更高一些，实现平衡
        if opt.image_weights: #默认flase，所以进不来
            """
                        如果设置进行图片采样策略，
                        则根据前面初始化的图片采样权重model.class_weights以及maps配合每张图片包含的类别数
                        通过random.choices生成图片索引indices从而进行采样
                        （即真正的数据集采用哪些图片还可以再次采样）
                        """
            #由公式可知根据maps值更新class_weights 从训练(gt)标签获得每个类的权重  标签频率高的类权重低
            #根据公式也可以看出来，对于好的map，class weight就会变小
            cw = model.class_weights.cpu().numpy() * (1 - maps) ** 2 / nc  # class weights
            #把class转换成image weights 得到每一张图片对应的采样权重
            iw = labels_to_image_weights(dataset.labels, nc=nc, class_weights=cw)  # image weights
            #最后送给dataloader
            # random.choices: 从range(dataset.n)序列中按照weights(参考每张图片采样权重)进行采样, 一次取一个数字，采样次数为k
            # 最终得到所有图片的采样顺序(参考每张图片采样权重)
            dataset.indices = random.choices(range(dataset.n), weights=iw, k=dataset.n)  # rand weighted idx

        # Update mosaic border (optional)
        # b = int(random.uniform(0.25 * imgsz, 0.75 * imgsz + gs) // gs * gs)
        # dataset.mosaic_border = [b - imgsz, -b]  # height, width borders

        #初始化训练时打印的平均损失信息
        mloss = torch.zeros(3, device=device)  # mean losses
        if RANK != -1:
        # DDP模式下打乱数据, ddp.sampler的随机采样数据是基于epoch+seed作为随机种子，
        # 每次epoch不同，随机种子就不同
        #此为随机采样
            train_loader.sampler.set_epoch(epoch)
        # 进度条，方便训练时信息的展示 pbar相当于一个迭代器
        pbar = enumerate(train_loader)
        #%10s代表输出宽度为10个字符,如果输出的字符串不超过10,则在左边补空格(右对齐)  '\n'：换行之后打印那七个元素
        LOGGER.info(('\n' + '%10s' * 7) % ('Epoch', 'gpu_mem', 'box', 'obj', 'cls', 'labels', 'img_size'))
        if RANK in [-1, 0]:
            #这里控制台打印出进度条那一行，显示进度以及0/1035,1035为一个epoch的batch数目  pbar是一个iterator对象，用tqdm包裹了一下
            pbar = tqdm(pbar, total=nb, bar_format='{l_bar}{bar:10}{r_bar}{bar:-10b}')  # progress bar
        optimizer.zero_grad()# 梯度清零
        #对pbar进行batch迭代，pbar相当于一个迭代器，执行完发现在控制台有一个进度条，还有当前epoch需要运行多少batch
        #imgs:16,表示一个bat   targets：表示这一个batch（16个图片有多少目标框） path:16张图片路径
        for i, (imgs, targets, paths, _) in pbar:  # batch -------------------------------------------------------------
            # 计算迭代的次数iteration
            #当前epoch中的第i个batch nb:每个epoch中batch数量  epoch：已经训练了多少epoch
            #故ni表示训练开始以来训练了多少batch
            ni = i + nb * epoch  # number integrated batches (since train start)
            #把图片送到cuda（gpu）中，转换为float，然后再去除以255做一个归一化，即把图片像素变为0到1之间
            # 这是为了在将范围变成[0，1]之间，因为图片信息的数值矩阵类型为unit8型，在0~255范围内，为了保证精度，上面数据处理时转换double型，
            # 但是直接运行imshow(图像)，会显示一个白色的图像。这是因为imshow()显示图像时对double型是认为在0~1范围内，即大于1时都是显示为白色，
            # 所以解决办法就是除以255后，图片矩阵的就变成0~1之间的double型，这样才可以正确表达图片信息。
            imgs = imgs.to(device, non_blocking=True).float() / 255  # uint8 to float32, 0-255 to 0.0-1.0

            # Warmup
            # ni表示历史以来训练了多少batch  nw：热身的迭代次数,指的是warmup的bat数量
            # 热身训练（前nw次迭代）热身训练迭代的次数iteration范围[1:nw]  选取较小的accumulate，调节学习率以及momentum,慢慢的训练
            if ni <= nw: #true
                xi = [0, nw]  # x interp [0,3105]

                #accumulate：热身训练并不是直接为64/16=4，而是利用interp缓慢爬坡，慢慢到4的，也就是每达到acculate-4，则进行一次更新
                #ni：当前已经进行总的batch
                #np.interp():把x坐标ni对应的y坐标插进去,得到得到Y坐标值就是accumulate。主要使用场景为一维线性插值，主要作用就是拟合曲线，根据现有的曲线取点来进行拟合。
                #其一参表示曲线图的所取插值的x坐标，二参表示坐标系的x坐标范围，三参表示坐标系y坐标。当xi等于0时，其y值为1；当xi等于nw时，其y值为nbs / batch_size
                #返回的就是插值对应的y值
                #上面代码有讲过，accumulate为4，即四次accumulate相当于迭代了64个bat才更新一次参数的更新,
                # 但是若warmup时一来了就进行四次累计以后再四次迭代有点狠，这里只是对其warmup,慢慢爬坡爬起来，慢慢更新。比如刚开始acc为1，到3105之前，慢慢爬到4.等到3105个bat时，即热身训练结束后，再爬到4，以后一直四个再更新参数
                accumulate = max(1, np.interp(ni, xi, [1, nbs / batch_size]).round())

                #sgd中三组groups，则j分别取0，1，2
                #即在热身训练【0，3epoch*batch】中，把g2（bn的bias）的lr从0.1 to lr0，把其他（g0-bn的weight、g1-卷积的weight）从0.0 to lr0
                for j, x in enumerate(optimizer.param_groups):
                    # bias lr falls from 0.1 to lr0, all other lrs rise from 0.0 to lr0
                    # 作用把bias从0.1下降到基准学习率lr*lf(epoch)（因为这些参数强壮，可以容忍相对较大lr,所以刚开始就为0.1）
                    # 作用在以及bn中的weights以及卷积的weight的参数学习率从0增加到lr*lf(epoch)（因为怕他们太脆弱，所以开始为0的warmup）
                    # lf为上面设置的余弦退火的衰减函数
                    #总：如果选取sgd中的group2时，与横坐标xi【0，3105】对应y坐标初始值（即0对应的）取warmup_bias_lr，否则（g0和g1）取0；y坐标的最终值（即nw=3105对应的）为x['initial_lr'] * lf(epoch)
                    x['lr'] = np.interp(ni, xi, [hyp['warmup_bias_lr'] if j == 2 else 0.0, x['initial_lr'] * lf(epoch)])
                    #动量momentum也从0.9慢慢变到hyp['momentum'](default=0.937)
                    if 'momentum' in x:
                        x['momentum'] = np.interp(ni, xi, [hyp['warmup_momentum'], hyp['momentum']])

            # Multi-scale 多尺度训练   从[imgsz*0.5, imgsz*1.5+gs]间随机选取一个尺寸(32的倍数)作为当前batch的尺寸送入模型开始训练
            # 因为没有全连接层，所以网络适用于不同尺度的img输入。倘若打开了multi_scale，即执行下面操作
            # imgsz: 默认训练尺寸   gs: 模型最大stride=32   [32 16 8]
            if opt.multi_scale:
                sz = random.randrange(imgsz * 0.5, imgsz * 1.5 + gs) // gs * gs  # size
                sf = sz / max(imgs.shape[2:])  # scale factor
                if sf != 1: #则将图片resize缩放
                    ns = [math.ceil(x * sf / gs) * gs for x in imgs.shape[2:]]  # new shape (stretched to gs-multiple)
                    #插值后得到新的图片数据
                    imgs = nn.functional.interpolate(imgs, size=ns, mode='bilinear', align_corners=False)

            # Forward 前向传播
            # amp:自动混合精度 在训练一个数值精度为float32的模型时，一部分的算子的精度为float16，具体哪些算子需要16的精度，可以进行自动安排。
            # 功能：缩短训练时间、降低存储需求
            # 设置amp混合精度训练    GradScaler函数（因为在做map时候需要对梯度进行scale） + autocast
            # 混合精度训练（autocast+gradscaler）中的autocast：上下文应只包含前向过程（包括loss计算），不包括反向传播，
            #因为反向op与前向op类型相同
            with amp.autocast(enabled=cuda): #(model + loss)
                #pred为一个列表，包括0，1，2三部分，0 torch.Size([16, 3, 80, 80, 25])；1为40*40；2为20*20
                #返回的pred是三个layer的预测，包括预测的所有bbox、目标置信度、具体类别
                pred = model(imgs)  #  forward；前向传播
                # 计算损失，包括分类损失，objectness损失，框的回归损失
                # loss为总损失值，loss_items为一个元组，包含分类损失，objectness损失，框的回归损失和总损失
                loss, loss_items = compute_loss(pred, targets.to(device))  # loss scaled by batch_size
                #芒果修改
                #loss, loss_items = compute_loss(pred, targets.to(device), opt.category_iou)  # loss scaled by batch_size
                if RANK != -1:
                    # 平均不同gpu之间的梯度
                    loss *= WORLD_SIZE  # gradient averaged between devices in DDP mode
                if opt.quad: # 如果采用collate_fn4取出mosaic4数据loss也要翻4倍
                    loss *= 4.

            # Backward：反向传播 将梯度放大防止梯度的underflow下溢（amp混合精度训练）
            #前面也提到bp（后向传播）的时候传递梯度信息使用，真正更新权重时候还是要把放大再缩放回去
            scaler.scale(loss).backward()  # 反向传播；Scales loss. 为了梯度放大.

            # Optimize迭代    模型反向传播accumulate次之后再根据累积的梯度更新一次参数
            #这次的batch-上一次batch>= accumulate就是step更新参数
            #accumulate是一直慢慢往上长，直到为4（64/16=4）
            if ni - last_opt_step >= accumulate: #（与3.0不同）
                # scaler.step()首先把梯度的值unscale回来
                # 如果梯度的值不是 infs（无穷大） 或者 NaNs, 那么调用optimizer.step()来更新权重,
                # 否则，忽略step调用，从而保证权重不更新（不被破坏）
                scaler.step(optimizer)  # optimizer.step
                # 准备着，看是否要增大scaler
                scaler.update()
                # 梯度清零
                optimizer.zero_grad()
                if ema: #计算出来的data weight加到model weight中去
                    # 当前epoch训练结束  更新ema
                    ema.update(model)
                last_opt_step = ni

            # Log
            # 打印Print一些信息 包括当前epoch、显存、损失(box、obj、cls、total)、当前batch的target的数量和图片的size等信息
            if RANK in [-1, 0]:
                #此epoch中每进行一个bat与前面的相加/bat数目计算的平均loss
                mloss = (mloss * i + loss_items) / (i + 1)  # update mean losses
                mem = f'{torch.cuda.memory_reserved() / 1E9 if torch.cuda.is_available() else 0:.3g}G'  # (GB)
                #进度条显示信息，七个元素对应的值
                pbar.set_description(('%10s' * 2 + '%10.4g' * 5) % (
                    f'{epoch}/{epochs - 1}', mem, *mloss, targets.shape[0], imgs.shape[-1]))
                #callback:回调函数是一个函数，将会在另一个函数完成执行后立即执行。
                #总体：执行callbacks后，会把括号里的东西给调用def train(hyp,opt,device,callbacks)的函数，即
                #train(opt.hyp, opt, device, callbacks)，再溯源到def main(opt, callbacks=Callbacks()):
                #找到Callbacks()类中的run函数 ，把这些东西放进去执行
                callbacks.run('on_train_batch_end', ni, model, imgs, targets, paths, plots, opt.sync_bn)
                if callbacks.stop_training:
                    return
            # end batch ------------------------------------------------------------------------------------------------

        # Scheduler  一个epoch训练结束后都要调整学习率（学习率衰减）
        # group中三个学习率（pg0、pg1、pg2）每个都要调整
        lr = [x['lr'] for x in optimizer.param_groups]  # for loggers
        scheduler.step() #scheduler:lr调节器-lr更新

        # 一个epoch训练结束后val一次
        if RANK in [-1, 0]:
            # mAP
            callbacks.run('on_train_epoch_end', epoch=epoch)
            # 将model中的属性赋值给ema
            ema.update_attr(model, include=['yaml', 'nc', 'hyp', 'names', 'stride', 'class_weights'])
            # 判断当前epoch是否是最后一轮
            final_epoch = (epoch + 1 == epochs) or stopper.possible_stop
            # noval: 是否只测试最后一轮  True: 只测试最后一轮   False: 每轮训练完都测试mAP
            #即需要validation或者是最后一个epoch时，做验证
            if not noval or final_epoch:  # Calculate mAP
                # 测试使用的是ema（指数移动平均 对模型的参数做平均）的模型
                # results: [1] Precision 所有类别的平均precision(最大f1时)
                #          [1] Recall 所有类别的平均recall
                #          [1] map@0.5 所有类别的平均mAP@0.5
                #          [1] map@0.5:0.95 所有类别的平均mAP@0.5:0.95
                #          [1] box_loss 验证集回归损失, obj_loss 验证集置信度损失, cls_loss 验证集分类损失
                # maps: [80] 所有类别的mAP@0.5:0.95
                #得到result\class中的map
                results, maps, _ = val.run(data_dict,# 数据集配置文件地址 包含数据集的路径、类别个数、类名、下载地址等信息
                                           batch_size=batch_size // WORLD_SIZE * 2,
                                           imgsz=imgsz,# test img size
                                           model=ema.ema,# ema model
                                           single_cls=single_cls,# 是否是单类数据集
                                           dataloader=val_loader,# test dataloader
                                           save_dir=save_dir,# 保存地址 runs/train/expn
                                           plots=False,# 是否可视化
                                           callbacks=callbacks,
                                           compute_loss=compute_loss)# 损失函数(train)

            # Update best mAP 这里的best mAP其实是[P, R, mAP@.5, mAP@.5-.95]的一个加权值
            # fi: [P, R, mAP@.5, mAP@.5-.95]的一个加权值 = 0.1*mAP@.5 + 0.9*mAP@.5-.95
            fi = fitness(np.array(results).reshape(1, -1))  # weighted combination of [P, R, mAP@.5, mAP@.5-.95]
            if fi > best_fitness:#加权得到的map如果比历史上最好的map要好，则把fi赋给best_fitness（最佳匹配度）
                best_fitness = fi
            #把所有log放到一个list中
            log_vals = list(mloss) + list(results) + lr
            callbacks.run('on_fit_epoch_end', log_vals, epoch, best_fitness, fi)

            # Save model 每个epoch后都会保存模型
            # 保存带checkpoint（简称ckpt）的模型用于inference或resuming training
            # 保存模型, 还保存了epoch, results, optimizer等信息
            # optimizer将不会在最后一轮完成后保存
            # model保存的是EMA的模型
            #nosave:不保存模型，默认保存  final_epoch：判断是否为最后一轮epoch evolve:超参进化
            if (not nosave) or (final_epoch and not evolve):  # if save
                ckpt = {'epoch': epoch,#如果resume，则会知道到了哪个epoch了，如果续训，就知道下一个该哪个
                        'best_fitness': best_fitness, #最好的map
                        'model': deepcopy(de_parallel(model)).half(),
                        'ema': deepcopy(ema.ema).half(),#有ema恢复的时候更好一些
                        'updates': ema.updates,
                        'optimizer': optimizer.state_dict(),
                        'wandb_id': loggers.wandb.wandb_run.id if loggers.wandb else None,
                        'date': datetime.now().isoformat()}

                # Save last, best and delete
                #会将model的参数、框架都保存到路径最新一个pt中
                torch.save(ckpt, last)
                # 会将model的参数、框架都保存到路径最好一个pt中
                if best_fitness == fi:
                    torch.save(ckpt, best)
                if (epoch > 0) and (opt.save_period > 0) and (epoch % opt.save_period == 0):
                    torch.save(ckpt, w / f'epoch{epoch}.pt')
                #保存完删除cpkt
                del ckpt
                callbacks.run('on_model_save', last, epoch, final_epoch, best_fitness, fi)

            # Stop Single-GPU  检查是否需要stop
            if RANK == -1 and stopper(epoch=epoch, fitness=fi):
                break

            # Stop DDP TODO: known issues shttps://github.com/ultralytics/yolov5/pull/4576
            # stop = stopper(epoch=epoch, fitness=fi)
            # if RANK == 0:
            #    dist.broadcast_object_list([stop], 0)  # broadcast 'stop' to all ranks

        # Stop DPP
        # with torch_distributed_zero_first(RANK):
        # if stop:
        #    break  # must break all DDP ranks

        # end epoch ----------------------------------------------------------------------------------------------------
    # end training -----------------------------------------------------------------------------------------------------

#--------------------5.9train函数——训练结束 / 打印信息 / 保存结果-------------------------------
# 打印一些信息(日志: 打印训练时间、plots可视化训练结果results1.png、confusion_matrix.png
# 以及(‘F1’, ‘PR’, ‘P’, ‘R’)曲线变化 、日志信息) + coco评价(只在coco数据集才会运行) +
# 释放显存 return results

    # 所有epoch训练结束后再val一次
    if RANK in [-1, 0]:
        # 日志: 打印训练时间
        LOGGER.info(f'\n{epoch - start_epoch + 1} epochs completed in {(time.time() - t0) / 3600:.3f} hours.')
        for f in last, best:
            if f.exists():
                #把optimizer保存的参数去掉，因为不想保存那么多参数占用空间
                strip_optimizer(f)  # strip optimizers
                if f is best:
                    LOGGER.info(f'\nValidating {f}...')
                    #再走一遍val流程
                    results, _, _ = val.run(data_dict,
                                            batch_size=batch_size // WORLD_SIZE * 2,
                                            imgsz=imgsz,
                                            model=attempt_load(f, device).half(),
                                            iou_thres=0.65 if is_coco else 0.60,  # best pycocotools results at 0.65
                                            single_cls=single_cls,
                                            dataloader=val_loader,
                                            save_dir=save_dir,
                                            save_json=is_coco,
                                            verbose=True,
                                            plots=True,
                                            callbacks=callbacks,
                                            compute_loss=compute_loss)  # val best model with plots
                    if is_coco:
                        callbacks.run('on_fit_epoch_end', list(mloss) + list(results) + lr, epoch, best_fitness, fi)
        #回调注册给Callback类中名字为on_train_end的last, best, plots, epoch, results这些参数以及关键字参数
        callbacks.run('on_train_end', last, best, plots, epoch, results)
        LOGGER.info(f"Results saved to {colorstr('bold', save_dir)}")

    # 释放显存
    torch.cuda.empty_cache()
    return results

#-------------------------3.parse_opt() 是对函数输入参数进行解析和打印显示:即：配置项加载进来----------
def parse_opt(known=False):
    """
            函数功能：设置opt参数
        """
    # 建立参数解析对象parser argparse:python的命令行解析的模块，内置于python，不需要安装    可以让我们直接在命令行中就可以向程序中传入参数并让程序运行
    #如果自己有python中的命令，则命令是自己的，不是默认的
    parser = argparse.ArgumentParser()
    # --------------------------------------------------- 常用参数 ---------------------------------------------
    # weights: 权重文件
    #parser.add_argument('--weights', type=str, default=ROOT / 'weights/yolov5s.pt',help='initial weights path')
    #parser.add_argument('--weights', type=str, default=ROOT / 'runs/train/moganet/weights/best.pt', help='initial weights path')
    parser.add_argument('--weights', type=str, default='', help='initial weights path')
    # cfg: 网络模型配置文件、网络结构   包括nc、depth_multiple、width_multiple、anchors、backbone、head等 训练自己的数据集需要自己生成
    #parser.add_argument('--cfg', type=str, default=ROOT / 'models/ghostnetv2-original.yaml', help='model.yaml path')
    parser.add_argument('--cfg', type=str, default=ROOT / 'models/yolov5s.yaml', help='model.yaml path')
    # data: 实现数据集配置文件 包括path、train、val、test、nc、names、download等
    parser.add_argument('--data', type=str, default=ROOT / 'data/VisDrone.yaml', help='dataset.yaml path')
    #parser.add_argument('--data', type=str, default=ROOT / 'data/bhc3.yaml', help='dataset.yaml path')
    # hyp: 训练时的超参文件
    parser.add_argument('--hyp', type=str, default=ROOT / 'data/hyps/hyp.scratch-low.yaml', help='hyperparameters path')
    # epochs: 训练轮次
    parser.add_argument('--epochs', type=int, default=150)
    # batch-size: 训练批次大小
    parser.add_argument('--batch-size', type=int, default=16, help='total batch size for all GPUs, -1 for autobatch')
    # imgsz: 输入网络的图片分辨率大小

    parser.add_argument('--imgsz', '--img', '--img-size', type=int, default=640, help='train, val image size (pixels)')
    # resume: 断点续训, 从上次打断的训练结果处接着训练  默认False
    parser.add_argument('--resume', nargs='?', const=True, help='resume most recent training')
    # nosave: 不保存模型  默认保存  store_true: only test final epoch
    parser.add_argument('--nosave', action='store_true', help='only save final checkpoint')
    # workers: dataloader中的最大work数（线程个数）
    parser.add_argument('--workers', type=int, default=8, help='max dataloader workers (per RANK in DDP mode)')
    # device: 训练的设备
    parser.add_argument('--device', default='', help='cuda device, i.e. 0 or 0,1,2,3 or cpu')
    #parser.add_argument('--device', default='cuda:0', help='cuda device, i.e. 0 or 0,1,2,3 or cpu')
    # single-cls: 数据集是否只有一个类别 默认False
    parser.add_argument('--single-cls', action='store_true', help='train multi-class data as single-class')

    # --------------------------------------------------- 数据增强参数 ---------------------------------------------
    # rect: 训练集是否采用矩形训练  默认False   因为这里是store_true，所以如果python命令行用它时直接--rect就行，不用store_true=true
    parser.add_argument('--rect', action='store_true', help='rectangular training')
    # noautoanchor: 不自动调整anchor 默认False(自动调整anchor)
    parser.add_argument('--noautoanchor', action='store_true', help='disable AutoAnchor')
    # evolve: 是否进行超参进化，使得数值更好 默认False(当训练时候不知道设置超参数时，可以使用这里进行超参训练，得到比较好的超参数，如lr)
    parser.add_argument('--evolve', type=int, nargs='?', const=300, help='evolve hyperparameters for x generations')
    # multi-scale: 是否使用多尺度训练 默认False，要被32整除。
    parser.add_argument('--multi-scale', action='store_true', help='vary img-size +/- 50%%')
    # label-smoothing: 标签平滑增强 默认0.0不增强  要增强一般就设为0.1
    parser.add_argument('--label-smoothing', type=float, default=0.0, help='Label smoothing epsilon')
    # optimizer: 是否使用优化器 默认使用SGD
    parser.add_argument('--optimizer', type=str, choices=['SGD', 'Adam', 'AdamW'], default='SGD', help='optimizer')
    # sync-bn: 是否使用跨卡同步bn操作,再DDP中使用  默认False
    parser.add_argument('--sync-bn', action='store_true', help='use SyncBatchNorm, only available in DDP mode')
    # cache-image: 是否提前缓存图片到内存cache,以加速训练  默认False
    parser.add_argument('--cache', type=str, nargs='?', const='ram', help='--cache images in "ram" (default) or "disk"')
    # image-weights: 是否使用图片采用策略(selection img to training by class weights) 默认False 不使用
    #dataloader去加载每一个训练的数据，每个训练数据是等概率的事件。但是作者发现某一类的数据分类比较差，这时把这一类的image-weights加大，
    #即对于每个batch的训练，其会更新相应的数据，通过每个类别的权重系数class_weights，随机选取相应类别的数据
    #因为class_weights已经平衡了类别权重了，所以根据它可以得到类别图片被选中概率，即某类对应图片少则会增加
    #其图片权重，会有意多选择训练困难的数据进行训练
    
    parser.add_argument('--image-weights', action='store_true', help='use weighted image selection for training')

    # --------------------------------------------------- 其他参数 ---------------------------------------------
    # bucket: 谷歌云盘bucket 一般用不到
    parser.add_argument('--bucket', type=str, default='', help='gsutil bucket')
    # project: 训练结果保存的根目录 默认是runs/train    runs/train/p/p1
    parser.add_argument('--project', default=ROOT / 'runs/train/', help='save to project/name')
    # name: 训练结果保存的目录 默认是exp  最终: runs/train/exp数字  ghostnetv2(noo weights) ghostnetv2_original ghostnetv2_original(visdrone)
    #parser.add_argument('--name', default='fsppf5332simpnext9num3c3gam1_2aiou_ace', help='save to project/name') gam2_fasternet5332_visdrone mobilenetv3_visdrone shufflenetv2_visdrone yolov5se_visdrone cbamimp_8&24_visdrone
    parser.add_argument('--name', default='exp', help='save to project/name')#cbamimpin_1fb_visdrone cbamin_1fb_visdrone cbam_2,9,19,23,27_visdrone fasternext_yolov5_visdrone yolov5s_checkpointnight_1107
    # exist-ok: 如果文件存在就ok不存在就新建或increment name(比如存在exp3不存在exp4,则新训练好的可以保存在新创建的exp4中)  默认False(默认文件都是不存在的
    # 0
    # )
    parser.add_argument('--exist-ok', action='store_true', help='existing project/name ok, do not increment')
    # quad: dataloader取数据时, 是否使用collate_fn4代替collate_fn  默认False
    parser.add_argument('--quad', action='store_true', help='quad dataloader')
    # save_period: Log model after every "save_period" epoch    默认-1 不需要log model 信息
    parser.add_argument('--save-period', type=int, default=-1, help='Save checkpoint every x epochs (disabled if < 1)')
    # local_rank:当前节点（机器）进程（gpu）的相对序号
    #这个参数表示进程对应的GPU号，系统会自动识别，
    # 配置local_rank参数，告诉每个进程自己的位置，要使用哪张GPU
    parser.add_argument('--local_rank', type=int, default=-1, help='DDP parameter, do not modify')

    # --------------------------------------------------- V6新增 ---------------------------------------------
    # --noval:是否只在最后一次测试网络模型
    parser.add_argument('--noval', action='store_true', help='only validate final epoch')
    parser.add_argument('--cos-lr', action='store_true', help='cosine LR scheduler')
    parser.add_argument('--patience', type=int, default=100, help='EarlyStopping patience (epochs without improvement)')
    parser.add_argument('--freeze', nargs='+', type=int, default=[0], help='Freeze layers: backbone=10, first3=0 1 2')

    # --------------------------------------------------- 四个W&B(wandb)参数 ---------------------------------------
    # Weights & Biases arguments
    parser.add_argument('--entity', default=None, help='W&B: Entity')
    parser.add_argument('--upload_dataset', nargs='?', const=True, default=False, help='W&B: Upload data, "val" option')
    parser.add_argument('--bbox_interval', type=int, default=-1, help='W&B: Set bounding-box image logging interval')
    # artifact_alias: which version of dataset artifact to be stripped  默认lastest  貌似没用到这个参数？
    parser.add_argument('--artifact_alias', type=str, default='latest', help='W&B: Version of dataset artifact to use')
    #https://blog.csdn.net/qq_43391414/article/details/122992458
    # help，参数的解释，相当于是注释作用，怕自己忘了。
    #action=‘store_true’。使用这个选项的参数必须为布尔变量。其中store_true表示：用户指定了这个参数，那么这个参数就为true。
    #什么叫用户指定了？例如上面这个特殊的例子，python main.py -x，其指定了x，那么x就会变成True。
    #户如果没有指定，就看默认值，如果没有默认值，那么就是相反的情况，即如果action=store_true，但是默认就是False。
    #parser.add_argument('--acmix', action='store_true', help='useacmix')#当让acmix为true时，还得命令行中写出来，所以直接默认为true了
    #parser.add_argument('--acmix', default=True, help='useacmix')

    #parser.add_argument('--category_iou', default='c_iou', help='iou')

    # parser.parse_known_args() 获取解析参数    parse_args():解析添加得参数
    # 作用就是当仅获取到基本设置时，如果运行命令中传入了之后才会获取到的其他配置，不会报错；而是将多出来的部分保存起来，留到后面使用
    opt = parser.parse_known_args()[0] if known else parser.parse_args()
    return opt

#---------- 4主函数，其中 check_requirements 用来对 python 版本和 requirements.txt 文件必须要安装的包的版本进行检测。run()函数则是执行目标检测的主函数。
#opt:所有的参数
def main(opt, callbacks=Callbacks()):
#---------------#4.1 打印所有训练参数、检查代码版本、检查并安装未安装好的环境--------------------------------------
#rank：表示多张显卡训练时的进程编号;,每一个进程对应了一个rank的进程，整个分布式由许多rank完成。
# DP mode 分布式训练,参照:https://github.com/ultralytics/yolov5/issues/475
# DataParallel模式,仅支持单机多卡，只有一个进程；DDP:多机多卡，会开启多个进程 https://www.zhihu.com/question/453920336/answer/2612740742
# rank为进程编号, 如果设置为rank=-1并且有多块gpu，则使用DataParallel模式，单机多卡
# rank=-1且gpu数量=1时,不会进行分布式
    #主类进程
    if RANK in [-1, 0]:

        # 输出所有训练参数
        #例如：train: weights=weights/yolov5s.pt, cfg=models/yolov5s.yaml, data=data/VOC.yaml, hyp=data/hyps/hyp.scratch-low.yaml, epochs=1, batch_size=16, imgsz=640, resume=False, nosave=False, workers=8, device=, single_cls=False, rect=False, noautoanchor=False, evolve=None, multi_scale=False, label_smoothing=0.0, optimizer=SGD, sync_bn=False, cache=None, image_weights=False, bucket=, project=runs/train, name=100轮+YOLOV6.1原型结果, exist_ok=False, quad=False, save_period=-1, local_rank=-1, noval=False, cos_lr=False, patience=100, freeze=[0], entity=None, upload_dataset=False, bbox_interval=-1, artifact_alias=latest
        print_args(FILE.stem, opt)
        # 检查代码版本是否是最新的,如果不是最新的则会拉一下代码  github: ...(不适用于windows系统)
        check_git_status()
        # 检查安装是否都安装了 requirements.txt， 缺少安装包安装。
        # 缺少安装包：建议使用 pip install -i https://pypi.tuna.tsinghua.edu.cn/simple -r requirements.txt
        check_requirements(exclude=['thop'])

    # Resume
# 4.2、--------是否使用断点续训-使用就从last.pt中读取相关参数；不使用断点续训 就从文件中读取相关参数--------
#本例中未用到
    # 初始化可视化工具wandb,wandb使用教程看https://zhuanlan.zhihu.com/p/266337608
    # 断点训练使用教程可以查看：https://blog.csdn.net/CharmsLUO/article/details/123410081
    #使用断点续训
    if opt.resume and not check_wandb_resume(opt) and not opt.evolve:  # resume an interrupted run
        #ckpt：是传来的模型地址
        # 如果resume是str，则表示传入的是模型的路径地址
        # 如果resume是True，则通过get_lastest_run()函数找到runs为文件夹中最近的权重文件last.pt
        #pt一般是PyTorch的模型保存格式   ckpt一般是tenseflow的模型保存格式
        ckpt = opt.resume if isinstance(opt.resume, str) else get_latest_run()  # specified or most recent path
        assert os.path.isfile(ckpt), 'ERROR: --resume checkpoint does not exist'
        # 相关的opt参数也要替换成last.pt中的opt参数
        with open(Path(ckpt).parent.parent / 'opt.yaml', errors='ignore') as f:
            opt = argparse.Namespace(**yaml.safe_load(f))  # replace
        opt.cfg, opt.weights, opt.resume = '', ckpt, True  # reinstate
        LOGGER.info(f'Resuming training from {ckpt}')
    else:
        # 不使用断点续训 就加载输入的参数，这里是对data做一个检查，如果存在则返回，不存在则下载
        opt.data, opt.cfg, opt.hyp, opt.weights, opt.project = \
            check_file(opt.data), check_yaml(opt.cfg), check_yaml(opt.hyp), str(opt.weights), str(opt.project)  # checks
        #如果assert错误，则必须指定--cfg或--weights
        #assert用法就是：如果len(opt.cfg) or len(opt.weights)成立，则继续往下执行，否则打印 'either --cfg or --weights must be specified'
        assert len(opt.cfg) or len(opt.weights), 'either --cfg or --weights must be specified'
        #opt.evolve:none
        if opt.evolve:#（没有进入）
            if opt.project == str(ROOT / 'runs/train'):  # if default project name, rename to runs/evolve
                opt.project = str(ROOT / 'runs/evolve')
            opt.exist_ok, opt.resume = opt.resume, False  # pass resume to exist_ok and disable resume
        #保存相关信息 runs/train/exp  increment_path：使名称序号增加，即如果有exp4则下次对于exp来说会生成exp5，不会把以前存在的覆盖掉
        #(比如runs/train/exp中存在exp3不存在exp4,则新训练好的可以保存在新创建的exp4中)
        opt.save_dir = str(increment_path(Path(opt.project) / opt.name, exist_ok=opt.exist_ok))

#--------4.3是否使用分布式训练-------------------------------------
    # DDP mode
    # 选择设备  cpu/cuda:0  device：如果为‘’，则程序自己去找对应的设备
    device = select_device(opt.device, batch_size=opt.batch_size)
    # local_rank是指在一个node（物理节点，可以是一台机器也可以是一个容器，节点内部可以有多个GPU）上进程的相对序号
    #Python通常假设等级 0 是第一个进程或基本进程。然后对其他进程进行不同的排序，例如1、2、3，总共四个进程。
    #如果我们使用单进程时，往往会设置进程号为-1。
    #总而言之，当local_rank=-1或者0时，我们认为它是主进程。
    # 多卡训练GPU，因为不是多卡，所以没有进入
    if LOCAL_RANK != -1: #当不是单卡时，进行多GPU训练
        msg = 'is not compatible with YOLOv5 Multi-GPU DDP training'
        assert not opt.image_weights, f'--image-weights {msg}'
        assert not opt.evolve, f'--evolve {msg}'
        assert opt.batch_size != -1, f'AutoBatch with --batch-size -1 {msg}, please pass a valid --batch-size'
        assert opt.batch_size % WORLD_SIZE == 0, f'--batch-size {opt.batch_size} must be multiple of WORLD_SIZE'
        assert torch.cuda.device_count() > LOCAL_RANK, 'insufficient CUDA devices for DDP command'
        ##使用torch.cuda.set_device()可以更方便地将模型和数据加载到对应GPU上, 直接定义模型之前加入一行代码即可
        # torch.cuda.set_device(gpu_id) #单卡
        # torch.cuda.set_device('cuda:'+str(gpu_ids)) #可指定多卡
        # 为这个进程指定GPU
        torch.cuda.set_device(LOCAL_RANK)
        #torch.device代表将torch.tensor分配到的设备的对象(简单点说，就是分配到你的CPU还是GPU上,以及哪块GPU上)。
        #如果设备序号不存在，则为当前设备；
        device = torch.device('cuda', LOCAL_RANK)
        # 初始化多进程
        dist.init_process_group(backend="nccl" if dist.is_nccl_available() else "gloo")

#-----------------------4.4 main函数——是否进化训练/遗传算法调参------------------------------
    # Train
    # 不设置evolve直接调用train训练
    if not opt.evolve:
        train(opt.hyp, opt, device, callbacks)
        # 分布式训练 WORLD_SIZE=主机的数量
        # 如果是使用多卡训练, 那么销毁进程组
        if WORLD_SIZE > 1 and RANK == 0:
            LOGGER.info('Destroying process group... ')
            dist.destroy_process_group()

    # 遗传净化算法/一边训练一遍进化
    # Evolve hyperparameters (optional)
    else:
        # Hyperparameter evolution metadata (mutation scale 0-1, lower_limit, upper_limit)
        # 超参进化列表 (突变规模, 最小值, 最大值)
        meta = {'lr0': (1, 1e-5, 1e-1),  # initial learning rate (SGD=1E-2, Adam=1E-3)
                'lrf': (1, 0.01, 1.0),  # final OneCycleLR learning rate (lr0 * lrf)
                'momentum': (0.3, 0.6, 0.98),  # SGD momentum/Adam beta1
                'weight_decay': (1, 0.0, 0.001),  # optimizer weight decay
                'warmup_epochs': (1, 0.0, 5.0),  # warmup epochs (fractions ok)
                'warmup_momentum': (1, 0.0, 0.95),  # warmup initial momentum
                'warmup_bias_lr': (1, 0.0, 0.2),  # warmup initial bias lr
                'box': (1, 0.02, 0.2),  # box loss gain
                'cls': (1, 0.2, 4.0),  # cls loss gain
                'cls_pw': (1, 0.5, 2.0),  # cls BCELoss positive_weight
                'obj': (1, 0.2, 4.0),  # obj loss gain (scale with pixels)
                'obj_pw': (1, 0.5, 2.0),  # obj BCELoss positive_weight
                'iou_t': (0, 0.1, 0.7),  # IoU training threshold
                'anchor_t': (1, 2.0, 8.0),  # anchor-multiple threshold
                'anchors': (2, 2.0, 10.0),  # anchors per output grid (0 to ignore)
                'fl_gamma': (0, 0.0, 2.0),  # focal loss gamma (efficientDet default gamma=1.5)
                'hsv_h': (1, 0.0, 0.1),  # image HSV-Hue augmentation (fraction)
                'hsv_s': (1, 0.0, 0.9),  # image HSV-Saturation augmentation (fraction)
                'hsv_v': (1, 0.0, 0.9),  # image HSV-Value augmentation (fraction)
                'degrees': (1, 0.0, 45.0),  # image rotation (+/- deg)
                'translate': (1, 0.0, 0.9),  # image translation (+/- fraction)
                'scale': (1, 0.0, 0.9),  # image scale (+/- gain)
                'shear': (1, 0.0, 10.0),  # image shear (+/- deg)
                'perspective': (0, 0.0, 0.001),  # image perspective (+/- fraction), range 0-0.001
                'flipud': (1, 0.0, 1.0),  # image flip up-down (probability)
                'fliplr': (0, 0.0, 1.0),  # image flip left-right (probability)
                'mosaic': (1, 0.0, 1.0),  # image mixup (probability)
                'mixup': (1, 0.0, 1.0),  # image mixup (probability)
                'copy_paste': (1, 0.0, 1.0)}  # segment copy-paste (probability)

        #errors参数是用来指定编码和解码错误时处理方法。 errors='ignore'，忽略错误
        with open(opt.hyp, errors='ignore') as f:
            # 加载yaml超参数  # 载入初始超参
            hyp = yaml.safe_load(f)  # load hyps dict
            if 'anchors' not in hyp:  # anchors commented in hyp.yaml
                hyp['anchors'] = 3
        opt.noval, opt.nosave, save_dir = True, True, Path(opt.save_dir)  # only val/save final epoch
        # ei = [isinstance(x, (int, float)) for x in hyp.values()]  # evolvable indices
        # 保存进化的超参数列表   # 超参进化后文件保存地址
        evolve_yaml, evolve_csv = save_dir / 'hyp_evolve.yaml', save_dir / 'evolve.csv'
        if opt.bucket:  #谷歌云盘bucket 一般用不到
            os.system(f'gsutil cp gs://{opt.bucket}/evolve.csv {evolve_csv}')  # download evolve.csv if exists
        """
               遗传算法调参：遵循适者生存、优胜劣汰的法则，即寻优过程中保留有用的，去除无用的。
               遗传算法需要提前设置4个参数: 群体大小/进化代数/交叉概率/变异概率

               """
        """
        类似GA算法
                    使用遗传算法进行参数进化 默认是进化300代
                    这里的进化算法是：根据之前训练时的hyp来确定一个base hyp再进行突变；
                    如何根据？通过之前每次进化得到的results来确定之前每个hyp的权重
                    有了每个hyp和每个hyp的权重之后有两种进化方式；
                        1.single:根据每个hyp的权重随机选择一个之前的hyp作为base hyp，random.choices(range(n), weights=w)
                        2.weighted:根据每个hyp的权重对之前所有的hyp进行融合获得一个base hyp，(x * w.reshape(n, 1)).sum(0) / w.sum()
                    evolve.txt会记录每次进化之后的results+hyp
                    每次进化时，hyp会根据之前的results进行从大到小的排序，再根据fitness函数计算之前每次进化得到的hyp的权重，再确定哪一种进化方式，从而进行进化。
                """
        for _ in range(opt.evolve):  #  默认选择进化300代
            if evolve_csv.exists():  # if evolve.csv exists: select best hyps and mutate（变异、突变）
                # Select parent(s)
                # 选择超参进化方式 只用single和weighted两种
                parent = 'single'  # parent selection method: 'single' or 'weighted'
                # 加载evolve.txt文件
                x = np.loadtxt(evolve_csv, ndmin=2, delimiter=',', skiprows=1)
                # 选取进化结果代数  选取至多前五次进化的结果
                n = min(5, len(x))  # number of previous results to consider
                #通过-fitnes计算x
                x = x[np.argsort(-fitness(x))][:n]  # top n mutations（前n个突变）
                # 根据resluts计算hyp权重
                w = fitness(x) - fitness(x).min() + 1E-6  # weights (sum > 0)
                # 根据不同进化方式获得base hyp
                if parent == 'single' or len(x) == 1:
                    # x = x[random.randint(0, n - 1)]  # random selection
                    x = x[random.choices(range(n), weights=w)[0]]  # weighted selection 随机选择
                elif parent == 'weighted':
                    x = (x * w.reshape(n, 1)).sum(0) / w.sum()  # weighted combination 加权融合

                # Mutate 超参进化  获取突变初始值
                # Mutate
                mp, s = 0.8, 0.2  # mutation probability, 突变概率, sigma
                npr = np.random #随机数
                #随机种子，即若括号内的数字不同，生成的随机数将不同于，之前的(time.time())的运行结果。确实每次的都不同
                npr.seed(int(time.time()))
                # 获取突变初始值
                g = np.array([meta[k][0] for k in hyp.keys()])  # gains 0-1
                ng = len(meta)
                v = np.ones(ng)#对超参数进行初始化为1
                # 设置突变
                while all(v == 1):  # mutate until a change occurs (prevent duplicates)
                    #如果是v=1则继续突变，直到会有改变
                    v = (g * (npr.random(ng) < mp) * npr.randn(ng) * npr.random() * s + 1).clip(0.3, 3.0)
                # 将突变添加到base hyp上
                # [i+7]是因为x中前七个数字为results的指标(P, R, mAP, F1, test_losses=(box, obj, cls))，之后才是超参数hyp
                for i, k in enumerate(hyp.keys()):  # plt.hist(v.ravel(), 300)
                    #超参数hyp*v[i]进行突变
                    hyp[k] = float(x[i + 7] * v[i])  # mutate

            # Constrain to limits 限制超参再规定范围
            for k, v in meta.items():
                hyp[k] = max(hyp[k], v[1])  # lower limit
                hyp[k] = min(hyp[k], v[2])  # upper limit
                hyp[k] = round(hyp[k], 5)  # significant digits

            # Train mutation  训练 使用突变后的参超 测试其效果
            results = train(hyp.copy(), opt, device, callbacks)
            callbacks = Callbacks()

            # Write mutation results
            # 将结果写入results 并将对应的hyp写到evolve.txt evolve.txt中每一行为一次进化的结果
            # 每行前七个数字 (P, R, mAP, F1, test_losses(GIOU, obj, cls)) 之后为hyp
            # 保存hyp到yaml文件
            print_mutation(results, hyp.copy(), save_dir, opt.bucket)

        # Plot results
        # 将结果可视化 / 输出保存信息
        plot_evolve(evolve_csv)
        LOGGER.info(f'Hyperparameter evolution finished {opt.evolve} generations\n'
                    f"Results saved to {colorstr('bold', save_dir)}\n"
                    f'Usage example: $ python train.py --hyp {evolve_yaml}')


def run(**kwargs):
    """
             # 执行这个脚本/ 调用train函数 / 开启训练
    # Usage: import train; train.run(data='coco128.yaml', imgsz=320, weights='yolov5m.pt')
        """
    # Usage: import train; train.run(data='coco128.yaml', imgsz=320, weights='yolov5m.pt')
    opt = parse_opt(True)
    for k, v in kwargs.items():
        # setattr() 赋值属性，属性不存在则创建一个赋值
        setattr(opt, k, v)
    main(opt)
    return opt

#------------------（2）从主函数开始执行。----------------------------------------
#当运行这个py文件时，会首先执行这里
#__name_：即当前文件名字
if __name__ == "__main__":
    opt = parse_opt() # 返回值：所有的参数
    main(opt)# 将参数又传给主函数 main
