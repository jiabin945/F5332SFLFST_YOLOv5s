import torch
import torch.nn as nn
import torchvision
import torch.backends.cudnn as cudnn
import torch.optim
import os
import sys
import argparse
import time
import DCE.dce_model
import numpy as np
from torchvision import transforms
from PIL import Image
import glob
import time
from tqdm import tqdm
#注：如果执行主目录下的的low...，是这样的
os.environ['CUDA_VISIBLE_DEVICES'] = '0'
#微光增强
wrong_image_path = []
def lowlight(DCE_net, image_path):
	#比例因子
	scale_factor = 12
	data_lowlight = Image.open(image_path)#打开的图片是PIL类型，转成RGB模式，三通道的

 
	#把数据列表装换为数组，再归一化处理
	# data_lowlight = (np.asarray(data_lowlight)/255.0)
	try:
		data_lowlight = (np.asarray(data_lowlight) / 255.0)
	except:
		print(image_path)
		wrong_image_path.append(image_path)
		return 0

	# 把数组转化内浮点型张量
	data_lowlight = torch.from_numpy(data_lowlight).float()

	h=(data_lowlight.shape[0]//scale_factor)*scale_factor # 1080
	w=(data_lowlight.shape[1]//scale_factor)*scale_factor # 1920
	data_lowlight = data_lowlight[0:h,0:w,:]
	# 3 x 1080 x 1920
	data_lowlight = data_lowlight.permute(2,0,1)
	#unsqueeze(0)增加维数，在第1维(下标从0开始)上增加 1,变成 (1,3,1080,1920)
	#https://blog.csdn.net/flysky_jay/article/details/81607289
	data_lowlight = data_lowlight.cuda().unsqueeze(0)


	enhanced_image,params_maps = DCE_net(data_lowlight)

	image_path = image_path.replace('images','imagess')

	result_path = image_path
	# 以‘/ ’为分割符，把最后一段替换为 ' '
	if not os.path.exists(image_path.replace('/'+image.split("/")[-1],'')):
		#os.makedirs() 方法用于递归创建目录，为每一张训练集图片创建/NAT2021-train/train_clip_enhanced/空目录用于存放增强后的图片
		os.makedirs(image_path.replace('/'+image_path.split("/")[-1],''))
	# import pdb;pdb.set_trace()
	#torchvision.utils.save_image直接保存tensor为图片
	torchvision.utils.save_image(enhanced_image, result_path)


if __name__ == '__main__':
	with torch.no_grad():

		filePath = '/media/king/243a6102-5ce5-4fea-8f08-27b212d33476/jiabin/jb_project/datasets/NEU-DET/NEU-DET/IMAGES' # the path of original imgs
		#os.listdir()返回指定路径下的文件和文件夹列表。
		file_list = os.listdir(filePath)
		#文件夹名 按字符串排序
		file_list.sort()
		scale_factor = 12
		#对dce_model模块里面的 enhance_net_nopool实例化对象DCE_net
		DCE_net =DCE.dce_model.enhance_net_nopool(scale_factor).cuda()
		#在测试模型时在前面使用
		DCE_net.eval()
		#torch.load_state_dict()函数就是用于将预训练的参数权重加载到新的模型之中
		#DCE_net.load_state_dict(torch.load('../DCE/Epoch99.pth'))
		DCE_net.load_state_dict(torch.load('DCE/Epoch99.pth'))
		#tqdm作用就是在终端上出现一个进度条，使得代码进度可视化,并循环文件列表里面的文件名
		for file_name in tqdm(file_list):
			#glob.glob()函数返回一个某一种文件夹下面的某一类型文件路径列表  返回一级目录的查找结果
			#test_list:文件夹或者文件对应路径+文件夹/文件名
			test_list = glob.glob(filePath+"/*")
			for image in test_list:
				#os.path.exists()就是判断括号里的文件是否存在的意思，括号内的可以是文件路径。创建了一个新的路径
				#置换目标字符串.replace('要被置换对象', '置换后新的字符'，[，次数])
				if not os.path.exists(image.replace('IMAGES','imagess')):
					lowlight(DCE_net, image)