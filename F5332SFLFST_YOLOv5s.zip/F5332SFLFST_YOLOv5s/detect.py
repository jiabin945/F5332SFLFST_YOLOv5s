# YOLOv5 🚀 by Ultralytics, GPL-3.0 license
#python命令行（detect）：--source ./inference/images/zidane.jpg --weights weights/yolov5s.pt --conf 0.4
#python detect.py --classes 0
"""
Run inference on images, videos, directories, streams, etc.

Usage - sources:
    $ python path/to/detect.py --weights yolov5s.pt --source 0              # webcam
                                                             img.jpg        # image
                                                             vid.mp4        # video
                                                             path/          # directory
                                                             path/*.jpg     # glob
                                                             'https://youtu.be/Zgi9g1ksQHc'  # YouTube
                                                             'rtsp://example.com/media.mp4'  # RTSP, RTMP, HTTP stream

Usage - formats:
    $ python path/to/detect.py --weights yolov5s.pt                 # PyTorch
                                         yolov5s.torchscript        # TorchScript
                                         yolov5s.onnx               # ONNX Runtime or OpenCV DNN with --dnn
                                         yolov5s.xml                # OpenVINO
                                         yolov5s.engine             # TensorRT
                                         yolov5s.mlmodel            # CoreML (MacOS-only)
                                         yolov5s_saved_model        # TensorFlow SavedModel
                                         yolov5s.pb                 # TensorFlow GraphDef
                                         yolov5s.tflite             # TensorFlow Lite
                                         yolov5s_edgetpu.tflite     # TensorFlow Edge TPU
"""
# 执行第一步：
# 导入下载好的模块
import argparse # python的命令行解析的模块，内置于python，不需要安装    可以让我们直接在命令行中就可以向程序中传入参数并让程序运行
import os
import sys   # sys系统模块 包含了与Python解释器和它的环境有关的函数。
from pathlib import Path   # Path将str转换为Path对象 使字符串路径易于操作的模块

import cv2  # opencv模块
import torch  # pytorch模块
import torch.backends.cudnn as cudnn # cuda模块

#path().resolve：将路径设置为绝对路径，解析路径上的所有符号链接，并将其规范化（例如在Windows下将斜杠转换为反斜杠）。
# __file__:指的是当前文件(即detect.py)，.resolve():获取绝对路径：/home/lhcz/sdb/jiabin/jb_project/yolov5-6.1/detect.py
FILE = Path(__file__).resolve()
#/home/lhcz/sdb/jiabin/jb_project/yolov5-6.1
ROOT = FILE.parents[0]  # YOLOv5 root directory # .parents():当前文件的路径的父目录；D:\模型轻量化\yolov5-6.1
#假如当前项目不在该路径中,就无法运行其中的模块,所以就需要加载路径
if str(ROOT) not in sys.path:  # sys.path是即当前python环境可以运行的路径，是一个列表list
    # 把ROOT（即当前项目v5）添加到运行路径上
    sys.path.append(str(ROOT))  # sys.path.append():添加相关路径，但在退出python环境后自己添加的路径就会消失
#os.path.relpath是求相对路径的（把绝对路径转化成相对路径，第一个参数那个相对于后面第二个参数那个的相对路径）,本例得到yolov5-6.1
#Path.cwd()确定当前所在的文件夹，即当前文件所在的位置，例如：#/home/lhcz/sdb/jiabin/jb_project，防止路径在ROOT前面，把这个补到后面weights等文件的路径中
#这一部分的主要作用有两个:
#将当前项目添加到系统路径上,以使得项目中的模块可以调用.  2将当前项目的相对路径保存在ROOT中,便于寻找项目中的文件
ROOT = Path(os.path.relpath(ROOT, Path.cwd()))  # relative # 将绝对路径转变为相对目录，后面会用到
'''
 先要确保模块的查询路径在sys.path中，这样下面的如models.common在导入的时候才会根据这个路径列表去导包
 否则models.common不知道从哪里导入
'''
# ----------------- 1导入自定义的其他包 -------------------
#这些都是用户自定义的库，由于上一步已经把路径加载上了，所以现在可以导入，这个顺序不可以调换。
from models.common import DetectMultiBackend
from utils.datasets import IMG_FORMATS, VID_FORMATS, LoadImages, LoadStreams
from utils.general import (LOGGER, check_file, check_img_size, check_imshow, check_requirements, colorstr,
                           increment_path, non_max_suppression, print_args, scale_coords, strip_optimizer, xyxy2xywh)
from utils.plots import Annotator, colors, save_one_box
from utils.torch_utils import select_device, time_sync

#该标注使得方法中所有计算得出的tensor的requires_grad都自动设置为False，也就是说不会求梯度，可以加快预测效率，减小资源消耗
#本来就是测试不需要梯度
@torch.no_grad()  # 一个上下文管理器，被该语句wrap起来的部分将不会track梯度(测试时不需要，训练时需要)
#这里仅把一些必要的参数注释了一下，其他参数在实际使用中可以使用默认值，如果识别效果不好可以
# 考虑修改参数（但更可能是训练的问题而不是这些参数的问题）
def run( # 事先训练完成的权重文件，比如yolov5s.pt,假如使用官方训练好的文件（比如yolov5s）,则会自动下载
        weights=ROOT / 'yolov5s.pt',  # model.pt path(s)
        source=ROOT / 'data/images',  # 预测时的输入数据，可以是文件/路径/URL/glob, 输入是0的话调用摄像头作为输入
        data=ROOT / 'data/coco128.yaml',  # 数据集文件
        imgsz=(640, 640),  # inference size (height, width)# 预测时的放缩后图片大小(因为YOLO算法需要预先放缩图片), 两个值分别是height, width
        conf_thres=0.25,  # 置信度阈值, 高于此值的bounding_box才会被保留
        iou_thres=0.45,  # NMS IOU threshold  # IOU阈值,高于此值的bounding_box才会被保留
        max_det=1000,  # maximum detections per image
        device='',  # 所使用的GPU编号，如果使用CPU就写cpu
        view_img=False,  # 是否在推理时预览图片
        save_txt=False,  #是否将结果保存在txt文件中
        save_conf=False,  # save confidences in --save-txt labels 是否将结果中的置信度保存在txt文件中
        save_crop=False,  # save cropped prediction boxes 是否保存裁剪后的预测框
        nosave=False,  # do not save images/videos 是否保存预测后的图片/视频
        classes=None,  # filter by class: --class 0, or --class 0 2 3 # 过滤指定类的预测结果
        agnostic_nms=False,  # class-agnostic NMS # 如为True,则为class-agnostic. 否则为class-specific
        augment=False,  # augmented inference
        visualize=False,  # visualize features
        update=False,  # update all models
        project=ROOT / 'runs/detect',  # save results to project/name  # 推理结果保存的路径
        name='exp',  # save results to project/name # 结果保存文件夹的命名前缀
        exist_ok=False,  # existing project/name ok, do not increment # True: 推理结果覆盖之前的结果 False: 推理结果新建文件夹保存,文件夹名递增
        line_thickness=1,  # 绘制Bounding_box的线宽度
        hide_labels=False,  # hide labels
        hide_conf=False,  # hide confidences
        half=False,  # use FP16 half-precision inference  是否使用半精度推理（节约显存）
        dnn=False,  # use OpenCV DNN for ONNX inference
        ):

    # --------------------run--第1步：对传入的source参数进行一个判断--------------------------------
    '''
    就是对传入的source参数进行解析：
    第一行: 解析命令行执行python delect.py --source ./inference/images/zidane.jpg时所传入的参数，
           就是获取图片路径啦，路径要始终是字符串类型,所以str()强制转换；
    第二行：判断是否要保存预测后图片
          not nosave=not flase=true(nosave是上面传入进来的参数，nosave=False)
          not source.endswith('.txt')=flase 传入的参数是否是txt格式，传入的是.jpg格式，显然不是
          所以图片是否保存标志位：save_img=true
    第三行：判断source是不是视频/图像文件路径，例如jpg文件  is_file=true
           Path(source).suffix[1:] 判断路径的后缀
           而IMG_FORMATS 和 VID_FORMATS两个变量保存的是所有的视频和图片的格式后缀。
    第四行：判断传入的地址是不是网络流，是不是一个网络地址（链接）
           先转换为小写，再判断开头是否以rtsp://', 'rtmp://', 'http://', 'https://开头
    第五行：# 判断是source是否是摄像头
    webcam =flase
           source.isnumeric() 地址是不是数字 如果是--source 0，后面是0，表示打开电脑摄像头
    第六行：如果是网络流地址 或者是文件 就去相应的地址下载图片
    '''
    #获取图片路径，路径要始终是字符串类型,所以str()强制转换；
    source = str(source)#'./inference/images/zidane.jpg'
    #判断是否要保存预测后图片（传入的是.jpg格式，显然不是所以图片是否保存标志位：save_img=true）
    save_img = not nosave and not source.endswith('.txt')  # save inference images
    is_file = Path(source).suffix[1:] in (IMG_FORMATS + VID_FORMATS)
    # 判断source是否是链接
    is_url = source.lower().startswith(('rtsp://', 'rtmp://', 'http://', 'https://'))
    # 判断是source是否是摄像头
    webcam = source.isnumeric() or source.endswith('.txt') or (is_url and not is_file)
    # 如果source是一个指向图片/视频的链接,则下载输入数据
    if is_url and is_file:
        source = check_file(source)  # download


    # ----------------------run--第2步：新建一个保存结果的文件夹-----------------------------
    #即生成保存结果的路径，然后根据当前生成的路径创建文件夹
    '''
        第一行：project:ROOT / 'runs/detect'为传入的参数，name:exp为传入的参数 将两个拼接起来作为保存的地址
               其中父目录：ROOT=D:\模型轻量化\yolov5-6.1，在一开始我们就指定好了
               所以完整的路径： D:\模型轻量化\yolov5-6.1  +  \ runs\detect    +\exp
               increment_path为增量式路径，简单来说，第一次运行的预测结果保存在exp中，第二次运行结果保存在exp2中，以此类推
        '''
    # 文件夹命名以及根据路径创建文件夹
    # save_dir是保存运行结果的文件夹名，是通过递增的方式来命名的。
    #例：runs/detect/expx
    save_dir = increment_path(Path(project) / name, exist_ok=exist_ok)  # increment run
    # 根据前面生成的路径创建文件夹
    (save_dir / 'labels' if save_txt else save_dir).mkdir(parents=True, exist_ok=True)  # make dir

    # 加载模型
    # -------------------------run--第3步：加载模型的权重----------------------------------

    # 第一行；选择运行的设备 GPU or cpu
    # 第二行;选择学习框架，例如：PyTorch TorchScript TensorRT等，可以按住Ctrl单击函数进入查看
    #     传入weights训练权重为yolov5s.pt，设备，
    # 第三行：读取模型属性：步长stride=32  类型名names=80 模型类型pt=true,表示是PyTorch类型
    # stride：推理时所用到的步长，默认为32， 大步长适合于大目标，小步长适合于小目标
    #names：保存推理结果名的列表，比如默认模型的值是['person', 'bicycle', 'car', ...]
    # pt: 加载的是否是pytorch模型（也就是pt格式的文件）
    # JIT: 是一种概念，全称是 Just In Time Compilation，中文译为「即时编译」，是一种程序优化的方法，
    # onnx:ONNX是一种针对机器学习所设计的开放式的文件格式,用于存储训练好的模型
    # 推理引擎：YOLO采用的是wts权重文件,在tensorRT推理过程中需要序列化生成engine文件,而engine文件是GPU框架绑定的,所以针对不同的显卡需要本地序列化一次
    # 第四行:核实图片的尺寸大小是否是步长32的倍数，这里是640*640,所以imgsz =640，不用修改，否则会给一个合适的值

    
    #3.1用什么硬件设备
    # select_device方法定义在utils.torch_utils模块中，返回值是torch.device对象，也就是推理时所使用的硬件资源。输入值如果是数字，表示GPU序号。也可是输入‘cpu’，表示使用CPU训练，默认是cpu
    device = select_device(device)
    # DetectMultiBackend定义在models.common模块中，是我们要加载的网络，其中weights参数就是输入时指定的权重文件（比如yolov5s.pt，pt代表pytorch类型）
    #3.2用什么Float32的模型
    #DetectMultiBackend:加载模型的方法
    model = DetectMultiBackend(weights, device=device, dnn=dnn, data=data)
    #3.3读取模型属性  # stride: 模型最大的下采样率 [8, 16, 32] 所有stride一般为32
    #感觉pt, .jit, onnx,engine是类型的意思
    stride, names, pt, jit, onnx, engine = model.stride, model.names, model.pt, model.jit, model.onnx, model.engine
    #核实图片的尺寸大小是否是步长32的倍数，不是就调整能整除的并返回（因为用的图片640*640，所以不用改变）
    imgsz = check_img_size(imgsz, s=stride)  # check image size

    # Half
    # 如果不是cpu（即gpu），则使用半精度 Float16 推理（图片半精度，模型半精度）
    #half=half & (pt or jit or onnx or engine) and device.type != 'cpu'  此代码等号右边前面为f,后面为t，则与后为f
    half &= (pt or jit or onnx or engine) and device.type != 'cpu'  # FP16 supported on limited backends with CUDA
    #3.4 调整模型
    # 是否将模型从float32 -> float16  加速推理
    if pt or jit:
        model.model.half() if half else model.model.float()

    # Dataloader
    # ----------------------------run--第4步：加载待预测的图片-----------------------

    # Dataloader
    if webcam:# webcam =flase 不执行 # 使用摄像头作为输入 # 一般不会使用webcam模式从网页中获取数据
        view_img = check_imshow() # 检测
        # 该设置可以加速预测
        cudnn.benchmark = True  # set True to speed up constant image size inference
        # 加载输入数据流  输入数据源 image_size 图片识别前被放缩的大小， stride：识别时的步长，
        ## auto的作用可以看utils.augmentations.letterbox方法，它决定了是否需要将图片填充为正方形，如果auto=True则不需要
        dataset = LoadStreams(source, img_size=imgsz, stride=stride, auto=pt)
        bs = len(dataset)  # batch_size
    else:  # 直接执行这里
        # 一般是直接从source文件目录下直接读取图片或者视频数据
        # 该函数主要负责的是图片或者视频的处理，实例化LoadImages类为dataset对象
        #auto的作用可以看utils.augmentations.letterbox方法，它决定了是否需要将图片填充为正方形，如果auto=True则不需要
        dataset = LoadImages(source, img_size=imgsz, stride=stride, auto=pt)
        bs = 1  # batch_size=1 表示每次输入一张图片
    # 通过不同的输入源来设置不同的数据加载方式
    # 用于保存视频,前者是视频路径,后者是一个cv2.VideoWriter对象
    vid_path, vid_writer = [None] * bs, [None] * bs

    # Run inference
    # -----------------------------run--第5步：预测推理部分---------------------------
    # warmup：GPU热身环节，随便给一张图片，先跑一遍
    # 使用空白图片（零矩阵）预先用GPU跑一遍预测流程，可以加速预测
    model.warmup(imgsz=(1 if pt else bs, 3, *imgsz), half=half)  # warmup
    #dt: 存储每一步骤的耗时 seen: 已经处理完了多少帧图片
    dt, seen = [0.0, 0.0, 0.0], 0
    ''' 
        # path要预测的图片/视频的路径
        im表示resize(放缩) + pad后的图片例如[3,384,640]（因为原图zidane720*1280,
        原则：长边变为640，这里变为原来的一半，短边同比例缩放到360，但是要为32的整数倍，向上取整
        为384，多出来的24用填充）
        im0s表示原图例如[3,1080,810]
        vid_cap=none  当读取图片时为None, 读取视频时为视频源
        s为打印信息，运行时候输出第几张图片，一共有几张，图片路径 时间
        '''
    #'image 1/1 /home/lhcz/sdb/jiabin/jb_project/yolov5-6.1/inference/images/zidane.jpg: '
    for path, im, im0s, vid_cap, s in dataset:

        # 5.1、对每张图片 / 视频进行前向推理
        t1 = time_sync()  # 获取系统当前时间

        # 5.2、处理每一张图片/视频的格式
        # 对图片进行预处理
        im = torch.from_numpy(im).to(device)# im resize后的图片，[3,640,480] 转成PyTorch支持的格式，然后to转到GPU上
        #判断模型有没有用到半精度   # 把输入从整型转化为半精度/全精度浮点数
        im = im.half() if half else im.float()  # uint8 to fp16/32
        #单色图像的每个像素有自己的辉度。0通常表示黑，而最大值255通常表示白色。
        im /= 255  # 0 - 255 to 0.0 - 1.0  所有像素点/255，归一化操作（这是图像表示方法的的规范，使用浮点数就要归一化）
        if len(im.shape) == 3: #扩增张量为 [1,3,640,480]  # 因为输入网络的图片需要是4为的 [batch_size, channel, w, h]
            #这个是通过插入None伪装一个axis达到增加tensor维度。默认在前面扩展
            im = im[None]  # expand for batch dim（比3.0版本的unsqueeze好）
        t2 = time_sync() # 获取系统当前时间
        dt[0] += t2 - t1 # 上面这个部分耗时保存

        # Inference
        '''
                第一行：visualize默认Flase,如果是True，则在模型推断的过程中将特征图保存下来，保存在runs文件夹中
                第二行：augment，表示是否要进行数据增强，增强会耗时
                       这两个参数传入到模型中去
                        然后得到 pred，其大小为torch.Size([1, 15120, 85]) ，15120个框
                        18900表示预测框的个数，85表示（x1,y1,x2,y2,c，80个类别的概率） 对应左上角以及右下角坐标
                '''
        visualize = increment_path(save_dir / Path(path).stem, mkdir=True) if visualize else False
        # 推理结果，pred保存的是所有的bound_box的信息，
        """
                前向传播 返回pred的shape是(1, num_boxes, 5+num_class)
                h,w为传入网络图片的高和宽。注意dataset在检测时使用了矩形推理，所以这里h不一定等于w（长边会变成640，短边同比例缩放，不是32整数倍则向上取整）
                num_boxes = (h/32 * w/32 + h/16 * w/16 + h/8 * w/8)*3（即对三个特征层计算有多少个网格。每个网格有三个anchors，所以乘以3）
                例如：图片大小720,1280-->15120个boxes = (20*12 + 40*24 + 80*48=5040)*3
                pred[..., 0:4]为预测框坐标; 预测框坐标为xywh(中心点+宽高)格式
                pred[..., 4]为objectness置信度得分
                pred[..., 5:-1]为分类概率结果
                """
        pred = model(im, augment=augment, visualize=visualize)
        t3 = time_sync()
        dt[1] += t3 - t2

        #  5.3、nms除去多余的框-NMS
        """
                pred: 前向传播的输出
                conf_thres: 置信度阈值
                iou_thres: iou阈值
                classes: 是否只保留特定的类别
                agnostic_nms: 进行nms是否也去除不同类别之间的框
                经过nms之后，预测框格式：xywh-->xyxy(左上角右下角)
                pred是一个列表list[torch.tensor]，长度为NMS后的目标框的个数
                max_det: 每张图片的最大目标个数 默认1000
                每一个torch.tensor的shape为(num_boxes, 6),内容为box(4个值)+conf+cls
                """
        #例如：torch.Size([3, 6])，即zidane图片经过nms后,框由15120变为3个框，6为
        #内容为box(4个值xyxy)+conf+cls
        pred = non_max_suppression(pred, conf_thres, iou_thres, classes, agnostic_nms, max_det=max_det)
        dt[2] += time_sync() - t3  # 记录nms该阶段耗时


        # Second-stage classifier (optional) # 添加第二级分类，默认不使用
        # pred = utils.general.apply_classifier(pred, classifier_model, im, im0s)

        # 5.4、后续保存或者打印预测信息
        # 对每张图片进行处理  将pred(相对img_size 640)映射回原图img0 size
        # Process predictions 过程预测
        #i:第几个框 det:第几个框的信息   i:0  det:torch.Size([3, 6]),其中3：3个框 6：box信息（xyxy+置信度+类别）
        for i, det in enumerate(pred):  # per image # 每次迭代处理一张图片，
            seen += 1
            if webcam:  # batch_size >= 1
                # 如果输入源是webcam（网页）则batch_size不为1 取出dataset中的一张图片
                p, im0, frame = path[i], im0s[i].copy(), dataset.count
                s += f'{i}: '
            else:
                # 但是大部分我们一般都是从LoadImages流读取本都文件中的照片或者视频 所以batch_size=1
                # p: 当前图片/视频的绝对路径 如 D:\模型轻量化\yolov5-6.1\inference\images\zidane.jpg
                # s: 输出信息 初始为 ''
                # im0: 原始图片 letterbox + pad 之前的图片
                # frame: 初始为0  可能是当前图片属于视频中的第几帧？
                p, im0, frame = path, im0s.copy(), getattr(dataset, 'frame', 0)

            # 当前图片路径 如'/home/lhcz/sdb/jiabin/jb_project/yolov5-6.1/inference/images/zidane.jpg'
            p = Path(p)  # to Path
            ## 图片/视频的保存路径例如：'runs/detect/100轮+YOLOV6.1原型结果2/zidane.jpg'
            #save_dir：runs/detect/100轮+YOLOV6.1原型结果2  p.name：zidane.jpg
            save_path = str(save_dir / p.name)  # im.jpg  # 推理结果图片保存的路径
            # txt文件(保存预测框坐标)保存路径 'runs/detect/exp/labels/zidane'
            txt_path = str(save_dir / 'labels' / p.stem) + ('' if dataset.mode == 'image' else f'_{frame}')  # im.txt
            # print string  输出显示推理前裁剪后的图像尺寸
            #例如：'image 1/1 /home/lhcz/sdb/jiabin/jb_project/yolov5-6.1/inference/images/zidane.jpg: 384x640 '   其中380*640是在这句代码中加的
            s += '%gx%g ' % im.shape[2:]  # print string
            #  normalization gain gn = [w, h, w, h]  用于后面的归一化：tensor([1280,  720, 1280,  720])
            # 得到原图的宽和高
            gn = torch.tensor(im0.shape)[[1, 0, 1, 0]]  # normalization gain whwh
            # 如果save_crop的值为true， 则将检测到的bounding_box单独保存成一张图片
            imc = im0.copy() if save_crop else im0  # for save_crop
            # 得到一个绘图的类，类中预先存储了原图、线条宽度、类名
            annotator = Annotator(im0, line_width=line_thickness, example=str(names))
            #det:第几个框的信息【3,6】:3是三框，6为框信息（xyxy+置信度+类别）
            #本例：384*640-》720*1280，此时坐标为xyxy格式
            if len(det):
                # Rescale boxes from img_size to im0 size
                # scale_coords：将标注的bounding_box大小调整为和原图一致（因为训练时原图经过了放缩）
                det[:, :4] = scale_coords(im.shape[2:], det[:, :4], im0.shape).round()

                # 打印出所有的预测结果 比如1 person（检测出一个人）
                # 输出信息s + 检测到的各个类别的目标个数
                #unique:去重并按元素由大到小返回一个新的无元素重复的元组或者列表
                #zidane图片中，第一次循环，c=0(即类别人)，n=2（有两个）；第二次循环，c=27(即类别领带)，n=2（有1个）
                for c in det[:, -1].unique():
                    n = (det[:, -1] == c).sum()  # 每个类的额检测个数
                    #s原来是：#例如：'image 1/1 /home/lhcz/sdb/jiabin/jb_project/yolov5-6.1/inference/images/zidane.jpg: 384x640 '
                    #后来：'image 1/1 /home/lhcz/sdb/jiabin/jb_project/yolov5-6.1/inference/images/zidane.jpg: 384x640 2 persons, 1 tie, '
                    #即把数量n和类别名字添加到s后面
                    s += f"{n} {names[int(c)]}{'s' * (n > 1)}, "  # add to string

                # Write results
                # 保存预测信息: txt、img0上画框、crop_img
                #reversed：即从后往前画，先领带后人
                for *xyxy, conf, cls in reversed(det):
                    # 将每个图片的预测信息分别存入save_dir/labels下的xxx.txt中 每行: class_id+score+xywh
                    if save_txt:  # Write to file # 保存txt文件
                        # 将xyxy(左上角 + 右下角)格式转换为xywh(中心的 + 宽高)格式 并除以gn(whwh)做归一化 转为list再保存
                        xywh = (xyxy2xywh(torch.tensor(xyxy).view(1, 4)) / gn).view(-1).tolist()  # normalized xywh
                        # line的形式是： ”类别 x y w h“，假如save_conf为true，则line的形式是：”类别 x y w h 置信度“
                        line = (cls, *xywh, conf) if save_conf else (cls, *xywh)  # label format
                        # 写入对应的文件夹里，路径默认为“runs\detect\exp*\labels”
                        with open(txt_path + '.txt', 'a') as f:
                            f.write(('%g ' * len(line)).rstrip() % line + '\n')

                    # 在原图上画框 + 将预测到的目标剪切出来 保存成图片 保存在save_dir/crops下
                    if save_img or save_crop or view_img:  # Add bbox to image
                        c = int(cls)  # integer class # 类别标号
                        ## 类别名
                        label = None if hide_labels else (names[c] if hide_conf else f'{names[c]} {conf:.2f}')
                        # 绘制边框
                        annotator.box_label(xyxy, label, color=colors(c, True))
                        # 如果需要就将预测到的目标剪切出来 保存成图片 保存在save_dir/crops下
                        if save_crop:
                            save_one_box(xyxy, imc, file=save_dir / 'crops' / names[c] / f'{p.stem}.jpg', BGR=True)

            # Stream results
            # 是否需要显示我们预测后的结果  img0(此时已将pred结果可视化到了img0中)
            im0 = annotator.result()
            if view_img:  #true则把预测后图片显示出来
                cv2.imshow(str(p), im0)
                cv2.waitKey(1)  # 1 millisecond

            # Save results (image with detections)
            # 是否需要保存图片或视频（检测后的图片/视频 里面已经被我们画好了框的） img0
            if save_img:  # 如果save_img为true,则保存绘制完的图片
                if dataset.mode == 'image':  # 如果是图片,则保存
                    #把im0写入到输出的路径save_path中
                    cv2.imwrite(save_path, im0)
                else:  # 'video' or 'stream'  # 如果是视频或者"流"
                    # vid_path[i] != save_path,说明这张图片属于一段新的视频,需要重新创建视频文件
                    if vid_path[i] != save_path:  # new video
                        vid_path[i] = save_path
                        if isinstance(vid_writer[i], cv2.VideoWriter):
                            vid_writer[i].release()  # release previous video writer
                        if vid_cap:  # video
                            fps = vid_cap.get(cv2.CAP_PROP_FPS)
                            w = int(vid_cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                            h = int(vid_cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                        else:  # stream
                            fps, w, h = 30, im0.shape[1], im0.shape[0]
                        save_path = str(Path(save_path).with_suffix('.mp4'))  # force *.mp4 suffix on results videos
                        vid_writer[i] = cv2.VideoWriter(save_path, cv2.VideoWriter_fourcc(*'mp4v'), fps, (w, h))
                    vid_writer[i].write(im0)
                    # 以上的部分是保存视频文件

        # Print time (inference-only)
        # 打印耗时
        LOGGER.info(f'{s}Done. ({t3 - t2:.3f}s)')

    # ===================================== 6、推理结束, 保存结果, 打印信息 =========
    # Print results
    # 平均每张图片所耗费时间
    #例如：t:(1778.6502838134766, 1806.0016632080078, 1314.6226406097412)
    t = tuple(x / seen * 1E3 for x in dt)  # speeds per image
    LOGGER.info(f'Speed: %.1fms pre-process, %.1fms inference, %.1fms NMS per image at shape {(1, 3, *imgsz)}' % t)

    # 保存预测的label信息 xywh等   save_txt
    if save_txt or save_img:
        s = f"\n{len(list(save_dir.glob('labels/*.txt')))} labels saved to {save_dir / 'labels'}" if save_txt else ''
        #Results saved to runs/detect/100轮+YOLOV6.1原型结果2
        LOGGER.info(f"Results saved to {colorstr('bold', save_dir)}{s}")
    if update:
        strip_optimizer(weights)  # update model (to fix SourceChangeWarning)


def parse_opt():
    """
            函数功能：设置opt参数
        """
    # 建立参数解析对象parser argparse:python的命令行解析的模块，内置于python，不需要安装    可以让我们直接在命令行中就可以向程序中传入参数并让程序运行
    parser = argparse.ArgumentParser()
    # 添加属性：给xx实例增加一个aa属性，如 xx.add_argument("aa")
    # nargs - 应该读取的命令行参数个数。*号，表示0或多个参数；+号表示1或多个参数。
    # action - 命令行遇到参数时的动作。action=‘store_true’，只要运行时该变量有传参就将该变量‘--xx’设为True。
    # weights: 模型的权重地址 默认 weights/best.pt  训练的权重
    #type:转换后的类型
    parser.add_argument('--weights', nargs='+', type=str, default=ROOT / 'yolov5s.pt', help='model path(s)')
    # source: 测试数据文件(图片或视频)的保存路径 默认data/images  也可以是‘0’（电脑自带摄像头），也可以rtsp等视频流
    # parser.add_argument('--source', type=str, default=ROOT / 'data/images', help='file/dir/URL/glob, 0 for webcam')
    #../:当前文件夹的上一级文件夹
    # parser.add_argument('--source', type=str, default='../datasets/jiabin/2', help='file/dir/URL/glob, 0 for webcam')
    parser.add_argument('--source', type=str, default='/media/king/243a6102-5ce5-4fea-8f08-27b212d33476/jiabin/jb_project/datasets/VisDrone/VisDrone2019-DET-test-dev/images', help='file/dir/URL/glob, 0 for webcam')
    #parser.add_argument('--data', type=str, default=ROOT / 'data/airplane.yaml', help='(optional) dataset.yaml path')
    # imgsz: 网络输入图片的大小 默认640
    parser.add_argument('--imgsz', '--img', '--img-size', nargs='+', type=int, default=[640], help='inference size h,w')
    # conf-thres: object置信度阈值 默认0.25
    parser.add_argument('--conf-thres', type=float, default=0.25, help='confidence threshold')
    # iou-thres: 做nms的iou阈值 默认0.45
    parser.add_argument('--iou-thres', type=float, default=0.45, help='NMS IoU threshold')
    # max-det: 每张图片最大的目标个数 默认1000
    parser.add_argument('--max-det', type=int, default=1000, help='maximum detections per image')
    # device: 设置代码执行的设备 cuda device, i.e. 0 or 0,1,2,3 or cpu
    parser.add_argument('--device', default='1', help='cuda device, i.e. 0 or 0,1,2,3 or cpu')
    # view-img: 是否展示预测之后的图片或视频 默认False
    parser.add_argument('--view-img', action='store_true', help='show results')
    # save-txt: 是否将预测的框坐标以txt文件格式保存 默认True 会在runs/detect/expn/labels下生成每张图片预测的txt文件
    parser.add_argument('--save-txt', action='store_true', help='save results to *.txt',default=True)
    # save-conf: 是否保存预测每个目标的置信度到预测tx文件中 默认True
    parser.add_argument('--save-conf', action='store_true', help='save confidences in --save-txt labels')
    # save-crop: 是否需要将预测到的目标从原图中扣出来 剪切好 并保存 会在runs/detect/expn下生成crops文件，将剪切的图片保存在里面  默认False
    parser.add_argument('--save-crop', action='store_true', help='save cropped prediction boxes')
    # nosave: 是否不要保存预测后的图片  默认False 就是默认要保存预测后的图片
    parser.add_argument('--nosave', action='store_true', help='do not save images/videos',default=True)
    # classes: 在nms中是否是只保留某些特定的类 默认是None 就是所有类只要满足条件都可以保留，保留特定比如0，1，2，3 命令行：--classes 0 1
    parser.add_argument('--classes', nargs='+', type=int, help='filter by class: --classes 0, or --classes 0 2 3')
    # agnostic-nms: 进行nms是否也除去不同类别之间的框 默认False
    parser.add_argument('--agnostic-nms', action='store_true', help='class-agnostic NMS')
    # augment: 预测是否也要采用数据增强 TTA   推理的时候进行多尺度，翻转等操作(TTA)推理
    parser.add_argument('--augment', action='store_true', help='augmented inference')
    #特征图是否可视化
    parser.add_argument('--visualize', action='store_true', help='visualize features')
    # update: 是否将optimizer从ckpt中删除  更新模型  默认False
    #如果为True，则对所有模型进行strip_optimizer操作，去除pt文件中的优化器等信息，默认为False
    parser.add_argument('--update', action='store_true', help='update all models')
    # project: 当前测试结果放在哪个主文件夹下 默认runs/detect
    parser.add_argument('--project', default=ROOT / 'runs/detect', help='save results to project/name')
    # name: 当前测试结果放在run/detect下的文件名  默认是exp
    parser.add_argument('--name', default='exp', help='save results to project/name')
    # exist-ok: 是否存在当前文件 默认False 一般是 no exist-ok 连用  所以一般都要重新创建文件夹
    parser.add_argument('--exist-ok', action='store_true', help='existing project/name ok, do not increment')
    # line-thickness: 画框的框框的线宽  默认是 3
    parser.add_argument('--line-thickness', default=1, type=int, help='bounding box thickness (pixels)')
    # hide-labels: 画出的框框是否需要隐藏label信息 默认False
    parser.add_argument('--hide-labels', default=False, action='store_true', help='hide labels')
    # hide-conf: 画出的框框是否需要隐藏conf信息 默认False
    parser.add_argument('--hide-conf', default=False, action='store_true', help='hide confidences')
    # half: 是否使用半精度 Float16 推理 可以缩短推理时间 但是默认是False
    parser.add_argument('--half', action='store_true', help='use FP16 half-precision inference')

    parser.add_argument('--dnn', action='store_true', help='use OpenCV DNN for ONNX inference')
    # 采用parser对象的parse_args函数获取解析的参数
    opt = parser.parse_args()
    #opt.imgsz这行是前面放参数的时候 ，default = [640]，长度是1，调整成2
    opt.imgsz *= 2 if len(opt.imgsz) == 1 else 1  # expand
    print_args(FILE.stem, opt)
    return opt


# 执行的第三步：主程序入口
def main(opt):
    # check_requirements 用来对 python 版本和 requirements.txt 文件必须要安装的包的版本进行检测 run()函数则是执行目标检测的主函数。
    check_requirements(exclude=('tensorboard', 'thop'))
    run(**vars(opt))# 将参数又传给run，run函数包含程序加载预测保存等功能，下一步我们去看run,往上翻


# 执行的第二步：当运行这个py文件时，会首先执行这里
if __name__ == "__main__":
    # opt = parse_opt()：解析终端命令行的参数，例如;python delect.py --source data\\images\\bus.jpg
    # 如果命令行没有写明的参数，会执行def parse_opt():中的默认参数，就是上面绿色字体的那部分
    opt = parse_opt()  # 返回值：所有的参数
    main(opt) # 将参数又传给主函数 main
