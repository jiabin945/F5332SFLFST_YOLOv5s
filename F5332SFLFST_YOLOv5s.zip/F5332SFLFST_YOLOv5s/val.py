# YOLOv5 🚀 by Ultralytics, GPL-3.0 license

#val
#编辑配置：D:\模型轻量化\yolov5-6.1\val.py
#python命令(val)：--data data/VOC.yaml --weights runs/train/VOC/weights/best.pt --batch-size 1
#(记住：如果要验证voc，就得用voc训练出来的模型（.pt）,不能用coco数据集训练出来的模型
# 因为不然类别不一致，会越界，比如：coco[57]是chair，对应voc[8]=chair。不信的话看下你的图片里是不是有椅子。)
#在训练阶段每个epoch训练结束后，都会调用一次val脚本，进行一次模型的验证。
#而当整个模型训练结束是，同样再会调用一次这个val脚本。
"""
    这个文件主要是在每一轮epoch训练结束后，验证当前模型的mAP、混淆矩阵等指标。(每一轮的batch中都会计算nms、
    通过process_batch函数判断这一个bat中每张图片预测框结果的真假、计算混淆矩阵、画出前三个batch的图片的groundtruth和预测框predictions(两个图)一起保存)
    实际上这个脚本最常用的应该是通过train.py调用 run 函数，而不是通过执行 val.py 的。
    所以在了解这个脚本的时候，其实最重要的就是 run 函数。
另外，6.1代码中的剪枝这里没有，但是原来版本有，自己添加上了
    难点：混淆矩阵+计算correct+计算mAP，一定要结合metrics.py脚本一起看
"""
# 大致实现思路：
#
# 加载模型 + 加载数据集
# 对每批次图像进行推理，并进行非极大值抑制处理获取每张图像的一个预测矩阵
# 对每张图像的全部预测框进行处理，进行gt的唯一匹配。对于gt匹配的预测框计算在每一个iou阈值下是否满足条件，构建成一个评价矩阵correct
# 将所有图像预测框的这些评价矩阵，以及每个预测框的置信度和预测类别，还有gt的类别保存下来进行后续操作
# 根据以上保存的训练，获取最大f1时每个类别的查准率，查全率，f1，以及每个类别在10个iou阈值下的map，这个就是最后所需要的信息
# 绘制相关图像 + 打印相关信息



"""
Validate a trained YOLOv5 model accuracy on a custom dataset

Usage:
    $ python path/to/val.py --weights yolov5s.pt --data coco128.yaml --img 640

Usage - formats:
    $ python path/to/val.py --weights yolov5s.pt                 # PyTorch
                                      yolov5s.torchscript        # TorchScript
                                      yolov5s.onnx               # ONNX Runtime or OpenCV DNN with --dnn
                                      yolov5s.xml                # OpenVINO
                                      yolov5s.engine             # TensorRT
                                      yolov5s.mlmodel            # CoreML (MacOS-only)
                                      yolov5s_saved_model        # TensorFlow SavedModel
                                      yolov5s.pb                 # TensorFlow GraphDef
                                      yolov5s.tflite             # TensorFlow Lite
                                      yolov5s_edgetpu.tflite     # TensorFlow Edge TPU
"""
#主体代码运行部分 + 指标计算部分 + 绘图部分

#---------------------------------------第一步导包和基本配置----------------------------------------
import argparse   # 解析命令行参数模块
import json  # 实现字典列表和JSON字符串之间的相互解析
import os   # 与操作系统进行交互的模块 包含文件路径操作和解析
import sys  # sys系统模块 包含了与Python解释器和它的环境有关的函数
from pathlib import Path  # Path将str转换为Path对象 使字符串路径易于操作的模块
from threading import Thread  # 线程操作模块

import numpy as np
import torch
from tqdm import tqdm
# __file__:指的是当前文件(即detect.py)，Path.resolve():获取绝对路径：D:\模型轻量化\yolov5-6.1\detect.py
#FILE最终保存着当前文件的绝对路径,
FILE = Path(__file__).resolve()
ROOT = FILE.parents[0]  # YOLOv5 root directory  # .parents():当前文件的路径的父目录；D:\模型轻量化\yolov5-6.1
#假如当前项目不在该路径中,就无法运行其中的模块,所以就需要加载路径
# sys.path是即当前python环境可以运行的路径，是一个列表list
if str(ROOT) not in sys.path:
    # sys.path是即当前python环境可以运行的路径，是一个列表list
    # sys.path.append():添加相关路径，但在退出python环境后自己添加的路径就会消失
    sys.path.append(str(ROOT))  # add ROOT to PATH
#os.path.relpath是求相对路径的（把绝对路径转化成相对路径，第一个参数那个相对于后面第二个参数那个的相对路径）,本例得到yolov5-6.1
#Path.cwd()确定当前所在的文件夹，即当前文件所在的位置，例如：#/home/lhcz/sdb/jiabin/jb_project，防止路径在ROOT前面，把这个补到后面weights等文件的路径中
#这一部分的主要作用有两个:
#将当前项目添加到系统路径上,以使得项目中的模块可以调用.  2将当前项目的相对路径保存在ROOT中,便于寻找项目中的文件
ROOT = Path(os.path.relpath(ROOT, Path.cwd()))  # relative # relative # 将绝对路径转变为相对目录，后面会用到

from models.common import DetectMultiBackend
from utils.callbacks import Callbacks
from utils.datasets import create_dataloader
from utils.general import (LOGGER, box_iou, check_dataset, check_img_size, check_requirements, check_yaml,
                           coco80_to_coco91_class, colorstr, increment_path, non_max_suppression, print_args,
                           scale_coords, xywh2xyxy, xyxy2xywh)
from utils.metrics import ConfusionMatrix, ap_per_class
from utils.plots import output_to_target, plot_images, plot_val_study
from utils.torch_utils import select_device, time_sync


def save_one_txt(predn, save_conf, shape, file):
    # Save one txt result
    gn = torch.tensor(shape)[[1, 0, 1, 0]]  # normalization gain whwh
    for *xyxy, conf, cls in predn.tolist():
        xywh = (xyxy2xywh(torch.tensor(xyxy).view(1, 4)) / gn).view(-1).tolist()  # normalized xywh
        line = (cls, *xywh, conf) if save_conf else (cls, *xywh)  # label format
        with open(file, 'a') as f:
            f.write(('%g ' * len(line)).rstrip() % line + '\n')


def save_one_json(predn, jdict, path, class_map):
    # Save one JSON result {"image_id": 42, "category_id": 18, "bbox": [258.15, 41.29, 348.26, 243.78], "score": 0.236}
    image_id = int(path.stem) if path.stem.isnumeric() else path.stem
    box = xyxy2xywh(predn[:, :4])  # xywh
    box[:, :2] -= box[:, 2:] / 2  # xy center to top-left corner
    for p, b in zip(predn.tolist(), box.tolist()):
        jdict.append({'image_id': image_id,
                      'category_id': class_map[int(p[5])],
                      'bbox': [round(x, 3) for x in b],
                      'score': round(p[4], 5)})

# 这个函数是重点
# 作用1：对预测框与gt进行一一匹配
# 作用2：对匹配上的预测框进行iou数值判断，用Ture来填充，其余没有匹配上的预测框的所以行数全部设置为False
def process_batch(detections, labels, iouv):
    """
    Return correct predictions matrix. Both sets of boxes are in (x1, y1, x2, y2) format.
    Arguments:
        detections (Array[N, 6]), x1, y1, x2, y2, conf, class
        labels (Array[M, 5]), class, x1, y1, x2, y2
    Returns:
        correct (Array[N, 10]), for 10 IoU levels
    """
    correct = torch.zeros(detections.shape[0], iouv.shape[0], dtype=torch.bool, device=iouv.device)
    iou = box_iou(labels[:, 1:], detections[:, :4])
    x = torch.where((iou >= iouv[0]) & (labels[:, 0:1] == detections[:, 5]))  # IoU above threshold and classes match
    if x[0].shape[0]:
        matches = torch.cat((torch.stack(x, 1), iou[x[0], x[1]][:, None]), 1).cpu().numpy()  # [label, detection, iou]
        if x[0].shape[0] > 1:
            matches = matches[matches[:, 2].argsort()[::-1]]
            matches = matches[np.unique(matches[:, 1], return_index=True)[1]]
            # matches = matches[matches[:, 2].argsort()[::-1]]
            matches = matches[np.unique(matches[:, 0], return_index=True)[1]]
        matches = torch.Tensor(matches).to(iouv.device)
        correct[matches[:, 1].long()] = matches[:, 2:3] >= iouv
    return correct

#-------------------第五步：执行run函数-----------------------------------
#run 函数其实用train.py执行的，并不是执行val.py。train.py调用（每个训练epoch后验证当前模型）:
#每次epoch训练完成后，通过train.py中的val.run调用，验证当前模型
#主体代码：

#5.1-----------------------------------载入参数-------------------------------------
@torch.no_grad()# 不参与反向传播
def run(data,   # data: 数据集配置文件地址 包含数据集的路径、类别个数、类名、下载地址等信息 train.py时传入data_dict
        weights=None,  # weights: 模型的权重文件地址 运行train.py=None 运行test.py=默认weights/yolov5s.pt（自己命令行['runs/exp153/weights/best.pt']）
        batch_size=32,  # 前向传播的批次大小 运行test.py传入默认32（自己命令行设置为1） 运行train.py则传入batch_size // WORLD_SIZE * 2
        imgsz=640,  # 输入网络的图片分辨率 运行test.py传入默认640 运行train.py则传入imgsz_test
        conf_thres=0.001,  # object置信度阈值 默认0.25
        iou_thres=0.6,  # 进行NMS时IOU的阈值 默认0.6
        task='val',  # 设置测试的类型 有train, val, test, speed or study几种 默认val
        device='',  # 测试的设备,自己设置为0
        workers=8,  # max dataloader workers (per RANK in DDP mode)
        single_cls=False,  # 数据集是否只用一个类别 运行test.py传入默认False 运行train.py则传入single_cls
        augment=False,  # 测试是否使用TTA Test Time Augment 默认False
        verbose=False,  # 是否打印出每个类别的mAP 运行test.py传入默认Fasle 运行train.py则传入nc < 50 and final_epoch
        save_txt=False,  # 是否以txt文件的形式保存模型预测框的坐标 默认False
        save_hybrid=False,  # 是否save label+prediction 混合 results to *.txt  默认False，是否将gt_label+pre_label一起输入nms
        save_conf=False,  # 是否保存预测每个目标的置信度到预测tx文件中 默认True
        save_json=False,  # 是否按照coco的json格式保存预测框，并且使用cocoapi做评估（需要同样coco的json格式的标签）运行test.py传入默认Fasle 运行train.py则传入is_coco and final_epoch(一般也是False)
        project=ROOT / 'runs/val',  # 测试保存的源文件 默认runs/val
        name='exp',  # 测试保存的文件地址 默认exp  保存在runs/test/exp下
        exist_ok=False,  # 是否存在当前文件 默认False 一般是 no exist-ok 连用  所以一般都要重新创建文件夹
        half=True,  # 是否使用半精度推理 FP16 half-precision inference 默认False
        dnn=False,  # use OpenCV DNN for ONNX inference
        model=None, # 模型 如果执行val.py就为None 如果执行train.py就会传入ema.ema(ema模型)
        dataloader=None, # 数据加载器 如果执行test.py就为None 如果执行train.py就会传入testloader
        save_dir=Path(''),  # 文件保存路径 如果执行test.py就为‘’ 如果执行train.py就会传入save_dir(runs/train/expn)
        plots=True, # 是否可视化 运行test.py传入默认True 运行train.py则传入plots and final_epoch
        callbacks=Callbacks(),
        compute_loss=None,# 损失函数 运行test.py传入默认None 运行train.py则传入compute_loss(train)
        ):
#--------------------5.2初始化配置1-----------------------------------
# 训练时（train.py）调用：初始化模型参数、训练设备
# 验证时（val.py）调用：初始化设备、save_dir文件路径、make dir、加载模型、check imgsz、 加载+check data配置信息

#判断是否是训练时调用run函数(执行train.py脚本), 如果是就使用训练时的设备
    training = model is not None
    if training:  # called by train.py
        device, pt, jit, engine = next(model.parameters()).device, True, False, False  # get model device, PyTorch model
        half &= device.type != 'cpu'  # half precision only supported on CUDA
        model.half() if half else model.float()
    # 如果不是train.py调用run函数(执行val.py脚本）
    # 就调用select_device选择可用的设备、并生成save_dir + make dir + 加载model + check imgsz + 加载data配置信息
    else:  # called directly
        #选择运行的设备GPU or cpu
        device = select_device(device, batch_size=batch_size)

        # Directories
        # 生成save_dir文件路径  runs/val/exp9
        save_dir = increment_path(Path(project) / name, exist_ok=exist_ok)  # increment run
        # 根据前面生成的路径创建文件夹
        (save_dir / 'labels' if save_txt else save_dir).mkdir(parents=True, exist_ok=True)  # make dir

        # Load model
        # YOLOV6 在DetectMultiBackend中实现  model = attempt_load(weights, map_location=device)
        # 加载模型 load FP32 model  只在运行val.py才需要自己加载model
        # 选择学习框架，例如：PyTorch TorchScript TensorRT等，可以按住Ctrl单击函数进入查看
        # 传入weights训练权重为yolov5s.pt，设备，
        model = DetectMultiBackend(weights, device=device, dnn=dnn, data=data)
        #读取模型属性：步长stride = 32类型名names = 80模型类型pt = true, 表示是PyTorch类型
        # stride：推理时所用到的步长，默认为32， 大步长适合于大目标，小步长适合于小目标
        # names：保存推理结果名的列表，比如默认模型的值是['person', 'bicycle', 'car', ...]
        # pt: 加载的是否是pytorch模型（也就是pt格式的文件）
        # JIT: 是一种概念，全称是 Just In Time Compilation，中文译为「即时编译」，是一种程序优化的方法，
        # onnx:ONNX是一种针对机器学习所设计的开放式的文件格式,用于存储训练好的模型
        #推理引擎：YOLO采用的是wts权重文件,在tensorRT推理过程中需要序列化生成engine文件,而engine文件是GPU框架绑定的,所以针对不同的显卡需要本地序列化一次
        stride, pt, jit, onnx, engine = model.stride, model.pt, model.jit, model.onnx, model.engine
        # 第四行:核实图片的尺寸大小是否是步长32的倍数，这里是640*640,所以imgsz =640，不用修改，否则会给一个合适的值
        imgsz = check_img_size(imgsz, s=stride)  # check image size

        # Half model 只能在单GPU设备上才能使用
        # half=half & (pt or jit or onnx or engine) and device.type != 'cpu'  此代码等号右边t,前面为f（因为传过来默认就为false），则结果为f
        #& ：位运算符，是按位进行逻辑运算   and:直接逻辑运算符
        half &= (pt or jit or onnx or engine) and device.type != 'cpu'  # FP16 supported on limited backends with CUDA
        if pt or jit:
            # 一旦使用half, 不但模型需要设为half, 输入模型的图片也需要设为half
            model.model.half() if half else model.model.float()
        elif engine:
            batch_size = model.batch_size
        else:
            half = False
            batch_size = 1  # export.py models default to batch-size 1
            device = torch.device('cpu')
            LOGGER.info(f'Forcing --batch-size 1 square inference shape(1,3,{imgsz},{imgsz}) for non-PyTorch backends')

        #数据集，包括路径、训练集、测试集、验证集、种类个数、种类名字等等
        # Data 加载数据配置信息 只有运行test.py才需要加载数据配置信息, 因为它需要根据data生成新的dataloader
        # 而运行train.py时是直接传入testloader的, 所以不需要加载数据配置信息
        # check_dataset:这个函数是检查本地是否有指定的数据集，没用就从torch库中下载并解压数据集。
        data = check_dataset(data)  # check

# ============================================== 5.3、调整模型 ==================================================
    # 半精度验证half model（在上面） + 模型剪枝prune + 模型融合conv+bn（后面两个剪枝、融合是6.1版本没有的，自己从别处加进去的）

    # from utils.torch_utils import prune
    # prune(model, 0.3)  # 模型剪枝

    # model = model.fuse()  # 模型融合  融合conv+bn

    # 如果模型中有BN (Batch Normalization)层和Dropout，那就需要在训练时添加model.train()，在测试时添加model.eval()。
    # 对BN层来说，model.train()保证BN层使用每一批数据的均值和方差，model.eval()保证BN层使用全部训练数据的均值和方差。
    # 对Dropout来说，model.train()随机选取一部分网络连接来训练更新参数，model.eval()利用所有的网络连接来训练更新参数。
    #eval()时，框架会自动把BN和DropOut固定住，用训练好的值; 不启用 BatchNormalization 和 Dropout
    model.eval()  # 启动模型验证模式

# ============================================== 5.4、初始化配置2 ==================================================
    # 是否是coco数据集is_coco + 类别个数nc + 计算mAP相关参数 + 初始化日志 Logging

    # 测试数据是否是coco数据集 + class类别个数
    is_coco = isinstance(data.get('val'), str) and data['val'].endswith('coco/val2017.txt')  # COCO dataset
    nc = 1 if single_cls else int(data['nc'])  # number of classes

    # 计算mAP相关参数
    # 设置iou阈值 从0.5-0.95取10个(0.05间隔)  tensor([0.50000, 0.55000, 0.60000, 0.65000, 0.70000, 0.75000, 0.80000, 0.85000, 0.90000, 0.95000], device='cuda:0')
    iouv = torch.linspace(0.5, 0.95, 10).to(device)  # iou vector for mAP@0.5:0.95
    # mAP@0.5:0.95 iou个数=10个
    niou = iouv.numel()

# ======================================= 5.5、加载val数据集（val.py调用） =============================================
    """
        训练时（train.py）调用：加载val数据集，(执行train.py调用run函数)就不需要生成dataloader 可以直接从参数中传过来valloader
        验证时（val.py）调用：不需要加载val数据集,(执行val.py脚本调用run函数)就调用create_dataloader生成dataloader
    """
    # Dataloader
    # 如果不是训练(执行val.py脚本调用run函数)就调用create_dataloader生成dataloader
    if not training:
        #warmup是一种学习率优化方法（最早出现在ResNet论文中）。在模型训练之初选用较小的学习率，训练一段时间之后使
        # 用预设的学习率进行训练。
        # 使用空白图片（零矩阵）预先用GPU跑一遍预测流程，可以加速预测
        model.warmup(imgsz=(1 if pt else batch_size, 3, imgsz, imgsz), half=half)  # warmup
        pad = 0.0 if task in ('speed', 'benchmark') else 0.5
        rect = False if task == 'benchmark' else pt  # square inference for benchmarks
        task = task if task in ('train', 'val', 'test') else 'val'  # path to train/val/test images
        # 创建dataloader 这里的rect默认为True 矩形推理用于测试集 在不影响mAP的情况下可以大大提升推理速度
        # 默认没有设置shuffle，也就是按顺序来进行验证，没有打乱数据集
        # 注意这里rect参数为True，yolov5的测试评估是基于矩形推理的
        dataloader = create_dataloader(data[task], imgsz, batch_size, stride, single_cls, pad=pad, rect=rect,
                                       workers=workers, prefix=colorstr(f'{task}: '))[0]

    # ============================================== 5.6初始化配置3 ==================================================
    # 初始化混淆矩阵 + 数据集类名 + 获取coco数据集的类别索引 + 设置tqdm进度条 + 初始化p, r, f1, mp, mr,
    # map50, map指标和时间t0, t1, t2 + 初始化测试集的损失 + 初始化json文件中的字典 统计信息 ap等

    #初始化测试的图片数量
    seen = 0
    # 初始化混淆矩阵
    confusion_matrix = ConfusionMatrix(nc=nc)
    #获取数据集所有类别的index和对应类名(自己命令行中是VOC.yaml，但是使用的是coco,可能voc配置文件中
    #voc数据集不存在 )
    names = {k: v for k, v in enumerate(model.names if hasattr(model, 'names') else model.module.names)}
    # 获取coco数据集的类别索引
    # coco数据集是80个类 索引范围本应该是0~79,但是这里返回的确是0~90  coco官方就是这样规定的
    # coco80_to_coco91_class就是为了与上述索引对应起来，返回一个范围在0~80的索引数组
    class_map = coco80_to_coco91_class() if is_coco else list(range(1000))
    # 设置tqdm进度条的显示信息 s:字符串
    s = ('%20s' + '%11s' * 6) % ('Class', 'Images', 'Labels', 'P', 'R', 'mAP@.5', 'mAP@.5:.95')
    # 初始化p, r, f1, mp, mr, map50, map指标和时间t0, t1, t2
    dt, p, r, f1, mp, mr, map50, map = [0.0, 0.0, 0.0], 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
    # 初始化测试集的损失
    loss = torch.zeros(3, device=device)
    # 初始化json文件中的字典 统计信息 ap等
    jdict, stats, ap, ap_class = [], [], [], []
    pbar = tqdm(dataloader, desc=s, bar_format='{l_bar}{bar:10}{r_bar}{bar:-10b}')  # progress bar

# ============================================== 5.7、开始验证 ==================================================
    #5.71图片预处理和target放到设备上，图片进行归一化处理，获得这批图片的四维，统计过程处理时间
    for batch_i, (im, targets, paths, shapes) in enumerate(pbar):
        t1 = time_sync()# 获取当前时间
        if pt or jit or engine:
            im = im.to(device, non_blocking=True)# img to device
            #目标框：torch.Size([2, 6])，2表示这个batch（自己设置为1）中图片一共2个目标，6表示6个信息
            #targets中的第一个数代表一个batch中第几张图片,第二个代表目标类别,后面四个是目标框
            targets = targets.to(device)
        # 如果half为True 就把图片变为half精度
        im = im.half() if half else im.float()  # uint8 to fp16/32
        #这是为了在将范围变成[0，1]之间，因为图片信息的数值矩阵类型为unit8型，在0~255范围内，为了保证精度，上面数据处理时转换double型，
        #但是直接运行imshow(图像)，会显示一个白色的图像。这是因为imshow()显示图像时对double型是认为在0~1范围内，即大于1时都是显示为白色，
        #所以解决办法就是除以255后，图片矩阵的就变成0~1之间的double型，这样才可以正确表达图片信息。
        im /= 255  # 0 - 255 to 0.0 - 1.0（归一化）
        nb, _, height, width = im.shape  # batch size, channels, height, width

        """
                    time_synchronized()函数里面进行了torch.cuda.synchronize()，再返回的time.time()
                    torch.cuda.synchronize()等待gpu上完成所有的工作，这样测试时间会更准确 
                    """
        t2 = time_sync()# 获取当前时间
        dt[0] += t2 - t1# 累计处理数据时间

        # Inference5.71-1前向推理
        # out: (预测结果)  推理结果 1个 [bs, anchor_num*grid_w*grid_h, xywh+c+20classes] = [1, 19200+4800+1200, 25]（三个层）
        # train_out:（训练结果） 训练结果 3个 [bs, anchor_num, grid_w, grid_h, xywh+c+20classes]
        #                    如: [1, 3, 80, 80, 25] [1, 3, 40, 40, 25] [1, 3, 20, 20, 25]
        #若只执行val,则train_out没有意义
        #out:torch.Size([1, 9261, 25])
        out, train_out = model(im) if training else model(im, augment=augment, val=True)  # inference, loss outputs
        dt[1] += time_sync() - t2 # 累计前向推理时间 t1

        # 5.71-2、计算验证损失
        # compute_loss不为空 说明正在执行train.py  根据传入的compute_loss计算损失值
        # 如果是在训练时进行的test，则通过训练结果计算并返回测试集的box, obj, cls损失
        #因为自己只执行val.py,所以compute_loss为none
        if compute_loss:  # box, obj, cls
            loss += compute_loss([x.float() for x in train_out], targets)[1]  # box, obj, cls

        # 5.71-3 NMS
        #torch.Size([17, 6])：17：target数量   6：(batch, cls, cx, cy, w, h)
        # 将真实框target的x1y1x2y2乘以缩放尺度(因为target是在labelimg中做了归一化的)映射到img(test)尺寸（也可能xywh）
        #将原图中归一化的gt_box投射到feature_map中（自己查的，应该对的）
        targets[:, 2:] *= torch.Tensor([width, height, width, height]).to(device)  # to pixels

        # save_hybrid: adding the dataset labels to the model predictions before NMS
        # 如果save_hybrid为True，获取当前target中每一类的对象存储在列表中, 默认为False
        # targets: [num_target, img_index+class_index+xywh] = [31, 6]  (num_target:表示这个batch图片的数量，若bat=1,则一张图片)
        # lb: {list: bs} 第一张图片的target[17, 5] 第二张[1, 5] 第三张[7, 5] 第四张[6, 5]
        lb = [targets[targets[:, 0] == i, 1:] for i in range(nb)] if save_hybrid else []  # for autolabelling
        t3 = time_sync()
        # 非极大抑制
        #发现out只有一个list，即只有一个batch,而这个batch为[187, 6]，即第一个batch中第一维：有预测187个框，第二维：六个参数：xyxy,conf，物体类别
        out = non_max_suppression(out, conf_thres, iou_thres, labels=lb, multi_label=True, agnostic=single_cls)
        dt[2] += time_sync() - t3 # 累计NMS时间

        # 5.71-4、统计每张图片的真实框、预测框信息  Statistics per image
        # 为每张图片做统计，写入预测信息到txt文件，生成json文件字典，统计tp等
        # out: list{bs}  [300, 6] [42, 6] [300, 6] [300, 6]  [pred_obj_num, x1y1x2y2+object_conf+cls]
        # 迭代依次处理每一张图像，直至完成整个batch的信息获取再进行下一个batch的处理
        #注意；现在out，因为命令行是bat=1，所以这批只有一张图片即list1。是预测后经过nms的[187,6](第一个bat一维：预测框数目，二维六个参数：xyxy,conf，物体类别)，target是映射后真实到原图的（bat,类别，中心坐标、宽高）
        #对这一个batch中的out中的每张图片（因为只有一张图片，所以只会一次）进行迭代  si:第几张图片  pred:[187,6]:即上面的
        for si, pred in enumerate(out):
            # 获取此批次out的第si张图片的gt标签信息 包括class, x, y, w, h    target[:, 0]为标签属于哪张图片的编号
            #如果targets[:, 0] == si，则返回第一个target信息，即gt框，标注的原始数据
            #torch.Size([2, 5])，即这批，因bat=1,即这张图片上两个gt框的信息，类别，中心点坐标、宽高
            labels = targets[targets[:, 0] == si, 1:]
            nl = len(labels)  # 第si张图片的gt个数
            #这批（bat=1即一张图片）上两个框种类
            tcls = labels[:, 0].tolist() if nl else []  # target 类别  例如：11，17
            # 获取第si张图片的地址 和 第si张图片的尺寸
            path, shape = Path(paths[si]), shapes[si][0]
            seen += 1  #统计图片数量

            # 如果当前图像预测为空，则添加空的信息到stats里，提前退出
            if len(pred) == 0:
                if nl:
                    stats.append((torch.zeros(0, niou, dtype=torch.bool), torch.Tensor(), torch.Tensor(), tcls))
                continue

            # Predictions
            if single_cls:
                pred[:, 5] = 0
            #[187,6]
            predn = pred.clone()
            # 将预测坐标映射到原图img0中，也就是img[si].shape[1:] 缩放到 shape中，最后一个参数是pad信息，可以设置为False
            scale_coords(im[si].shape[1:], predn[:, :4], shape, shapes[si][1])  # native-space pred

            # 571-4-1、计算混淆矩阵、计算correct、生成stats
            # 初始化预测评定 niou为iou阈值的个数  Assign all predictions as incorrect
            # correct = [pred_obj_num, 10] = [300, 10]  全是False
            # Evaluate
            if nl:
                tbox = xywh2xyxy(labels[:, 1:5])  # target(即此图片上两个gt框) boxes 获得xyxy格式的框
                # 将目标框gtbox映射到原图img
                scale_coords(im[si].shape[1:], tbox, shape, shapes[si][1])  # native-space labels
                # 处理完gt的尺寸信息，重新构建成 (cls, xyxy)的格式，即在tbox基础上（xyxy）补上类别这一项
                labelsn = torch.cat((labels[:, 0:1], tbox), 1)  # native-space labels

                # 调用获取匹配预测框的iou信息-process_batch的部分
                # 对当前的预测框与gt进行一一匹配，并且在预测框的对应位置上获取iou的评分信息，其余没有匹配上的预测框设置为False
                correct = process_batch(predn, labelsn, iouv)

                if plots:
                    # 计算混淆矩阵 confusion_matrix      predn, labelsn：这个批次的这个图片上的预测框与真实框
                    confusion_matrix.process_batch(predn, labelsn)
            else:
                correct = torch.zeros(pred.shape[0], niou, dtype=torch.bool)
            # 将每张图片的预测结果统计到stats中 Append statistics
            # stats: correct, conf, pcls, tcls   bs个 correct, conf, pcls, tcls
            # correct: [pred_num, 10] bool 当前图片每一个预测框在每一个iou条件下是否是TP
            # pred[:, 4]: [pred_num, 1] 当前图片每一个预测框的conf
            # pred[:, 5]: [pred_num, 1] 当前图片每一个预测框的类别
            # tcls: [gt_num, 1] 当前图片所有gt框的类别
            stats.append((correct.cpu(), pred[:, 4].cpu(), pred[:, 5].cpu(), tcls))  # (correct, conf, pcls, tcls)

            #575 - 2 保存预测信息到txt文件  runs\val\exp7\labels\image_name.txt
            # Save/log
            if save_txt:
                save_one_txt(predn, save_conf, shape, file=save_dir / 'labels' / (path.stem + '.txt'))
            # 575-3、将预测信息保存到coco格式的json字典(后面存入json文件)
            if save_json:
                save_one_json(predn, jdict, path, class_map)  # append to COCO-JSON dictionary
            callbacks.run('on_val_image_end', pred, predn, path, names, im[si])

        # Plot images
        #画出前三个batch的图片的groundtruth和预测框predictions(两个图)一起保存
        if plots and batch_i < 3:
            # ground truth
            f = save_dir / f'val_batch{batch_i}_labels.jpg'  # labels
            # Thread  表示在单独的控制线程中运行的活动 创建一个单线程(子线程)来执行函数 由这个子进程全权负责这个函数
            # target: 执行的函数  args: 传入的函数参数  daemon: 当主线程结束后, 由他创建的子线程Thread也已经自动结束了
            # .start(): 启动线程  当thread一启动的时候, 就会运行我们自己定义的这个函数plot_images
            # 如果在plot_images里面打开断点调试, 可以发现子线程暂停, 但是主线程还是在正常的训练(还是正常的跑)
            Thread(target=plot_images, args=(im, targets, paths, f, names), daemon=True).start()
            f = save_dir / f'val_batch{batch_i}_pred.jpg'  # predictions
            Thread(target=plot_images, args=(im, output_to_target(out), paths, f, names), daemon=True).start()

    #所有bat结束后计算其map
    # 统计stats中所有图片的统计结果 将stats列表的信息拼接到一起
    # stats(concat后): list{4} correct, conf, pcls, tcls  统计出的整个数据集的GT
    # correct [img_sum, 10] 整个数据集所有图片中所有预测框在每一个iou条件下是否是TP  [1905, 10]
    # conf [img_sum] 整个数据集所有图片中所有预测框的conf  [1905]
    # pcls [img_sum] 整个数据集所有图片中所有预测框的类别   [1905]
    # tcls [gt_sum] 整个数据集所有图片所有gt框的类别    [929]

    #调用获取map等指标信息-ap_per_class的部分：
    # Compute metrics
    stats = [np.concatenate(x, 0) for x in zip(*stats)]  # to numpy
    # stats[0].any(): stats[0]是否全部为False, 是则返回 False, 如果有一个为 True, 则返回 True
    if len(stats) and stats[0].any():
        # 调用获取map等指标信息-ap_per_class的部分：
        # 根据上面的统计预测结果计算p, r, ap, f1, ap_class（ap_per_class函数是计算每个类的mAP等指标的）等指标
        #tp：20（类别），应该是每个类的判断为真，实际为真的数量。 fp:20,应该是每个类的判断为真，实际为假
        # p: [nc] 最大平均f1时每个类别的precision
        # r: [nc] 最大平均f1时每个类别的recall
        # ap: [71, 10] 数据集每个类别在10个iou阈值下的mAP
        # f1 [nc] 最大平均f1时每个类别的f1
        # ap_class: [nc] 返回数据集中所有的类别index
        tp, fp, p, r, f1, ap, ap_class = ap_per_class(*stats, plot=plots, save_dir=save_dir, names=names)
        # ap50: [nc] 所有类别的mAP@0.5   ap: [nc] 所有类别的mAP@0.5:0.95
        ap50, ap = ap[:, 0], ap.mean(1)  # AP@0.5, AP@0.5:0.95
        # mp: [1] 所有类别的平均precision(最大f1时)
        # mr: [1] 所有类别的平均recall(最大f1时)
        # map50: [1] 所有类别的平均mAP@0.5
        # map: [1] 所有类别的平均mAP@0.5:0.95
        mp, mr, map50, map = p.mean(), r.mean(), ap50.mean(), ap.mean()
        # nt: [nc] 统计出整个数据集的gt框中数据集各个类别的个数
        nt = np.bincount(stats[3].astype(np.int64), minlength=nc)  # number of targets per class
    else:
        nt = torch.zeros(1)

    # Print results print打印各项指标
    # Print results  数据集图片数量 + 数据集gt框的数量 + 所有类别的平均precision +
    # 所有类别的平均recall + 所有类别的平均mAP@0.5 + 所有类别的平均mAP@0.5:0.95
    #pf:'%20s%11i%11i%11.3g%11.3g%11.3g%11.3g'
    pf = '%20s' + '%11i' * 2 + '%11.3g' * 4  # print format
    LOGGER.info(pf % ('all', seen, nt.sum(), mp, mr, map50, map))

    # Print results per class
    # 细节展示每个类别的各个指标  类别 + 数据集图片数量 + 这个类别的gt框数量 + 这个类别的precision +
    #                        这个类别的recall + 这个类别的mAP@0.5 + 这个类别的mAP@0.5:0.95
    #verbose ：是否打印每个类别的map，默认false
    if (verbose or (nc < 50 and not training)) and nc > 1 and len(stats):
        for i, c in enumerate(ap_class):
            LOGGER.info(pf % (names[c], seen, nt[c], p[i], r[i], ap50[i], ap[i]))

    # Print speeds  打印前向传播耗费的总时间、nms耗费总时间、总时间
    t = tuple(x / seen * 1E3 for x in dt)  # speeds per image
    if not training:
        shape = (batch_size, 3, imgsz, imgsz)
        #百分号后面的t中的数据即为前面格式中的数据
        LOGGER.info(f'Speed: %.1fms pre-process, %.1fms inference, %.1fms NMS per image at shape {shape}' % t)

    # Plots
    #、画出混淆矩阵并存入wandb_logger中
    # Plots  confusion_matrix + wandb_logger
    if plots:
        confusion_matrix.plot(save_dir=save_dir, names=list(names.values()))
        callbacks.run('on_val_end')

    # Save JSON
    # 采用之前保存的json文件格式预测结果 通过cocoapi评估各个指标
    # 需要注意的是 测试集的标签也要转为coco的json格式
    if save_json and len(jdict):
        w = Path(weights[0] if isinstance(weights, list) else weights).stem if weights is not None else ''  # weights
        anno_json = str(Path(data.get('path', '../coco')) / 'annotations/instances_val2017.json')  # annotations json
        pred_json = str(save_dir / f"{w}_predictions.json")  # predictions json
        LOGGER.info(f'\nEvaluating pycocotools mAP... saving {pred_json}...')
        with open(pred_json, 'w') as f:
            json.dump(jdict, f)

        try:  # https://github.com/cocodataset/cocoapi/blob/master/PythonAPI/pycocoEvalDemo.ipynb
            check_requirements(['pycocotools'])
            from pycocotools.coco import COCO
            from pycocotools.cocoeval import COCOeval

            # 获取并初始化测试集标签的json文件
            anno = COCO(anno_json)  # init annotations api
            # 初始化预测框的文件
            pred = anno.loadRes(pred_json)  # init predictions api
            # 创建评估器
            eval = COCOeval(anno, pred, 'bbox')
            if is_coco:
                eval.params.imgIds = [int(Path(x).stem) for x in dataloader.dataset.img_files]  # image IDs to evaluate
            # 评估
            eval.evaluate()
            eval.accumulate()
            eval.summarize()
            map, map50 = eval.stats[:2]  # update results (mAP@0.5:0.95, mAP@0.5)
        except Exception as e:
            LOGGER.info(f'pycocotools unable to run: {e}')

    # 返回测试指标结果  Return results
    model.float()  # for training
    if not training:
        s = f"\n{len(list(save_dir.glob('labels/*.txt')))} labels saved to {save_dir / 'labels'}" if save_txt else ''
        LOGGER.info(f"Results saved to {colorstr('bold', save_dir)}{s}")
    maps = np.zeros(nc) + map  # [80] 80个平均mAP@0.5:0.95
    for i, c in enumerate(ap_class):
        maps[c] = ap[i]  # maps [80] 所有类别的mAP@0.5:0.95
    # (mp, mr, map50, map, *(loss.cpu() / len(dataloader)).tolist()): {tuple:7}
    #      0: mp [1] 所有类别的平均precision(最大f1时)
    #      1: mr [1] 所有类别的平均recall(最大f1时)
    #      2: map50 [1] 所有类别的平均mAP@0.5
    #      3: map [1] 所有类别的平均mAP@0.5:0.95
    #      4: val_box_loss [1] 验证集回归损失
    #      5: val_obj_loss [1] 验证集置信度损失
    #      6: val_cls_loss [1] 验证集分类损失
    # maps: [80] 所有类别的mAP@0.5:0.95
    # t: {tuple: 3} 0: 打印前向传播耗费的总时间   1: nms耗费总时间   2: 总时间
    return (mp, mr, map50, map, *(loss.cpu() / len(dataloader)).tolist()), maps, t


#------------------第二步：设置opt参数-----------------------------------------------
def parse_opt():
    """
        opt参数详解
        data: 数据集配置文件地址 包含数据集的路径、类别个数、类名、下载地址等信息，即指定yaml文件
        weights: 模型的权重文件地址 weights/yolov5s.pt
        batch_size: 前向传播的批次大小 默认32，自己指定的是16
        imgsz: 输入网络的图片分辨率 默认640
        conf-thres: object置信度阈值 默认0.001
        iou-thres: 进行NMS时IOU的阈值 默认0.6
        task: 设置测试的类型 有train, val, test, speed or study几种 默认val
        device: 测试的设备
        single-cls: 数据集是否只用一个类别 默认False
        augment: 测试是否使用TTA Test Time Augment 默认False
        解释tta:可将准确率提高若干个百分点，它就是测试时增强（test time augmentation, TTA）。这里会为原始
        图像造出多个不同版本，包括不同区域裁剪和更改缩放程度等，并将它们输入到模型中；然后对多个版本进行计算得到平均输出，作为图像的最终输出分数
        verbose: 是否打印出每个类别的mAP 默认False
        下面三个参数是auto-labelling(有点像RNN中的teaching forcing)相关参数详见:https://github.com/ultralytics/yolov5/issues/1563 下面解释是作者原话
        save-txt: traditional auto-labelling
        save-hybrid: save hybrid autolabels, combining existing labels with new predictions before NMS (existing predictions given confidence=1.0 before NMS.
        save-conf: add confidences to any of the above commands
        save-json: 是否按照coco的json格式保存预测框，并且使用cocoapi做评估（需要同样coco的json格式的标签） 默认False
        project: 测试保存的源文件 默认runs/test
        name: 测试保存的文件地址 默认exp  保存在runs/test/exp下
        exist-ok: 是否存在当前文件 默认False 一般是 no exist-ok 连用  所以一般都要重新创建文件夹
        half: 是否使用半精度推理 默认False
        """
# 建立参数解析对象parser argparse:python的命令行解析的模块，内置于python，不需要安装    可以让我们直接在命令行中就可以向程序中传入参数并让程序运行
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', type=str, default=ROOT / 'data/VisDrone.yaml',
                        help='dataset.yaml path')  # 数据集配置文件地址 包含数据集的路径、类别个数、类名、下载地址等信息
    parser.add_argument('--weights', nargs='+', type=str, default=ROOT / '',
                        help='model.pt path(s)')  # 模型的权重文件地址 weights/yolov5s.pt
    parser.add_argument('--batch-size', type=int, default=32, help='batch size')  # 前向传播的批次大小 默认32
    parser.add_argument('--imgsz', '--img', '--img-size', type=int, default=640,
                        help='inference size (pixels)')  # 输入网络的图片分辨率 默认640
    parser.add_argument('--conf-thres', type=float, default=0.001, help='confidence threshold')  # object置信度阈值 默认0.25
    parser.add_argument('--iou-thres', type=float, default=0.6, help='NMS IoU threshold')  # 进行NMS时IOU的阈值 默认0.6
    parser.add_argument('--task', default='val',help='train, val, test, speed or study')  # 设置测试的类型 有train, val, test, speed or study几种 默认val
    parser.add_argument('--device', default='0', help='cuda device, i.e. 0 or 0,1,2,3 or cpu')  # 测试的设备
    parser.add_argument('--workers', type=int, default=8, help='max dataloader workers (per RANK in DDP mode)')
    parser.add_argument('--single-cls', action='store_true',
                        help='treat as single-class dataset')  # 数据集是否只用一个类别 默认False
    parser.add_argument('--augment', action='store_true',
                        help='augmented inference')  # 测试是否使用TTA Test Time Augment 默认False
    parser.add_argument('--verbose', action='store_true', help='report mAP by class')  # 是否打印出每个类别的mAP 默认False
    parser.add_argument('--save-txt', action='store_true', help='save results to *.txt')  # 是否以txt文件的形式保存模型预测框的坐标 默认True
    parser.add_argument('--save-hybrid', action='store_true',
                        help='save label+prediction hybrid results to *.txt')  # 是否save label+prediction hybrid results to *.txt  默认False 是否将gt_label+pre_label一起输入nms
    parser.add_argument('--save-conf', action='store_true',
                        help='save confidences in --save-txt labels')  # 是否保存预测每个目标的置信度到预测tx文件中 默认True
    parser.add_argument('--save-json', action='store_true',
                        help='save a COCO-JSON results file')  # 是否按照coco的json格式保存预测框，并且使用cocoapi做评估（需要同样coco的json格式的标签） 默认False
    parser.add_argument('--project', default=ROOT / '', help='save to project/name')  # 测试保存的源文件 默认runs/test
    parser.add_argument('--name', default='',help='save to project/name')  # 测试保存的文件地址 默认exp  保存在runs/test/exp下
    parser.add_argument('--exist-ok', action='store_true',help='existing project/name ok, do not increment')  # 是否存在当前文件 默认False 一般是 no exist-ok 连用  所以一般都要重新创建文件夹
    parser.add_argument('--half', action='store_true', help='use FP16 half-precision inference')  # 是否使用半精度推理 默认False
    parser.add_argument('--dnn', action='store_true', help='use OpenCV DNN for ONNX inference')
    opt = parser.parse_args() # 解析上述参数
    opt.data = check_yaml(opt.data)  # check YAML
    opt.save_json |= opt.data.endswith('coco.yaml')# |或 左右两个变量有一个为True 左边变量就为True
    opt.save_txt |= opt.save_hybrid
    print_args(FILE.stem, opt)
    return opt

#---------第四步：执行main函数------------------------------------------
#一般执行if模块
def main(opt):
    # 检测requirements文件中需要的包是否安装好了
    check_requirements(requirements=ROOT / 'requirements.txt', exclude=('tensorboard', 'thop'))

    # 如果task in ['train', 'val', 'test']就正常测试 训练集/验证集/测试集
    if opt.task in ('train', 'val', 'test'):  # run normally
        if opt.conf_thres > 0.001:  # https://github.com/ultralytics/yolov5/issues/1466
            LOGGER.info(f'WARNING: confidence threshold {opt.conf_thres} >> 0.001 will produce invalid mAP values.')
        run(**vars(opt))

    # 如果opt.task == 'speed' 就测试yolov5系列和yolov3-spp各个模型的速度评估
    else:
        weights = opt.weights if isinstance(opt.weights, list) else [opt.weights]
        opt.half = True  # FP16 for fastest results
        # 如果opt.task == 'speed' 就测试yolov5系列和yolov3-spp各个模型的速度评估
        if opt.task == 'speed':  # speed benchmarks
            # python val.py --task speed --data coco.yaml --batch 1 --weights yolov5n.pt yolov5s.pt...
            opt.conf_thres, opt.iou_thres, opt.save_json = 0.25, 0.45, False
            for opt.weights in weights:
                run(**vars(opt), plots=False)

        # 如果opt.task = ['study']就评估yolov5系列和yolov3-spp各个模型在各个尺度下的指标并可视化
        elif opt.task == 'study':  # speed vs mAP benchmarks
            # python val.py --task study --data coco.yaml --iou 0.7 --weights yolov5n.pt yolov5s.pt...
            for opt.weights in weights:
                f = f'study_{Path(opt.data).stem}_{Path(opt.weights).stem}.txt'  # filename to save to
                x, y = list(range(256, 1536 + 128, 128)), []  # x axis (image sizes), y axis
                for opt.imgsz in x:  # img-size
                    LOGGER.info(f'\nRunning {f} --imgsz {opt.imgsz}...')
                    r, _, t = run(**vars(opt), plots=False)
                    y.append(r + t)  # results and times
                np.savetxt(f, y, fmt='%10.4g')  # save
            os.system('zip -r study.zip study_*.txt')
            # 可视化各个指标
            plot_val_study(x=x)  # plot

# ----------------执行的第三步：用python执行该文件---------------------------------------
#当运行这个py文件时，会首先执行这里
if __name__ == "__main__":
    # opt = parse_opt()：解析终端命令行的参数，例如:--data data/VOC.yaml --weights runs/exp153/weights/best.pt --batch-size 1
    # 如果命令行没有写明的参数，会执行def parse_opt():中的默认参数，就是上面绿色字体的那部分
    opt = parse_opt() # 返回值：所有的参数
    main(opt) # 将参数又传给主函数 main
