import base64
import torch
a=torch.ones(2,1)
print('a=',a)