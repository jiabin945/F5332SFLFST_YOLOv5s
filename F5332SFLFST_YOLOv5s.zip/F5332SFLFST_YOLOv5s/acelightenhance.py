#单卡比多卡块
import os
os.environ['CUDA_VISIBLE_DEVICES'] = '2'
import cv2
import numpy as np
from tqdm import tqdm


def gamma_trans(img, gamma):
    '''
    首先归一化到0-1范围，然后gamma作为指数值求出新的像素值再还原
    '''
    gamma_table = [np.power(x / 255.0, gamma) * 255.0 for x in range(256)]
    gamma_table = np.round(np.array(gamma_table)).astype(np.uint8)

    return cv2.LUT(img, gamma_table)  # 作为一个查表的映射

# img = cv2.imread('/home/lhcz/sdb/jiabin/jb_project/datasets/imgs/.jpg')
# img3 = gamma_trans(img,0.75)

# def ALTM(img):
#     h, w = img.shape[:2]
#     res = np.float32(img)  # res = np.array(img, dtype=np.float32)  # 转换为32位图像
#     Lwmax = res.max()
#     log_Lw = np.log(0.001 + res)
#     Lw_sum = log_Lw.sum()
#     Lwaver = np.exp(Lw_sum / (h * w))
#     Lg = np.log(res / Lwaver + 1) / np.log(Lwmax / Lwaver + 1)
#
#     res = Lg * 255.0  # 不使用分段线性增强
#     # res = simple_balance(Lg, 2, 3)  # 使用线性增强，该算法比较耗时
#     dst = np.uint8(res)  # dst = cv2.convertScaleAbs(res)
#     return dst
#
# ALTM()

#ace
import cv2
import numpy as np
import math


def stretchImage(data, s=0.005, bins=2000):  # 线性拉伸，去掉最大最小0.5%的像素值，然后线性拉伸至[0,1]
    ht = np.histogram(data, bins);
    d = np.cumsum(ht[0]) / float(data.size)
    lmin = 0;
    lmax = bins - 1
    while lmin < bins:
        if d[lmin] >= s:
            break
        lmin += 1
    while lmax >= 0:
        if d[lmax] <= 1 - s:
            break
        lmax -= 1
    return np.clip((data - ht[1][lmin]) / (ht[1][lmax] - ht[1][lmin]), 0, 1)


g_para = {}


def getPara(radius=5):  # 根据半径计算权重参数矩阵
    global g_para
    m = g_para.get(radius, None)
    if m is not None:
        return m
    size = radius * 2 + 1
    m = np.zeros((size, size))
    for h in range(-radius, radius + 1):
        for w in range(-radius, radius + 1):
            if h == 0 and w == 0:
                continue
            m[radius + h, radius + w] = 1.0 / math.sqrt(h ** 2 + w ** 2)
    m /= m.sum()
    g_para[radius] = m
    return m


def zmIce(I, ratio=4, radius=300):  # 常规的ACE实现
    para = getPara(radius)
    height, width = I.shape
    zh, zw = [0] * radius + list(range(height)) + [height - 1] * radius, [0] * radius + list(range(width)) + [width - 1] * radius
    Z = I[np.ix_(zh, zw)]
    res = np.zeros(I.shape)
    for h in range(radius * 2 + 1):
        for w in range(radius * 2 + 1):
            if para[h][w] == 0:
                continue
            res += (para[h][w] * np.clip((I - Z[h:h + height, w:w + width]) * ratio, -1, 1))
    return res


def zmIceFast(I, ratio, radius):  # 单通道ACE快速增强实现
    height, width = I.shape[:2]
    if min(height, width) <= 2:
        return np.zeros(I.shape) + 0.5
    Rs = cv2.resize(I, ((width + 1) // 2, (height + 1) // 2))
    Rf = zmIceFast(Rs, ratio, radius)  # 递归调用
    Rf = cv2.resize(Rf, (width, height))
    Rs = cv2.resize(Rs, (width, height))

    return Rf + zmIce(I, ratio, radius) - zmIce(Rs, ratio, radius)


def zmIceColor(I, ratio=4, radius=3):  # rgb三通道分别增强，ratio是对比度增强因子，radius是卷积模板半径
    res = np.zeros(I.shape)
    for k in range(3):
        res[:, :, k] = stretchImage(zmIceFast(I[:, :, k], ratio, radius))
    return res


#原始图片的路径
filePath = '/media/king/243a6102-5ce5-4fea-8f08-27b212d33476/jiabin/jb_project/datasets/NEU-DET/NEU-DET/IMAGES' # the path of original imgs
file_list = os.listdir(filePath) ##os.listdir()返回指定路径下的文件和文件夹列表
#print(file_list)

for file_name in tqdm(file_list):
    print(file_name)
    path = os.path.join(filePath, file_name)
    m = zmIceColor(cv2.imread(path) / 255.0) * 255
#ace增强后的路径
    newFilePath='/media/king/243a6102-5ce5-4fea-8f08-27b212d33476/jiabin/jb_project/datasets/NEUACE/NEU-DET/IMAGES'#需要自己新建整个路径的文件夹
    newPath = os.path.join(newFilePath, file_name)
    cv2.imwrite(newPath, m)