# YOLOv5 🚀 by Ultralytics, GPL-3.0 license
"""
放的是模型的构造函数
由1detect层、2Model：整个Model构造。model初始化会调用parse_model。3parse_model：由model调用，parse_model会根据模型配置文件把模型一层层搭起来
判断读到的模块m是模型配置文件的是哪些模块，然后会构造出这些模块，最后根据m具体是什么来构造出需要的那一层
YOLO-specific modules
        这个模块是yolov5的模型搭建模块，非常的重要，不过代码量并不大，不是很难，
        只是yolov5的作者把封装的太好了，模型扩展了很多的额外的功能，导致看起来很难，其实真正有用的代码不多的。
        重点是抓住三个函数是在哪里调用的，谁调用谁的

Usage:
    $ python path/to/models/yolo.py --cfg yolov5s.yaml
"""

import argparse
import sys
from copy import deepcopy
from pathlib import Path

import models

FILE = Path(__file__).resolve()
ROOT = FILE.parents[1]  # YOLOv5 root directory
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))  # add ROOT to PATH
# ROOT = ROOT.relative_to(Path.cwd())  # relative

from models.common import *
from models.experimental import *
from utils.autoanchor import check_anchor_order
from utils.general import LOGGER, check_version, check_yaml, make_divisible, print_args
from utils.plots import feature_visualization
from utils.torch_utils import fuse_conv_and_bn, initialize_weights, model_info, scale_img, select_device, time_sync
from models.p9_neck.efficient_repgfpn import CSPStage
from models.componentpy.attention import *

try:
    import thop  # for FLOPs computation
except ImportError:
    thop = None

#detect层
class Detect(nn.Module):
    """
            Detect模块是用来构建Detect层的，将输入feature map 通过一个卷积操作和公式计算到我们想要的shape, 为后面的计算损失或者NMS作准备

        """

    stride = None  # strides computed during build
    onnx_dynamic = False  # ONNX export parameter

    def __init__(self, nc=80, anchors=(), ch=(), inplace=True):  # detection layer
        super().__init__()
        """
                        detection layer 相当于yolov3中的YOLOLayer层
                        :params nc: number of classes
                        :params anchors: 传入3个feature map上的所有anchor的大小（P3、P4、P5）
                        :params ch: [128, 256, 512] 3个输出feature map的channel
                """
        self.nc = nc  # number of classes  若是VOC，则类别为20
        #比如voc,20+5(种类+五个参数（中心点坐标+宽高）) xywhc+classes
        self.no = nc + 5  # number of outputs per anchor,：xywhc+classes
        #因为anchors嵌套了三个尺度的列表，所以为3
        self.nl = len(anchors)  # number of detection layers(要做检测的特征图层数为3) Detect的个数 3
        self.na = len(anchors[0]) // 2  # number of anchors（每个尺度上anchor数目为3）
        self.grid = [torch.zeros(1)] * self.nl  # init grid，是一个列表，初始化为0
        self.anchor_grid = [torch.zeros(1)] * self.nl  # init anchor grid

        # a=[3, 3, 2]  anchors以[w, h]对的形式存储  3个feature map 每个feature map上有三个anchor（w,h）
        # a = torch.tensor(anchors).float().view(self.nl, -1, 2)

        # register_buffer
        # 模型中需要保存的参数一般有两种：
        # 一种是反向传播需要被optimizer更新的，即参与训练的参数称为parameter，optim.step只能更新nn.parameter类型的参数
        # 另一种不要被更新，即不参与训练的参数称为buffer，buffer的参数更新是在forward中。
        # shape(nl,na,2),其中view表示重新调整Tensor的形状。原来tensor(anchors)有18（9个anchor*2宽高）
        #后来view成一维nl=3,二维-1表示自动调整，三维为2，容易得到二维为3，即na
        # self.register_buffer('anchors', a)
        self.register_buffer('anchors', torch.tensor(anchors).float().view(self.nl, -1, 2))  # shape(nl,na,2)
        # output conv 对每个输出的feature map都要调用一次conv1x1,得到三个conv
        #ModuleList:可以用来搭建神经网络，用来存储各个模块，模块前后没有关联，这里搭建dedect神经网络
        #x:输入的通道数  self.no * self.na：128,256,512  输出通道数：anchor数量*每一个anchor输出的channel  k=1
        #ch:输入detect中的三个卷积的channel大小，而三个卷积输出的channel是每个卷积对应的anchor数量（3）*（种类+5）
        self.m = nn.ModuleList(nn.Conv2d(x, self.no * self.na, 1) for x in ch)  # output conv
        # use in-place ops (e.g. slice assignment) 一般都是True 默认不使用AWS Inferentia加速
        self.inplace = inplace  # use in-place ops (e.g. slice assignment)

    def forward(self, x):
        z = []  # inference output

        logits_ = []  # 修改---1

        for i in range(self.nl):
            x[i] = self.m[i](x[i])  # conv
            bs, _, ny, nx = x[i].shape  # x(bs,255,20,20) to x(bs,3,20,20,85)
            x[i] = x[i].view(bs, self.na, self.no, ny, nx).permute(0, 1, 3, 4, 2).contiguous()

            if not self.training:  # inference
                if self.onnx_dynamic or self.grid[i].shape[2:4] != x[i].shape[2:4]:
                    self.grid[i], self.anchor_grid[i] = self._make_grid(nx, ny, i)

                logits = x[i][..., 5:]  # 修改---2

                y = x[i].sigmoid()
                if self.inplace:
                    y[..., 0:2] = (y[..., 0:2] * 2 - 0.5 + self.grid[i]) * self.stride[i]  # xy
                    y[..., 2:4] = (y[..., 2:4] * 2) ** 2 * self.anchor_grid[i]  # wh
                else:  # for YOLOv5 on AWS Inferentia https://github.com/ultralytics/yolov5/pull/2953
                    xy = (y[..., 0:2] * 2 - 0.5 + self.grid[i]) * self.stride[i]  # xy
                    wh = (y[..., 2:4] * 2) ** 2 * self.anchor_grid[i]  # wh
                    y = torch.cat((xy, wh, y[..., 4:]), -1)
                z.append(y.view(bs, -1, self.no))

                logits_.append(logits.view(bs, -1, self.no - 5))  # 修改---3

        return x if self.training else (torch.cat(z, 1), x)
        #return x if self.training else (torch.cat(z, 1), torch.cat(logits_, 1), x)  # 修改---4 #在热力图时候使用，返回预测框坐标、得分和分类

    def _make_grid(self, nx=20, ny=20, i=0):
        d = self.anchors[i].device
        if check_version(torch.__version__, '1.10.0'):  # torch>=1.10.0 meshgrid workaround for torch>=0.7 compatibility
            yv, xv = torch.meshgrid([torch.arange(ny, device=d), torch.arange(nx, device=d)], indexing='ij')
        else:
            yv, xv = torch.meshgrid([torch.arange(ny, device=d), torch.arange(nx, device=d)])
        grid = torch.stack((xv, yv), 2).expand((1, self.na, ny, nx, 2)).float()
        anchor_grid = (self.anchors[i].clone() * self.stride[i]) \
            .view((1, self.na, 1, 1, 2)).expand((1, self.na, ny, nx, 2)).float()
        return grid, anchor_grid

#模型构造函数，被train中的model = Model(cfg, ch=3, nc=nc, anchors=hyp.get('anchors')).to(device)调用
class Model(nn.Module):
    #__init__函数：类似构造函数，主要功能为从yaml中初始化model中各种变量包括网络模型model、通道ch，分类数nc，锚框anchor和三层输出缩放倍数stride等。
    def __init__(self, cfg='yolov5s.yaml', ch=3, nc=None, anchors=None):  # model, input channels, number of classes
        """
                        自己知道训练时候调用
                        Model主要包含模型的搭建与扩展功能，yolov5的作者将这个模块的功能写的很全，
                            扩展功能如：特征可视化，打印模型信息、TTA推理增强、融合Conv+Bn加速推理、模型搭载nms功能、autoshape函数：
                            模型搭建包含前处理、推理、后处理的模块(预处理 + 推理 + nms)。
                        感兴趣的可以仔细看看，不感兴趣的可以直接看__init__和__forward__两个函数即可。

                        :params cfg:模型配置文件
                        :params ch: input img channels 一般是3 RGB文件
                        :params nc: number of classes 数据集的类别个数
                        :anchors: 一般是None
                """
        super().__init__()
        #ifELSE作用就是：如果模型配置文件名是字典类型，就赋给self.yaml;否则将字符串类型转换为字典类型
        #首先去加载yaml文件 因为cfg是'models/yolov5s.yaml'，是字符串类型，所以不是dict
        if isinstance(cfg, dict):
            self.yaml = cfg  # model dict
        else:  # is *.yaml 一般执行这里
            import yaml  # for torch hub
            self.yaml_file = Path(cfg).name #得到yaml文件名  yolo5s.yaml
            # 如果配置文件中有中文，打开时要加encoding参数
            with open(cfg, encoding='ascii', errors='ignore') as f:
                # model dict  取到配置文件中每条的信息（没有注释内容） safe_load：把yaml文件字符串个格式变为python中的字典形式
                self.yaml = yaml.safe_load(f)  # model dict

        '''
        		接着判断yaml中是否有设置输入图像的通道ch，如果没有就默认为3。
        		接着判断分类总数nc和anchor与yaml中是否一致，如果不一致，则使用init函数参数中指定的nc和anchor。
        		'''
        # Define model  ,意思若yaml中如果有ch，就用get里面得到('ch', ch)中的‘ch’指定键的值,如果没有ch，所以用('ch', ch)中后面的ch来代替（此ch为传入的ch=3）
        ch = self.yaml['ch'] = self.yaml.get('ch', ch)  # input channels
        # 设置类别数 一般不执行, 因为nc=self.yaml['nc']恒成立
        #比较传入进来的配置文件中的nc(yaml['nc'])与传入进来的nc比较，不相同就执行if(其实恒成立)
        if nc and nc != self.yaml['nc']:
            #意思用形参nc代替模型配置文件中的nc
            LOGGER.info(f"Overriding model.yaml nc={self.yaml['nc']} with nc={nc}")
            #可以看出，传入的nc（即使用的数据集中的种类）的比模型中的原先定义种类的优先级更高
            self.yaml['nc'] = nc  # override yaml value，nc以数据集配置文件传进来的nc为主，而不是模型中配置文件的nc为主
        # 重写anchor，一般不执行, 因为传进来的anchors一般都是None
        #过程：train调用，里面的Model(anchors=hyp.get('anchors')），而在超参文件中anchors被注释了，所以这里传过来的为none
        if anchors:#因为从train中传来的hyp中么有anchors这个字段的，所以这里为none
            LOGGER.info(f'Overriding model.yaml anchors with anchors={anchors}')
            self.yaml['anchors'] = round(anchors)  # override yaml value

        '''
               读取yaml中的网络结构并实例化
               '''
        #创建网络模型，调用parse_model函数对模型配置文件如yolo5s.yaml进行翻译,一层一层构建，最终形成model，
        # self.model: 初始化的整个网络模型(包括Detect层结构)
        # self.save: 所有层结构中from不等于-1的序号，并排好序  [4, 6, 10, 14, 17, 20, 23]
        #save（保存的是不进行梯度的参数）在forward中使用
        #“deepcopy 是 Python 的一个内建函数,它可以用来深度复制一个对象。这意味着,它不会只复制对象的引用,而是会创建一个新的对象,其内容和原对象完全相同。
        self.model, self.save = parse_model(deepcopy(self.yaml), ch=[ch])  # model, savelist
        # default class names index ['0', '1', '2',..., '19']
        self.names  = [str(i) for i in range(self.yaml['nc'])]  # default names

        # self.inplace=True  默认True  不使用加速推理
        # AWS Inferentia Inplace compatiability
        # https://github.com/ultralytics/yolov5/pull/2953
        self.inplace = self.yaml.get('inplace', True)

        '''
        		为求输出层的stride,在detect层做模型的前向传播
        		最后来计算图像从输入到输出的缩放倍数和anchor在head上的大小
        		'''
        # 获取Detect模块的stride(相对输入图像的下采样率)和anchors在当前Detect输出的feature map的尺度
        # Build strides, anchors
        '''
                1，获取结构最后一层Detect层，前向传播
                '''
        m = self.model[-1]  # Detect()
        #如果m是Detect最后一层
        #if isinstance(m, Detect):#原yolo的
        if isinstance(m, Detect) or isinstance(m, Decoupled_Detect):
            # s = 256  # 2x min stride，输入的高
            s = 256
            m.inplace = self.inplace
            # 计算三个feature map下采样的倍率  [8, 16, 32]
            # 假设640X640的图片大小，在最后三层时分别乘1/8 1/16 1/32，得到80，40，20
            #理解：torch.zeros(1, ch, s, s)：bat,ch,h,w,把它送到detect层的self.forward(即detect中的forward，感觉是整个模型的forward）中去，得到输出的(1, ch, s, s)，再把输出的高x.shape[-2]
            #取出来，用原来的输入的高/输出高得到stride大小tensor([ 8., 16., 32.])
            m.stride = torch.tensor([s / x.shape[-2] for x in self.forward(torch.zeros(1, ch, s, s))])  # forward
            # 将当前anchor的大小处理成相对当前feature map的大小 如[10, 13]/8 -> [1.25, 1.625]
            m.anchors /= m.stride.view(-1, 1, 1)
            # 检查anchor顺序与stride顺序是否一致，因为stride=8适合小目标检测，因为感受野不是特别大，
            #那么anchor也是从小到大顺序执行的，如果不对则会做调整
            check_anchor_order(m)
            self.stride = m.stride
            self._initialize_biases()  # only run once 初始化偏置bias
            # try:
            #     self._initialize_biases()  # only run once
            #     LOGGER.info('initialize_biases done')
            # except:
            #     LOGGER.info('decoupled no biase ')
        # Init weights, biases
        initialize_weights(self)  # 调用torch_utils.py下initialize_weights初始化模型权重
        self.info()  # 打印模型信息
        LOGGER.info('')

    def forward(self, x, augment=False, profile=False, visualize=False):
        # augmented inference, None  上下flip/左右flip
        # 是否在测试时也使用数据增强  Test Time Augmentation(TTA)
        if augment:
            return self._forward_augment(x)  # augmented inference, None
        # 默认执行 正常前向推理
        # single-scale inference, train
        return self._forward_once(x, profile, visualize)  # single-scale inference, train

    def _forward_augment(self, x):
        img_size = x.shape[-2:]  # height, width
        s = [1, 0.83, 0.67]  # scales
        f = [None, 3, None]  # flips (2-ud, 3-lr)
        y = []  # outputs
        for si, fi in zip(s, f):
            # scale_img缩放图片尺寸
            xi = scale_img(x.flip(fi) if fi else x, si, gs=int(self.stride.max()))
            yi = self._forward_once(xi)[0]  # forward
            # cv2.imwrite(f'img_{si}.jpg', 255 * xi[0].cpu().numpy().transpose((1, 2, 0))[:, :, ::-1])  # save
            # _descale_pred将推理结果恢复到相对原图图片尺寸
            yi = self._descale_pred(yi, fi, si, img_size)
            y.append(yi)
        y = self._clip_augmented(y)  # clip augmented tails
        return torch.cat(y, 1), None  # augmented inference, train

    def _forward_once(self, x, profile=False, visualize=False):
        """
                    :params x: 输入图像
                    :params profile: True 可以做一些性能评估
                    :params feature_vis: True 可以做一些特征可视化
                    :return train: 一个tensor list 存放三个元素   [bs, anchor_num, grid_w, grid_h, xywh+c+20classes]
                                   分别是 [1, 3, 80, 80, 25] [1, 3, 40, 40, 25] [1, 3, 20, 20, 25]
                            inference: 0 [1, 19200+4800+1200, 25] = [bs, anchor_num*grid_w*grid_h, xywh+c+20classes]
                                       1 一个tensor list 存放三个元素 [bs, anchor_num, grid_w, grid_h, xywh+c+20classes]
                                         [1, 3, 80, 80, 25] [1, 3, 40, 40, 25] [1, 3, 20, 20, 25]
                """
        # y: 存放着self.save=True的每一层的输出，因为后面的层结构concat等操作要用到
        # dt: 在profile中做性能评估时使用
        y, dt = [], []  # outputs
        for m in self.model:
            # 前向推理每一层结构   m.i=index   m.f=from   m.type=类名   m.np=number of params
            # if not from previous layer   m.f=当前层的输入来自哪一层的输出  s的m.f都是-1
            if m.f != -1:  # if not from previous layer
                # 这里需要做4个concat操作和1个Detect操作
                # concat操作如m.f=[-1,6] x就有两个元素,一个是上一层的输出,另一个是index=6的层的输出 再送到x=m(x)做concat操作
                # Detect操作m.f=[17, 20, 23] x有三个元素,分别存放第17层第20层第23层的输出 再送到x=m(x)做Detect的forward
                x = y[m.f] if isinstance(m.f, int) else [x if j == -1 else y[j] for j in m.f]  # from earlier layers
            # 打印日志信息  FLOPs time等
            # 打印日志信息  前向推理时间
            if profile:
                self._profile_one_layer(m, x, dt)
            x = m(x)   # run正向推理  执行每一层的forward函数(除Concat和Detect操作)
            # print('层数',i,'特征图大小',x.shape)

            # 存放着self.save的每一层的输出，因为后面需要用来作concat等操作要用到  不在self.save层的输出就为None
            y.append(x if m.i in self.save else None)  # save output

            # 特征可视化 可以自己改动想要哪层的特征进行可视化
            if visualize:
                feature_visualization(x, m.type, m.i, save_dir=visualize)
        return x

    def _descale_pred(self, p, flips, scale, img_size):
        """
                    用在上面的__init__函数上
                        将推理结果恢复到原图图片尺寸  Test Time Augmentation(TTA)中用到
                        de-scale predictions following augmented inference (inverse operation)
                        :params p: 推理结果
                        :params flips:
                        :params scale:
                        :params img_size:
                """
        # 不同的方式前向推理使用公式不同 具体可看Detect函数
        # de-scale predictions following augmented inference (inverse operation)
        if self.inplace:    # 默认执行 不使用AWS Inferentia
            p[..., :4] /= scale  # de-scale
            if flips == 2:
                p[..., 1] = img_size[0] - p[..., 1]  # de-flip ud
            elif flips == 3:
                p[..., 0] = img_size[1] - p[..., 0]  # de-flip lr
        else:
            x, y, wh = p[..., 0:1] / scale, p[..., 1:2] / scale, p[..., 2:4] / scale  # de-scale
            if flips == 2:
                y = img_size[0] - y  # de-flip ud
            elif flips == 3:
                x = img_size[1] - x  # de-flip lr
            p = torch.cat((x, y, wh, p[..., 4:]), -1)
        return p

    def _clip_augmented(self, y):
        # Clip YOLOv5 augmented inference tails
        nl = self.model[-1].nl  # number of detection layers (P3-P5)
        g = sum(4 ** x for x in range(nl))  # grid points
        e = 1  # exclude layer count
        i = (y[0].shape[1] // g) * sum(4 ** x for x in range(e))  # indices
        y[0] = y[0][:, :-i]  # large
        i = (y[-1].shape[1] // g) * sum(4 ** (nl - 1 - x) for x in range(e))  # indices
        y[-1] = y[-1][:, i:]  # small
        return y

    def _profile_one_layer(self, m, x, dt):
        c = isinstance(m, Detect)  # is final layer, copy input as inplace fix
        o = thop.profile(m, inputs=(x.copy() if c else x,), verbose=False)[0] / 1E9 * 2 if thop else 0  # FLOPs
        t = time_sync()
        for _ in range(10):
            m(x.copy() if c else x)
        dt.append((time_sync() - t) * 100)
        if m == self.model[0]:
            LOGGER.info(f"{'time (ms)':>10s} {'GFLOPs':>10s} {'params':>10s}  {'module'}")
        LOGGER.info(f'{dt[-1]:10.2f} {o:10.2f} {m.np:10.0f}  {m.type}')
        if c:
            LOGGER.info(f"{sum(dt):10.2f} {'-':>10s} {'-':>10s}  Total")

    def _initialize_biases(self, cf=None):  # initialize biases into Detect(), cf is class frequency
        """用在上面的__init__函数上
                        initialize biases into Detect(), cf is class frequency
                        https://arxiv.org/abs/1708.02002 section 3.3
                        """
        # cf = torch.bincount(torch.tensor(np.concatenate(dataset.labels, 0)[:, 0]).long(), minlength=nc) + 1.
        m = self.model[-1]  # Detect() module
        for mi, s in zip(m.m, m.stride):  # from
            b = mi.bias.view(m.na, -1)  # conv.bias(255) to (3,85)
            b.data[:, 4] += math.log(8 / (640 / s) ** 2)  # obj (8 objects per 640 image)
            b.data[:, 5:] += math.log(0.6 / (m.nc - 0.999999)) if cf is None else torch.log(cf / cf.sum())  # cls
            mi.bias = torch.nn.Parameter(b.view(-1), requires_grad=True)

    def _print_biases(self):
        """
                        打印模型中最后Detect层的偏置bias信息(也可以任选哪些层bias信息)
                """
        m = self.model[-1]  # Detect() module
        for mi in m.m:  # from
            b = mi.bias.detach().view(m.na, -1).T  # conv.bias(255) to (3,85)
            LOGGER.info(
                ('%6g Conv2d.bias:' + '%10.3g' * 6) % (mi.weight.shape[1], *b[:5].mean(1).tolist(), b[5:].mean()))

    # def _print_weights(self):
    #     for m in self.model.modules():
    #         if type(m) is Bottleneck:
    #             LOGGER.info('%10.3g' % (m.w.detach().sigmoid() * 2))  # shortcut weights

    def fuse(self):  # fuse model Conv2d() + BatchNorm2d() layers
        """用在detect.py、val.py
                       fuse model Conv2d() + BatchNorm2d() layers
                       调用torch_utils.py中的fuse_conv_and_bn函数和common.py中Conv模块的fuseforward函数
                       """
        LOGGER.info('Fusing layers... ') # 日志
        # 遍历每一层结构
        for m in self.model.modules():
            # 如果当前层是卷积层Conv且有bn结构, 那么就调用fuse_conv_and_bn函数讲conv和bn进行融合, 加速推理
            if isinstance(m, (Conv, DWConv)) and hasattr(m, 'bn'):
                m.conv = fuse_conv_and_bn(m.conv, m.bn)  # 融合 update conv
                delattr(m, 'bn')  # 移除bn remove batchnorm
                m.forward = m.forward_fuse  # # 更新前向传播 update forward (反向传播不用管, 因为这种推理只用在推理阶段)
        self.info()  # 打印conv+bn融合后的模型信息
        return self

    def info(self, verbose=False, img_size=640):  # print model information
        """
                    用在上面的__init__函数上
                        调用torch_utils.py下model_info函数打印模型信息
                """
        model_info(self, verbose, img_size)

    def _apply(self, fn):
        # Apply to(), cpu(), cuda(), half() to model tensors that are not parameters or registered buffers
        self = super()._apply(fn)
        m = self.model[-1]  # Detect()
        if isinstance(m, Detect):
            m.stride = fn(m.stride)
            m.grid = list(map(fn, m.grid))
            if isinstance(m.anchor_grid, list):
                m.anchor_grid = list(map(fn, m.anchor_grid))
        return self

    #解耦头的内容
    def _initialize_dh_biases(self, cf=None):  # initialize biases into Detect(), cf is class frequency
        # https://arxiv.org/abs/1708.02002 section 3.3
        # cf = torch.bincount(torch.tensor(np.concatenate(dataset.labels, 0)[:, 0]).long(), minlength=nc) + 1.
        m = self.model[-1]  # Detect() module
        for mi, s in zip(m.m, m.stride):  # from
            # reg_bias = mi.reg_preds.bias.view(elif m in {Detectm.na, -1).detach()
            # reg_bias += math.log(8 / (640 / s) ** 2)
            # mi.reg_preds.bias = torch.nn.Parameter(reg_bias.view(-1), requires_grad=True)

            # cls_bias = mi.cls_preds.bias.view(m.na, -1).detach()
            # cls_bias += math.log(0.6 / (m.nc - 0.999999)) if cf is None else torch.log(cf / cf.sum())  # cls
            # mi.cls_preds.bias = torch.nn.Parameter(cls_bias.view(-1), requires_grad=True)
            b = mi.b3.bias.view(m.na, -1)
            b.data[:, 4] += math.log(8 / (640 / s) ** 2)  # obj (8 objects per 640 image)
            mi.b3.bias = torch.nn.Parameter(b.view(-1), requires_grad=True)
            b = mi.c3.bias.data
            b += math.log(0.6 / (m.nc - 0.999999)) if cf is None else torch.log(cf / cf.sum())  # cls
            mi.c3.bias = torch.nn.Parameter(b, requires_grad=True)

#由class model初始化时调用的,parse_model模型配置文件根据yolo5.yaml配置文件把整个模型一层一层搭建起来
#ch记录的所有层输出的channel
def parse_model(d, ch):  # model_dict, input_channels(3)
    """
            主要功能：parse_model模块用来解析模型文件(从Model中传来的字典形式)，并搭建网络结构。
            在上面Model模块的__init__函数中调用

            这个函数其实主要做的就是: 更新当前层的args（参数）,计算c2（当前层的输出channel） =>
                                  使用当前层的参数搭建当前层 =>
                                  生成 layers + save

            :params d: model_dict 模型文件 字典形式 {dict:7}  yolov5s.yaml中的6个元素 + ch
            :pate'stestrams ch: 记录模型每一层的输出channel 初始ch=[3] 后面会删除
            :return nn.Sequential(*layers): 网络的每一层的层结构
            :return sorted(save): 把所有层结构中from不是-1的值记下 并排序 [4, 6, 10, 14, 17, 20, 23]
        """
    # 字符串前加f表示字符串内支持大括号内的python表达式,'':>3表示左边空白距离为3。'module':<40表示module右边空白距离为40
    LOGGER.info(f"\n{'':>3}{'from':>18}{'n':>3}{'params':>10}  {'module':<40}{'arguments':<30}")
    # 读取d字典中(配置文件)的anchors和parameters(nc、depth_multiple、width_multiple)
    #  nc（numbe  r of classes）数据集类别个数；
    # depth_multiple，通过深度参数depth gain在搭建每一层的时候，实际深度 = 理论深度(每一层的参数n) * depth_multiple，起到一个动态调整模型深度的作用。
    # width_multiple，在模型中间层的每一层的实际输出channel = 理论channel(每一层的参数c2) * width_multiple，起到一个动态调整模型宽度的作用。
    anchors, nc, gd, gw = d['anchors'], d['nc'], d['depth_multiple'], d['width_multiple']
    # na: number of anchors 每一个predict head上的anchor数 = 3
    #因为anchor[0]:[10, 13, 16, 30, 33, 23],是由宽高组成的，除以2取整即为一层中anchors的数量
    na = (len(anchors[0]) // 2) if isinstance(anchors, list) else anchors  # number of anchors

    # no: number of outputs 每一个predict head层的输出channel = anchors * (classes + 5) = 75(VOC)
    no = na * (nc + 5)  # number of outputs = anchors * (classes + 5)

    # 开始搭建网络,一层一层构建
    # layers: 保存每一层的层结构
    # save: 记录下所有层结构中from中不是-1的层结构序号
    # c2: 保存当前层的输出channel  ch是用来保存之前所有的模块输出的channel（所以ch[-1]代表着上一个模块的输出通道）。
    layers, save, c2 = [], [], ch[-1]  # layers（存放每一层模型）, savelist（需要把哪些层输出保存起来，保存那些层的index）, ch out
    # from(当前层输入来自哪些层), number(当前层次数 初定), module(当前层类别), args(当前层类参数 初定)
    #对每一层进行迭代
    for i, (f, n, m, args) in enumerate(d['backbone'] + d['head']):  # from, number, module, args
        # eval(string) 通过eval接口，得到当前层的真实类名，即实现字符串名向类的转换，得到m对应的类，类在common中定义
        # 例如: 第一层：由原来m,也就是Conv，通过eval，变为了<class 'models.common.Conv'>，这个类在models.common中定义好了
        m = eval(m) if isinstance(m, str) else m   # 将字符串处理成一个类名 或者 字符串，即实现名字向类的转换
        #对此层的args部分进行迭代，如果是字符串，则执行eval函数，变字符串为common中的一个类名
        #j:序号（因为有enumerate，就多了这么一个） a:args列表中的每一位元素
        for j, a in enumerate(args):   # 主要照顾 yolo.yaml文件中最后一列的, [nc, anchors]，即为字符串的
            try:
                #第一次循环这里a是64，不是字符串，不执行；但是若是字符串，则执行eval(a)，把原来args中的东西对应的真实值放入到现在的args中
                #例子：第一次上采样的args:[None, 2, 'nearest'],none变为了在python中的关键字none;
                #nearest:因为python中并没有关键字代表nearest，所以执行except NameError:，把其忽略掉
                #例子2：最后一层args:[nc, anchors],nc在eval后变为20（因为训练集使用VOC数据集，数据集对应的voc.yaml中定义的就是20），anchors变为
                #[[10, 13, 16, 30, 33, 23], [30, 61, 62, 45, 59, 119], [116, 90, 156, 198, 373, 326]]（因为voc.yaml中定义就是这样）
                args[j] = eval(a) if isinstance(a, str) else a  # eval strings
            except NameError:
                pass

        # ------------------- 更新当前层的args（参数）,计算c2（当前层的输出channel） -------------------
        # depth gain 控制深度  如v5s: n*0.33   n: 当前模块的次数(间接控制深度)   round函数用来返回一个浮点数的四舍五入值
        #注意对于c3，这里的n是指bottleneck中的个数
        n = n_ = max(round(n * gd), 1) if n > 1 else n  # depth gain
        #这里if-else其实是在构建此module（模块）真正的args（包括真输入通道、真输出通道(原定的通道数*通道因子)，k,p,s），ifelse以后就m(*args)进入commom.py初始化就得到这一层的模块
        #m：当前层真实类名，第一层是Conv，所以就进来了
        if m in [Conv, GhostConv, Bottleneck, GhostBottleneck, SPP, SPPF, DWConv, MixConv2d, Focus, CrossConv,
                 BottleneckCSP, C3, C3TR, C3SPP, C3Ghost,
                 SELayer,ConvBNHswish,MblNetV3_Blk,
                 ConvBNReLUMaxpool, ShuffleNet_Blk,
                 MogaBlock,
                 PatchEmbed,BasicStage,PatchMerging,FasterNeXt,FasterNeXt1,FasterNeXt2,FasterNeXt3,FasterNeXt4,
                 DP_Conv,DP_C3,
                 ConvBnAct,GhostBottleneckV2,GhostV2Conv,C3GhostV2,
                 ConvBNReLU,InvertedResidual,InvertedResidual_parc,
                 CbamimpBasicStage,CbamBasicStage,SEAttention,CBAM,cbam_block,CoordAtt,FcaBasicBlock,FcaLayer,
                 ACmix,GAMAttention,C3_GAM,C3_GAM1,C3_GAM2,C3_GAM3,C3_GAM4,FasterNeXt_GAM,BasicStagegam,C3_ParNet,C3_ParNet1,ShuffleAttention,
                 C2f,gamC2f,CSPStage,CARAFE,nn.ConvTranspose2d,
                 falconstem,c2f_fb,c2f_fbandpconv,C3_SA,C3_SA1,SimAM,CrissCrossAttention,C3_SAM,C3_SAM1,ODConv2d,
                 LSK,C3_LSK,C3_LSK1,C3_LSK2,FasterNeXt_LSK,BasicStagelsk,ScConv,
                 C3_EMA,C3_EMA1,C3_EMA2,C3_EMA3,C3_EMA4,ECAGAM,LSKB,LSK_Bottleneck,LSK_Bottleneck1,LSK_Bottleneck2,
                 CBAM_Bottleneck,CBAM_Bottleneck1,CBAM_Bottleneck2]:
            # c1: 当前层的输入的channel数，f是-1,即ch[-1]表示ch的最后一个元素。因为只有一个元素[3]，所以第一次只会提取出来3
            # c2: 当前层的输出的channel数(初定。因为不同的结构通道数不一样)  arg中第一个参数，第一次输出为64
            # ch: 传入进来的，记录着所有层的输出channel，f代表该ch中最后一个，即对一下一层来说，这就是-1层的输入
            c1, c2 = ch[f], args[0]  #  第一次args[0]为[-1, 1, Conv, [64,6, 2，2]]这的64
            # if not output  no=75  只有最后一层c2=no  最后一层不用控制宽度，输出channel必须是no
            if c2 != no:  # if not output（即不是最终输出）
                # width gain 控制宽度  如v5s: c2*width_multiple（yolo.yaml）

                # c2: 当前层的最终输出的channel数(间接控制宽度)
                #用8去规整成c2 * gw（实际的输出通道数）8的倍数，因为在cuda中，channel是8的倍数的话，运算会更快
                c2 = make_divisible(c2 * gw, 8)
            # 在初始arg的基础上更新 加入当前层的输入channel、真正的输出channel,arg中除了原来的原定的channel之外的参数
            # 并更新当前层   比如第一层args：由[原定的输出通道数, k, p, s]变为[输入通道数、实际的输出通道数(原定输出通道数*width_multiple)、k,p,s]
            # [in_channel, out_channel, *args[1:]]
            #这才是对应模型的真正的args（根据模型配置文件得到的）
            args = [c1, c2, *args[1:]]
            # 如果当前层是BottleneckCSP/C3/C3TR, 则需要在args中加入bottleneck的个数
            # [in_channel, out_channel, Bottleneck的个数n, bool(True表示有shortcut 默认，反之无)]
            if m in [BottleneckCSP, C3, C3TR, C3Ghost,FasterNeXt,FasterNeXt1,FasterNeXt2,FasterNeXt3,FasterNeXt4,C3_GAM,
                     C3_GAM1,C3_GAM2,C3_GAM3,C3_GAM4,FasterNeXt_GAM,C3_ParNet,C3_ParNet1,C2f,gamC2f,CSPStage,c2f_fb,c2f_fbandpconv,C3_SA,C3_SA1,C3_SAM,C3_SAM1,
                     C3_LSK,C3_LSK1,C3_LSK2,FasterNeXt_LSK,C3_EMA,C3_EMA1,C3_EMA2,C3_EMA3,C3_EMA4,C3_ECA,C3_ECA1,C3_ECA2,C3_ECA3,C3_ECA4,]:
                args.insert(2, n)  # number of repeats # 在索引为2的位置插入bottleneck个数n
                n = 1 # 恢复默认值1
            elif m is nn.ConvTranspose2d:
                if len(args) >= 7:
                    args[6] = make_divisible(args[6] * gw, 8)
        elif m is SKAttention:
            c1, c2 = ch[f], args[0]
            if c2 != no:
                c2 = make_divisible(c2 * gw, 8)
            args = [c1, *args[1:]]
        elif m is nn.BatchNorm2d:
            # BN层只需要返回上一层的输出channel
            args = [ch[f]]
        elif m is EMA:
            args = [ch[f], *args]
        elif m is ASFF2:
            c1, c2 = [ch[f[0]], ch[f[1]]], args[0]
            c2 = make_divisible(c2 * gw, 8)
            args = [c1, c2, *args[1:]]
        elif m is ASFF3:
            c1, c2 = [ch[f[0]], ch[f[1]], ch[f[2]]], args[0]
            c2 = make_divisible(c2 * gw, 8)
            args = [c1, c2, *args[1:]]
        elif m is Concat:
            # Concat层则将f中所有的输出channel求和得到这层的输出channel
            c2 = sum(ch[x] for x in f) # 因为这个[[-1, 6], 1, Concat, [1]] 的第一个是个列表，所以需要遍历，然后将-1, 6层的输入加起来
        # 添加bifpn_add结构
        elif m in [BiFPN_Add2, BiFPN_Add3]:
            c2 = max([ch[x] for x in f])
        elif m is Detect:  # Detect（YOLO Layer）层  #原v5的内容
            # 在args中加入三个Detect层（17，20，23）的输出channel，args由[20, [[10, 13, 16, 30, 33, 23], [30, 61, 62, 45, 59, 119], [116, 90, 156, 198, 373, 326]]]变为后面加128，256，512这个列表
            args.append([ch[x] for x in f])
            if isinstance(args[1], int):  # number of anchors  几乎不执行
                args[1] = [list(range(args[1] * 2))] * len(f)
        #elif m in {Detect, ASFF_Detect, Decoupled_Detect}:
            # args.append([ch[x] for x in f])
            # if isinstance(args[1], int):  # number of anchors
            #     args[1] = [list(range(args[1] * 2))] * len(f)
        elif m is Contract:
            c2 = ch[f] * args[0] ** 2
        elif m is Expand:
            c2 = ch[f] // args[0] ** 2
        # elif m is CARAFE:
        #     c2 = ch[f]
        #     args = [c2, *args]
        elif m in [eca1,ECASAM]:
            channel= args[0]
            #channel = make_divisible(channel * gw, 8) if channel != no else channel
            args = [channel]
        # elif m is eca2:
        #     channel, k_size = args[0], args[1]
        #     channel = make_divisible(channel * gw, 8) if channel != no else channel
        #     args = [channel, k_size]
        else:#例如upsample
            c2 = ch[f]  # 输出通道与输入通道数一致,

        #module（模块即层的初始化），把可变长args作为参数，经过m类调用,进入common.py中（在common中对应的模块def打断点，调试执行完这步直接跳转到common中对应模块）
        # m_: 得到当前层module  如果n>1就创建多个m(当前层结构), 如果n=1就创建一个m，即调用common中的对应模块组件（也有可能是common之外的torch自带原生的组件，也有的是本yolo.py自带的，如最后一层detect）
        #举例：第一层前面m是<class 'models.common.Conv'>，所以这里m(*args)会调用Conv类，构建Conv(cbs)
        #举例：第一次上采样时m(*args)：它的输入的参数用nearest方法，宽高变为原来两倍，其他不变
        # n只有在[BottleneckCSP, C3, C3TR]中才会用到.  另外for _ in range(n)中_表示不需要关心变量的值，这时可以用_代替常用的i
        #*在python中做函数形参，意味着1参数的个数不止一个，2另外带一个星号（*）参数的函数传入的参数存储为一个元组（tuple），带两个（*）号则是表示字典（dict）可以表示一个可变长度的序列
        m_ = nn.Sequential(*(m(*args) for _ in range(n))) if n > 1 else m(*args)  # module

        # 打印当前层结构的一些基本信息
        #str(m)[8:-2]:'models.common.Conv',如果其中有__main__,则用空替换掉，即去掉__main__，最终得到t
        t = str(m)[8:-2].replace('__main__.', '')  # module type
        np = sum(x.numel() for x in m_.parameters())  # number params（这一层，比如第一次的Conv中参数） numel()函数:返回数组中元素的个数
        #模块索引：0 上一层索引：-1 类型：models.common.Conv np(模块参数):3520
        m_.i, m_.f, m_.type, m_.np = i, f, t, np  # attach index, 'from' index, type, number params
        #打印这些参数
        LOGGER.info(f'{i:>3}{str(f):>18}{n_:>3}{np:10.0f}  {t:<40}{str(args):<30}')  # print

        # append to savelist  把所有层结构中from不是-1的值记下 ，比如12层6，16层的4 [6, 4, 14, 10, 17, 20, 23]。这句话意思不管ifelse都会把f变成列表
        #举例：第一次concat[-1,6],因为这是列表不是int,所以执行else.另外6满足条件，6（x）%13(i)==6,保存到save中。其实不是-1的层不会超过当前层的层数的，所以对i取余还是x
        save.extend(x % i for x in ([f] if isinstance(f, int) else f) if x != -1)  # append to savelist

        # 将当前层结构module加入layers中
        layers.append(m_)
        if i == 0:
            ch = []  # 去除输入channel [3]

        # 把当前层的输出channel数加入ch，构造下一个模块时把上一个模块的输出当做下一个模块的输入
        ch.append(c2)
    #把所有layers做一个Sequential,把save做一个sorted返回回去，返回到class model中的
    #self.model, self.save = parse_model(deepcopy(self.yaml), ch=[ch])
    return nn.Sequential(*layers), sorted(save) # nn.Sequential(*layers) 处理成一个模型


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--cfg', type=str, default='ghostnetv2_yolov5s.yaml', help='model.yaml')
    parser.add_argument('--device', default='0', help='cuda device, i.e. 0 or 0,1,2,3 or cpu')
    # 其实这里就明明白白写着怎么输出各层FLOPs
    #终端行输入python .\models\yolo.py --line-profile我们得到完整的各层参量和FLOPs表
    parser.add_argument('--profile', action='store_true', help='profile model speed')
    parser.add_argument('--test', action='store_true', help='test all yolo*.yaml')
    opt = parser.parse_args()
    opt.cfg = check_yaml(opt.cfg)  # check YAML
    print_args(FILE.stem, opt)
    device = select_device(opt.device)

    # Create model
    model = Model(opt.cfg).to(device)
    model.train()

    # Profile
    if opt.profile:
        img = torch.rand(8 if torch.cuda.is_available() else 1, 3, 640, 640).to(device)
        y = model(img, profile=True)

    # Test all models
    if opt.test:
        for cfg in Path(ROOT / 'models').rglob('yolo*.yaml'):
            try:
                _ = Model(cfg)
            except Exception as e:
                print(f'Error in {cfg}: {e}')

    # Tensorboard (not working https://github.com/ultralytics/yolov5/issues/2898)
    # from torch.utils.tensorboard import SummaryWriter
    # tb_writer = SummaryWriter('.')
    # LOGGER.info("Run 'tensorboard --logdir=models' to view tensorboard at http://localhost:6006/")
    # tb_writer.add_graph(torch.jit.trace(model, img, strict=False), [])  # add model graph


# #计算打印不出来的参数量以及计算量
# input = torch.rand(1, 3, 640, 640).to(device)
# flops, params = thop.profile(model, inputs=(input,))
# # print('flops:', flops / 900000000*2)
# print('flops:', flops / 1000000000*2)
# print('params:', params)



#解耦头
class Decouple(nn.Module):
    # Decoupled convolution
    def __init__(self, c1, nc=80, na=3):  # ch_in, num_classes, num_anchors
        super().__init__()
        c_ = min(c1, 256)  # min(c1, nc * na)
        self.na = na  # number of anchors
        self.nc = nc  # number of classes
        self.a = Conv(c1, c_, 1)
        c = [int(x + na * 5) for x in (c_ - na * 5) * torch.linspace(1, 0, 4)]  # linear channel descent

        self.b1, self.b2, self.b3 = Conv(c_, c[1], 3), Conv(c[1], c[2], 3), nn.Conv2d(c[2], na * 5, 1)  # vc

        self.c1, self.c2, self.c3 = Conv(c_, c_, 1), Conv(c_, c_, 1), nn.Conv2d(c_, na * nc, 1)  # cls

    def forward(self, x):
        bs, nc, ny, nx = x.shape  # BCHW
        x = self.a(x)
        b = self.b3(self.b2(self.b1(x)))
        c = self.c3(self.c2(self.c1(x)))
        return torch.cat((b.view(bs, self.na, 5, ny, nx), c.view(bs, self.na, self.nc, ny, nx)), 2).view(bs, -1, ny, nx)


class Decoupled_Detect(nn.Module):
    stride = None  # strides computed during build
    onnx_dynamic = False  # ONNX export parameter
    export = False  # export mode

    def __init__(self, nc=80, anchors=(), ch=(), inplace=True):  # detection layer
        super().__init__()

        self.nc = nc  # number of classes
        self.no = nc + 5  # number of outputs per anchor
        self.nl = len(anchors)  # number of detection layers
        self.na = len(anchors[0]) // 2  # number of anchors
        self.grid = [torch.zeros(1)] * self.nl  # init grid
        self.anchor_grid = [torch.zeros(1)] * self.nl  # init anchor grid
        self.register_buffer('anchors', torch.tensor(anchors).float().view(self.nl, -1, 2))  # shape(nl,na,2)
        self.m = nn.ModuleList(Decouple(x, self.nc, self.na) for x in ch)  # yolov5 provide ,  old Decouple too much FLOP
        self.inplace = inplace  # use in-place ops (e.g. slice assignment)

    def forward(self, x):
        z = []  # inference output
        for i in range(self.nl):
            x[i] = self.m[i](x[i])  # conv
            bs, _, ny, nx = x[i].shape  # x(bs,255,20,20) to x(bs,3,20,20,85)
            x[i] = x[i].view(bs, self.na, self.no, ny, nx).permute(0, 1, 3, 4, 2).contiguous()

            if not self.training:  # inference
                if self.onnx_dynamic or self.grid[i].shape[2:4] != x[i].shape[2:4]:
                    self.grid[i], self.anchor_grid[i] = self._make_grid(nx, ny, i)

                y = x[i].sigmoid()
                if self.inplace:
                    y[..., 0:2] = (y[..., 0:2] * 2 + self.grid[i]) * self.stride[i]  # xy
                    y[..., 2:4] = (y[..., 2:4] * 2) ** 2 * self.anchor_grid[i]  # wh
                else:  # for YOLOv5 on AWS Inferentia https://github.com/ultralytics/yolov5/pull/2953
                    xy, wh, conf = y.split((2, 2, self.nc + 1), 4)  # y.tensor_split((2, 4, 5), 4)  # torch 1.8.0
                    xy = (xy * 2 + self.grid[i]) * self.stride[i]  # xy
                    wh = (wh * 2) ** 2 * self.anchor_grid[i]  # wh
                    y = torch.cat((xy, wh, conf), 4)
                z.append(y.view(bs, -1, self.no))

        return x if self.training else (torch.cat(z, 1),) if self.export else (torch.cat(z, 1), x)

    def _make_grid(self, nx=20, ny=20, i=0, torch_1_10=check_version(torch.__version__, '1.10.0')):
        d = self.anchors[i].device
        t = self.anchors[i].dtype
        shape = 1, self.na, ny, nx, 2  # grid shape
        y, x = torch.arange(ny, device=d, dtype=t), torch.arange(nx, device=d, dtype=t)
        yv, xv = torch.meshgrid(y, x, indexing='ij') if torch_1_10 else torch.meshgrid(y, x)  # torch>=0.7 compatibility
        grid = torch.stack((xv, yv), 2).expand(shape) - 0.5  # add grid offset, i.e. y = 2.0 * x - 0.5
        anchor_grid = (self.anchors[i] * self.stride[i]).view((1, self.na, 1, 1, 2)).expand(shape)
        return grid, anchor_grid


class ASFF_Detect(nn.Module):  # add ASFFV5 layer and Rfb
    stride = None  # strides computed during build
    onnx_dynamic = False  # ONNX export parameter
    export = False  # export mode

    def __init__(self, nc=80, anchors=(), ch=(), multiplier=0.5, rfb=False, inplace=True):  # detection layer
        super().__init__()
        self.nc = nc  # number of classes
        self.no = nc + 5  # number of outputs per anchor
        self.nl = len(anchors)  # number of detection layers
        self.na = len(anchors[0]) // 2  # number of anchors
        self.grid = [torch.zeros(1)] * self.nl  # init grid
        self.l0_fusion = ASFFV5(level=0, multiplier=multiplier, rfb=rfb)
        self.l1_fusion = ASFFV5(level=1, multiplier=multiplier, rfb=rfb)
        self.l2_fusion = ASFFV5(level=2, multiplier=multiplier, rfb=rfb)
        self.anchor_grid = [torch.zeros(1)] * self.nl  # init anchor grid
        self.register_buffer('anchors', torch.tensor(anchors).float().view(self.nl, -1, 2))  # shape(nl,na,2)
        self.m = nn.ModuleList(nn.Conv2d(x, self.no * self.na, 1) for x in ch)  # output conv
        self.inplace = inplace  # use in-place ops (e.g. slice assignment)

    def forward(self, x):
        z = []  # inference output
        result = []

        result.append(self.l2_fusion(x))
        result.append(self.l1_fusion(x))
        result.append(self.l0_fusion(x))
        x = result
        for i in range(self.nl):
            x[i] = self.m[i](x[i])  # conv
            bs, _, ny, nx = x[i].shape  # x(bs,255,20,20) to x(bs,3,20,20,85)
            x[i] = x[i].view(bs, self.na, self.no, ny, nx).permute(0, 1, 3, 4, 2).contiguous()

            if not self.training:  # inference
                if self.onnx_dynamic or self.grid[i].shape[2:4] != x[i].shape[2:4]:
                    self.grid[i], self.anchor_grid[i] = self._make_grid(nx, ny, i)

                y = x[i].sigmoid()
                if self.inplace:
                    y[..., 0:2] = (y[..., 0:2] * 2 + self.grid[i]) * self.stride[i]  # xy
                    y[..., 2:4] = (y[..., 2:4] * 2) ** 2 * self.anchor_grid[i]  # wh
                else:  # for YOLOv5 on AWS Inferentia https://github.com/ultralytics/yolov5/pull/2953
                    xy, wh, conf = y.split((2, 2, self.nc + 1), 4)  # y.tensor_split((2, 4, 5), 4)  # torch 1.8.0
                    xy = (xy * 2 + self.grid[i]) * self.stride[i]  # xy
                    wh = (wh * 2) ** 2 * self.anchor_grid[i]  # wh
                    y = torch.cat((xy, wh, conf), 4)
                z.append(y.view(bs, -1, self.no))

        return x if self.training else (torch.cat(z, 1),) if self.export else (torch.cat(z, 1), x)

    def _make_grid(self, nx=20, ny=20, i=0, torch_1_10=check_version(torch.__version__, '1.10.0')):
        d = self.anchors[i].device
        t = self.anchors[i].dtype
        shape = 1, self.na, ny, nx, 2  # grid shape
        y, x = torch.arange(ny, device=d, dtype=t), torch.arange(nx, device=d, dtype=t)
        if torch_1_10:  # torch>=1.10.0 meshgrid workaround for torch>=0.7 compatibility
            yv, xv = torch.meshgrid(y, x, indexing='ij')
        else:
            yv, xv = torch.meshgrid(y, x)
        grid = torch.stack((xv, yv), 2).expand(shape) - 0.5  # add grid offset, i.e. y = 2.0 * x - 0.5
        anchor_grid = (self.anchors[i] * self.stride[i]).view((1, self.na, 1, 1, 2)).expand(shape)
        # print(anchor_grid)
        return grid, anchor_grid