import math
from collections import OrderedDict

import torch
from torch import nn

from models.common import Conv, Bottleneck, CBAM


class EMA(nn.Module):
    def __init__(self, channels, factor=8):
        super(EMA, self).__init__()
        self.groups = factor
        assert channels // self.groups > 0
        self.softmax = nn.Softmax(-1)
        self.agp = nn.AdaptiveAvgPool2d((1, 1))
        self.pool_h = nn.AdaptiveAvgPool2d((None, 1))
        self.pool_w = nn.AdaptiveAvgPool2d((1, None))
        self.gn = nn.GroupNorm(channels // self.groups, channels // self.groups)
        self.conv1x1 = nn.Conv2d(channels // self.groups, channels // self.groups, kernel_size=1, stride=1, padding=0)
        self.conv3x3 = nn.Conv2d(channels // self.groups, channels // self.groups, kernel_size=3, stride=1, padding=1)

    def forward(self, x):
        b, c, h, w = x.size()
        group_x = x.reshape(b * self.groups, -1, h, w)  # b*g,c//g,h,w
        x_h = self.pool_h(group_x)
        x_w = self.pool_w(group_x).permute(0, 1, 3, 2)
        hw = self.conv1x1(torch.cat([x_h, x_w], dim=2))
        x_h, x_w = torch.split(hw, [h, w], dim=2)
        x1 = self.gn(group_x * x_h.sigmoid() * x_w.permute(0, 1, 3, 2).sigmoid())
        x2 = self.conv3x3(group_x)
        x11 = self.softmax(self.agp(x1).reshape(b * self.groups, -1, 1).permute(0, 2, 1))
        x12 = x2.reshape(b * self.groups, c // self.groups, -1)  # b*g, c//g, hw
        x21 = self.softmax(self.agp(x2).reshape(b * self.groups, -1, 1).permute(0, 2, 1))
        x22 = x1.reshape(b * self.groups, c // self.groups, -1)  # b*g, c//g, hw
        weights = (torch.matmul(x11, x12) + torch.matmul(x21, x22)).reshape(b * self.groups, 1, h, w)
        return (group_x * weights.sigmoid()).reshape(b, c, h, w)

#把c3中的bottleneck换成了GAM_Bottleneck：即原有的bottleneck中最后一个模块加入了gam然后放入c3中
class EMA_Bottleneck(nn.Module):
    #  Bottleneck with 1 Attention
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_, c2, 3, 1, g=g)
        self.att = EMA(c2, 8)
        self.add = shortcut and c1 == c2

    def forward(self, x):
        return x + self.att(self.cv2(self.cv1(x))) if self.add else self.att(self.cv2(self.cv1(x)))


class C3_EMA(nn.Module):
    # CSP Bottleneck with 3 convolutions and 1 SpatialGroupEnhance.
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1)
        self.m = nn.Sequential(*(EMA_Bottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))

    def forward(self, x):
        return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1))

#把c3中的bottleneck换成了GAM_Bottleneck：即原有的bottleneck中两个卷积模块中间加入了gam，然后把GAM_Bottleneck放入c3中
class EMA_Bottleneck1(nn.Module):
    #  Bottleneck with 1 Attention
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.att = EMA(c_, 8)
        self.cv2 = Conv(c_, c2, 3, 1, g=g)
        self.add = shortcut and c1 == c2

    def forward(self, x):
        return x + self.cv2(self.att(self.cv1(x))) if self.add else self.att(self.cv2(self.cv1(x)))


class C3_EMA1(nn.Module):
    # CSP Bottleneck with 3 convolutions and 1 SpatialGroupEnhance.
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1)
        self.m = nn.Sequential(*(EMA_Bottleneck1(c_, c_, shortcut, g, e=1.0) for _ in range(n)))

    def forward(self, x):
        return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1))

# 添加在c3最后一个卷积之前加入ema
class C3_EMA2(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5): # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e) # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1) # optional act=FReLU(c2)
        self.m = nn.Sequential(*(Bottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))
        self.m1 = nn.ModuleList([EMA(2 * c_)]) # 添加在最后一个卷积之前
    def forward(self, x):
        return self.cv3(self.m1[0](torch.cat((self.m(self.cv1(x)), self.cv2(x)), 1)))

#在没有bottleneck支路的最前面放入EMA
class C3_EMA3(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1)  # optional act=FReLU(c2)
        self.m = nn.Sequential(*(Bottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))
        self.m1 = nn.ModuleList([EMA(c1)])

    def forward(self, x):
        return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(self.m1[0](x))), 1))

#在有bottleneck支路的conv与bottleneck之间放入ema
class C3_EMA4(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1)  # optional act=FReLU(c2)
        self.m = nn.Sequential(*(Bottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))
        self.m1 = nn.ModuleList([EMA(c_)])

    def forward(self, x):
        return self.cv3(torch.cat((self.m(self.m1[0](self.cv1(x))), self.cv2(x)), 1))


class SKAttention(nn.Module):

    def __init__(self, channel=512, kernels=[1, 3, 5, 7], reduction=16, group=1, L=32):
        super().__init__()
        self.d = max(L, channel // reduction)
        self.convs = nn.ModuleList([])
        for k in kernels:
            self.convs.append(
                nn.Sequential(OrderedDict([
                    ('conv', nn.Conv2d(channel, channel, kernel_size=k, padding=k // 2, groups=group)),
                    ('bn', nn.BatchNorm2d(channel)),
                    ('relu', nn.ReLU())
                ]))
            )
        self.fc = nn.Linear(channel, self.d)
        self.fcs = nn.ModuleList([])
        for i in range(len(kernels)):
            self.fcs.append(nn.Linear(self.d, channel))
        self.softmax = nn.Softmax(dim=0)

    def forward(self, x):
        bs, c, _, _ = x.size()
        conv_outs = []
        ### split
        for conv in self.convs:
            conv_outs.append(conv(x))
        feats = torch.stack(conv_outs, 0)  # k,bs,channel,h,w

        ### fuse
        U = sum(conv_outs)  # bs,c,h,w

        ### reduction channel
        S = U.mean(-1).mean(-1)  # bs,c
        Z = self.fc(S)  # bs,d

        ### calculate attention weight
        weights = []
        for fc in self.fcs:
            weight = fc(Z)
            weights.append(weight.view(bs, c, 1, 1))  # bs,channel
        attention_weughts = torch.stack(weights, 0)  # k,bs,channel,1,1
        attention_weughts = self.softmax(attention_weughts)  # k,bs,channel,1,1

        ### fuse
        V = (attention_weughts * feats).sum(0)
        return V

#或者，sk可以表示成
class SKConv(nn.Module):
    def __init__(self, features, M: int = 2, G: int = 32, r: int = 16, stride: int = 1, L: int = 32):
        super().__init__()
        d = max(features / r, L)
        self.M = M
        self.features = features
        # 1.split
        self.convs = nn.ModuleList([])
        for i in range(M):
            self.convs.append(nn.Sequential(
                nn.Conv2d(features, features, kernel_size=3, stride=stride, padding=1 + i, dilation=1 + i, groups=G,
                          bias=False),
                nn.BatchNorm2d(features),
                nn.ReLU(inplace=True)
            ))
        # 2.fuse
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(nn.Conv2d(features, d, kernel_size=1, stride=1, bias=False),
                                nn.BatchNorm2d(d),
                                nn.ReLU(inplace=True))
        # 3.select
        self.fcs = nn.ModuleList([])
        for i in range(M):
            self.fcs.append(
                nn.Conv2d(d, features, kernel_size=1, stride=1)
            )
        self.softmax = nn.Softmax(dim=1)

    def forward(self, x):
        batch_size = x.shape[0]
        # 1.split
        feats = [conv(x) for conv in self.convs]
        feats = torch.cat(feats, dim=1)
        feats = feats.view(batch_size, self.M, self.features, feats.shape[2], feats.shape[3])
        print('feats.shape', feats.shape)
        # 2.fuse
        feats_U = torch.sum(feats, dim=1)
        feats_S = self.gap(feats_U)
        feats_Z = self.fc(feats_S)
        print('feats_U.shape', feats_U.shape)
        print('feats_S.shape', feats_S.shape)
        print('feats_Z.shape', feats_Z.shape)
        # 3.select
        attention_vectors = [fc(feats_Z) for fc in self.fcs]
        attention_vectors = torch.cat(attention_vectors, dim=1)
        print('attention_vectors.shape', attention_vectors.shape)
        attention_vectors = attention_vectors.view(batch_size, self.M, self.features, 1, 1)
        print('attention_vectors.shape', attention_vectors.shape)
        attention_vectors = self.softmax(attention_vectors)
        feats_V = torch.sum(feats * attention_vectors, dim=1)
        print('feats_V.shape', feats_V.shape)
        return feats_V

if __name__ == '__main__':
    inputs = torch.randn(4, 64, 512, 512)
    net = SKConv(64)
    outputs = net(inputs)

#eca
#自适应核
class eca1(nn.Module):
    # 初始化, in_channel代表特征图的输入通道数, b和gama代表公式中的两个系数
    def __init__(self,in_channel,gamma=2,b=1):
        # 继承父类初始化
        super(eca1, self).__init__()
        # 根据输入通道数自适应调整卷积核大小
        k=int(abs((math.log(in_channel,2)+b)/gamma))
        # 如果卷积核大小是奇数，就使用它# 如果卷积核大小是偶数，就把它变成奇数
        kernel_size=k if k % 2 else k+1
        # 卷积时，为例保证卷积前后的size不变，需要0填充的数量
        padding=kernel_size//2
        # 全局平均池化，输出的特征图的宽高=1
        self.pool=nn.AdaptiveAvgPool2d(output_size=1)
        # 1D卷积，输入和输出通道数都=1，卷积核大小是自适应的
        self.conv=nn.Sequential(
            nn.Conv1d(in_channels=1,out_channels=1,kernel_size=kernel_size,padding=padding,bias=False),
            # 权值归一化
            nn.Sigmoid()
        )

    # 前向传播
    def forward(self,x):
        # 获得输入图像的shape 使用全局平均池化GAP，得到1*1*C的特征图；
        out=self.pool(x)
        # 维度调整，变成序列形式 [b,c,1,1]==>[b,1,c],感觉这样变化是为了将通道c放在后面，便于下一步使用1*1卷积学习通道注意力信息
        out=out.view(x.size(0),1,x.size(1))
        # 1D卷积 [b,1,c]==>[b,1,c] # 权值归一化
        out=self.conv(out)
        # 维度调整 [b,1,c]==>[b,c,1,1]
        out=out.view(x.size(0),x.size(1),1,1)
        # 将输入特征图和通道权重相乘[b,c,h,w]*[b,c,1,1]==>[b,c,h,w]
        return out*x

#把c3中的bottleneck换成了GAM_Bottleneck：即原有的bottleneck中最后一个模块加入了gam然后放入c3中
class ECA_Bottleneck(nn.Module):
    #  Bottleneck with 1 Attention
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_, c2, 3, 1, g=g)
        self.att = eca1(c2)
        self.add = shortcut and c1 == c2

    def forward(self, x):
        return x + self.att(self.cv2(self.cv1(x))) if self.add else self.att(self.cv2(self.cv1(x)))


class C3_ECA(nn.Module):
    # CSP Bottleneck with 3 convolutions and 1 SpatialGroupEnhance.
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1)
        self.m = nn.Sequential(*(ECA_Bottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))

    def forward(self, x):
        return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1))

#把c3中的bottleneck换成了GAM_Bottleneck：即原有的bottleneck中两个卷积模块中间加入了gam，然后把GAM_Bottleneck放入c3中
class ECA_Bottleneck1(nn.Module):
    #  Bottleneck with 1 Attention
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.att = eca1(c_)
        self.cv2 = Conv(c_, c2, 3, 1, g=g)
        self.add = shortcut and c1 == c2

    def forward(self, x):
        return x + self.cv2(self.att(self.cv1(x))) if self.add else self.att(self.cv2(self.cv1(x)))


class C3_ECA1(nn.Module):
    # CSP Bottleneck with 3 convolutions and 1 SpatialGroupEnhance.
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1)
        self.m = nn.Sequential(*(ECA_Bottleneck1(c_, c_, shortcut, g, e=1.0) for _ in range(n)))

    def forward(self, x):
        return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1))

# 添加在c3最后一个卷积之前加入ema
class C3_ECA2(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5): # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e) # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1) # optional act=FReLU(c2)
        self.m = nn.Sequential(*(Bottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))
        self.m1 = nn.ModuleList([eca1(2 * c_)]) # 添加在最后一个卷积之前
    def forward(self, x):
        return self.cv3(self.m1[0](torch.cat((self.m(self.cv1(x)), self.cv2(x)), 1)))

#在没有bottleneck支路的最前面放入EMA
class C3_ECA3(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1)  # optional act=FReLU(c2)
        self.m = nn.Sequential(*(Bottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))
        self.m1 = nn.ModuleList([eca1(c1)])

    def forward(self, x):
        return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(self.m1[0](x))), 1))

#在有bottleneck支路的conv与bottleneck之间放入ema
class C3_ECA4(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1)  # optional act=FReLU(c2)
        self.m = nn.Sequential(*(Bottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))
        self.m1 = nn.ModuleList([eca1(c_)])

    def forward(self, x):
        return self.cv3(torch.cat((self.m(self.m1[0](self.cv1(x))), self.cv2(x)), 1))

#自己构建的ECASAM
#由cbam(https://blog.csdn.net/toCVer/article/details/125281213)改进而来
class ECASAM(nn.Module):
    def __init__(self, in_channel):
        super(ECASAM, self).__init__()
        self.Cam = ECAModul(in_channel=in_channel)  # 通道注意力模块
        self.Sam = SpatialAttentionModul(in_channel=in_channel)  # 空间注意力模块

    def forward(self, x):
        x = self.Cam(x)
        x = self.Sam(x)
        return x


class ECAModul(nn.Module):  # 通道注意力模块
    def __init__(self, in_channel, gamma=2,b=1):  # channel为输入的维度, r为全连接层缩放比例->控制中间层个数
        super(ECAModul, self).__init__()
        # 全局最大池化
        self.MaxPool = nn.AdaptiveMaxPool2d(1)

        # 根据输入通道数自适应调整卷积核大小
        k = int(abs((math.log(in_channel, 2) + b) / gamma))
        # 如果卷积核大小是奇数，就使用它# 如果卷积核大小是偶数，就把它变成奇数
        kernel_size = k if k % 2 else k + 1
        # 卷积时，为例保证卷积前后的size不变，需要0填充的数量
        padding = kernel_size // 2

        self.fc_MaxPool = nn.Sequential(
            nn.Conv1d(in_channels=1, out_channels=1, kernel_size=kernel_size, padding=padding, bias=False),
            # 权值归一化
            nn.Sigmoid()
        )

        # 全局均值池化
        self.AvgPool = nn.AdaptiveAvgPool2d(1)

        self.fc_AvgPool = nn.Sequential(
            nn.Conv1d(in_channels=1, out_channels=1, kernel_size=kernel_size, padding=padding, bias=False),
            # 权值归一化
            nn.Sigmoid()
        )

        # 激活函数
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        # 1.最大池化分支
        max_branch = self.MaxPool(x)

        # 维度调整，变成序列形式 [b,c,1,1]==>[b,1,c],感觉这样变化是为了将通道c放在后面，便于下一步使用1*1卷积学习通道注意力信息
        max_in = max_branch.view(x.size(0), 1, x.size(1))

        # 送入MLP全连接神经网络, 得到权重
        max_weight = self.fc_MaxPool(max_in)

        # 维度调整 [b,1,c]==>[b,c,1,1]
        #max_weight=max_weight.view(x.size(0),x.size(1),1,1)

        # 2.全局池化分支
        avg_branch = self.AvgPool(x)

        # 维度调整，变成序列形式 [b,c,1,1]==>[b,1,c],感觉这样变化是为了将通道c放在后面，便于下一步使用1*1卷积学习通道注意力信息
        avg_in = avg_branch.view(x.size(0), 1, x.size(1))

        # 送入MLP全连接神经网络, 得到权重
        avg_weight = self.fc_AvgPool(avg_in)

        # 维度调整 [b,1,c]==>[b,c,1,1]
        #avg_weight = avg_weight.view(x.size(0), x.size(1), 1, 1)

        # MaxPool + AvgPool 激活后得到权重weight
        weight = max_weight + avg_weight
        weight = self.sigmoid(weight)

        weights=weight.view(x.size(0),x.size(1),1,1)

        # # 将维度为b, c的weight, reshape成b, c, 1, 1 与 输入x 相乘
        # h, w = weight.shape
        # # 通道注意力Mc
        # Mc = torch.reshape(weight, (h, w, 1, 1))

        # 乘积获得结果
        x = weights * x

        return x


class SpatialAttentionModul(nn.Module):  # 空间注意力模块
    def __init__(self, in_channel):
        super(SpatialAttentionModul, self).__init__()
        self.conv = nn.Conv2d(2, 1, 7, padding=3)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        # x维度为 [N, C, H, W] 沿着维度C进行操作, 所以dim=1,即对通道求最大值与均值的那一个 结果剩下[N, H, W]
        ##返回的是两个值，一个是每一行最大值的tensor组，另一个是最大值所在的位置 dim是max函数索引的维度0/1，0是每列的最大值，1是每行的最大值
        MaxPool = torch.max(x, dim=1).values  # torch.max 返回的是索引和value， 要用.values去访问值才行！
        AvgPool = torch.mean(x, dim=1)

        # 增加维度, 变成 [N, 1, H, W] unsqueeze()函数起升维的作用
        MaxPool = torch.unsqueeze(MaxPool, dim=1)
        AvgPool = torch.unsqueeze(AvgPool, dim=1)

        # 维度拼接 [N, 2, H, W]
        x_cat = torch.cat((MaxPool, AvgPool), dim=1)  # 获得特征图

        # 卷积操作得到空间注意力结果
        x_out = self.conv(x_cat)
        Ms = self.sigmoid(x_out)#将学习到的权重映射到0到1之间

        # 与原图通道进行乘积  将学习到的各个channel的激活值乘以U上的原始特征：学习到了各个channel的权重系数，从而使得模型对各个channel的特征更有辨别能力。
        x = Ms * x

        return x


#自己构建的ECASAM，只是
#由cbam(https://blog.csdn.net/toCVer/article/details/125281213)
# 和gam https://www.qinglite.cn/doc/813564771da3bba7e改进而来
#但是计算量参数量有点太大了
class ECAGAM(nn.Module):
    def __init__(self, in_channels, out_channels,gamma=2,b=1, rate=4):
        super(ECAGAM, self).__init__()

        # 根据输入通道数自适应调整卷积核大小
        k = int(abs((math.log(in_channels, 2) + b) / gamma))
        # 如果卷积核大小是奇数，就使用它# 如果卷积核大小是偶数，就把它变成奇数
        kernel_size = k if k % 2 else k + 1
        # 卷积时，为例保证卷积前后的size不变，需要0填充的数量
        padding = kernel_size // 2

        # 全局平均池化，输出的特征图的宽高=1
        self.pool = nn.AdaptiveAvgPool2d(output_size=1)

        self.channel_attention = nn.Sequential(
            nn.Conv1d(in_channels=1, out_channels=1, kernel_size=kernel_size, padding=padding, bias=False),
            # 权值归一化
            nn.Sigmoid()
        )

        self.spatial_attention = nn.Sequential(
            nn.Conv2d(in_channels, int(in_channels / rate), kernel_size=7, padding=3),
            nn.BatchNorm2d(int(in_channels / rate)),
            nn.ReLU(inplace=True),
            nn.Conv2d(int(in_channels / rate), out_channels, kernel_size=7, padding=3),
            nn.BatchNorm2d(out_channels)
        )

    def forward(self, x):
        # 获得输入图像的shape 使用全局平均池化GAP，得到1*1*C的特征图；
        out = self.pool(x)
        # 维度调整，变成序列形式 [b,c,1,1]==>[b,1,c],感觉这样变化是为了将通道c放在后面，便于下一步使用1*1卷积学习通道注意力信息
        out = out.view(x.size(0), 1, x.size(1))
        # 1D卷积 [b,1,c]==>[b,1,c] # 权值归一化
        out = self.channel_attention(out)
        # 维度调整 [b,1,c]==>[b,c,1,1]
        out = out.view(x.size(0), x.size(1), 1, 1)
        # 将输入特征图和通道权重相乘[b,c,h,w]*[b,c,1,1]==>[b,c,h,w]

        x = x * out

        x_spatial_att = self.spatial_attention(x).sigmoid()
        out = x * x_spatial_att

        return out

#lskb
import torch
import torch.nn as nn
from torch.nn.modules.utils import _pair as to_2tuple
#from mmcv.runner import BaseModule
# from timm.models.layers import DropPath
# from functools import partial
# import warnings
# from mmcv.cnn import build_norm_layer


class DWConv(nn.Module):
    def __init__(self, dim=768):
        super(DWConv, self).__init__()
        self.dwconv = nn.Conv2d(dim, dim, 3, 1, 1, bias=True, groups=dim)

    def forward(self, x):
        x = self.dwconv(x)
        return x


class Mlp(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.fc1 = nn.Conv2d(in_features, hidden_features, 1)
        self.dwconv = DWConv(hidden_features)
        self.act = act_layer()
        self.fc2 = nn.Conv2d(hidden_features, out_features, 1)
        self.drop = nn.Dropout(drop)

    def forward(self, x):
        x = self.fc1(x)
        x = self.dwconv(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x


class LSKblock(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.conv0 = nn.Conv2d(dim, dim, 5, padding=2, groups=dim)
        self.conv_spatial = nn.Conv2d(dim, dim, 7, stride=1, padding=9, groups=dim, dilation=3)
        self.conv1 = nn.Conv2d(dim, dim // 2, 1)
        self.conv2 = nn.Conv2d(dim, dim // 2, 1)
        self.conv_squeeze = nn.Conv2d(2, 2, 7, padding=3)
        self.conv = nn.Conv2d(dim // 2, dim, 1)

    def forward(self, x):
        attn1 = self.conv0(x)
        attn2 = self.conv_spatial(attn1)

        attn1 = self.conv1(attn1)
        attn2 = self.conv2(attn2)

        attn = torch.cat([attn1, attn2], dim=1)
        avg_attn = torch.mean(attn, dim=1, keepdim=True)
        max_attn, _ = torch.max(attn, dim=1, keepdim=True)
        agg = torch.cat([avg_attn, max_attn], dim=1)
        sig = self.conv_squeeze(agg).sigmoid()
        attn = attn1 * sig[:, 0, :, :].unsqueeze(1) + attn2 * sig[:, 1, :, :].unsqueeze(1)
        attn = self.conv(attn)
        return x * attn


class Attention(nn.Module):
    def __init__(self, d_model):
        super().__init__()

        self.proj_1 = nn.Conv2d(d_model, d_model, 1)
        self.activation = nn.GELU()
        self.spatial_gating_unit = LSKblock(d_model)
        self.proj_2 = nn.Conv2d(d_model, d_model, 1)

    def forward(self, x):
        shorcut = x.clone()
        x = self.proj_1(x)
        x = self.activation(x)
        x = self.spatial_gating_unit(x)
        x = self.proj_2(x)
        x = x + shorcut
        return x


class LSKB(nn.Module):
    def __init__(self, dim, dim01, mlp_ratio=4., drop=0., drop_path=0., act_layer=nn.GELU, norm_cfg=None):
        super().__init__()
        if norm_cfg:
            self.norm1 = build_norm_layer(norm_cfg, dim)[1]
            self.norm2 = build_norm_layer(norm_cfg, dim)[1]
        else:
            self.norm1 = nn.BatchNorm2d(dim)
            self.norm2 = nn.BatchNorm2d(dim)
        self.attn = Attention(dim)
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)
        layer_scale_init_value = 1e-2
        self.layer_scale_1 = nn.Parameter(
            layer_scale_init_value * torch.ones((dim)), requires_grad=True)
        self.layer_scale_2 = nn.Parameter(
            layer_scale_init_value * torch.ones((dim)), requires_grad=True)

    def forward(self, x):
        x = x + self.drop_path(self.layer_scale_1.unsqueeze(-1).unsqueeze(-1) * self.attn(self.norm1(x)))
        x = x + self.drop_path(self.layer_scale_2.unsqueeze(-1).unsqueeze(-1) * self.mlp(self.norm2(x)))
        return x

#cbam_bottleneck
#把c3中的bottleneck换成了GAM_Bottleneck：即原有的bottleneck中最后一个模块加入了gam然后放入c3中
class CBAM_Bottleneck(nn.Module):
    #  Bottleneck with 1 Attention
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_, c2, 3, 1, g=g)
        self.att = CBAM(c2, c2)
        self.add = shortcut and c1 == c2

    def forward(self, x):
        return x + self.att(self.cv2(self.cv1(x))) if self.add else self.att(self.cv2(self.cv1(x)))

#把c3中的bottleneck换成了GAM_Bottleneck：即原有的bottleneck中两个卷积模块中间加入了gam，然后把GAM_Bottleneck放入c3中
class CBAM_Bottleneck1(nn.Module):
    #  Bottleneck with 1 Attention
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.att = CBAM(c_, c_)
        self.cv2 = Conv(c_, c2, 3, 1, g=g)
        self.add = shortcut and c1 == c2

    def forward(self, x):
        return x + self.cv2(self.att(self.cv1(x))) if self.add else self.att(self.cv2(self.cv1(x)))

#在主路使用lsk然后再拼接
class CBAM_Bottleneck2(nn.Module):
    #  Bottleneck with 1 Attention
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_, c2, 3, 1, g=g)
        self.add = shortcut and c1 == c2
        self.att = CBAM(c1, c1)

    def forward(self, x):
        return self.att(x) + self.att(self.cv2(self.cv1(x))) if self.add else self.att(self.cv2(self.cv1(x)))