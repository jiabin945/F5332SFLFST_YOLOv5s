#将同名不同样子的图片（如图片经过增强后同名的图片）放到自己需要的文件夹中（如：自己将同名的增强的图片放入到train/val/test下面相同位置）
import shutil
import numpy as np
import os
data = []
path='/home/lhcz/sdb/jiabin/jb_project/datasets/checkpoint_night/images'
folders = os.listdir(path)
# print(folders)
for f in folders:
    print(f)
    #获取指定文件夹下的所有文件
    folders = os.listdir(path+'/'+f)
    print(folders)
    for line in folders:
        print(line)
        srcfile_path = '/home/lhcz/sdb/jiabin/jb_project/datasets/checkpoint_night/labels/{}'.format(line[:-4])+'.txt'
        tarfile_path = '/home/lhcz/sdb/jiabin/jb_project/datasets/checkpoint_night/labelss/{}/'.format(f)   #新创建一个文件夹
        shutil.copy(srcfile_path, tarfile_path)




