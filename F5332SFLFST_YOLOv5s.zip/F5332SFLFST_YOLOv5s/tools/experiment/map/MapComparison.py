import pandas as pd
import matplotlib.pyplot as plt

# Function to clean column names
def clean_column_names(df):
    df.columns = df.columns.str.strip()
    df.columns = df.columns.str.replace('\s+', '_', regex=True)

#这里对应放的是训练出来的csv文件       nonoresult.csv表示原始的结果图,csv文件在runs/train/exp中
fae11 = pd.read_csv("results4.csv")
fae13 = pd.read_csv("results5.csv")



# Clean column names
clean_column_names(fae11)
clean_column_names(fae13)


# Plot mAP@0.5 curves
plt.figure()
#lable属性为曲线名称，自己可以定义
plt.plot(fae11['metrics/mAP_0.5:0.95'], label="F5332_SFL+CIoU")#(original_results['metrics/mAP_0.5'], label="Original YOLOv5")
plt.plot(fae13['metrics/mAP_0.5:0.95'], label="F5332_SFL+FocalαEIoU1.5")#(improved_results['metrics/mAP_0.5'], label="Improved YOLOv5")


plt.xlabel("Epoch")#Epoch
plt.ylabel("mAP@0.5:0.95")#mAP@0.5
plt.legend(loc='lower right')#plt.legend() 会显示该 label 的内容     loc：改变标签的位置
plt.title("mAP@0.5:0.95 comparison for IoU")#mAP@0.5 comparison for α between 1 to 3
plt.savefig("mAP@0.5:0.95comparisonforIoU.png")##保存结果在map文件夹中

# # Plot mAP@0.5:0.95 curves
# plt.figure()
# plt.plot(original_results['metrics/mAP_0.5:0.95'], label="FasterBlock1282")
# plt.plot(improved1_results['metrics/mAP_0.5:0.95'], label="FasterBlock2272")
# plt.plot(improved2_results['metrics/mAP_0.5:0.95'], label="FasterBlock5332")
# plt.xlabel("Epoch")
# plt.ylabel("mAP@0.5:0.95")
# plt.legend()
# #图的标题
# plt.title("mAP@0.5:0.95 Comparison")
# #图片名称
# plt.savefig("mAP_0.5_0.95_comparison.png")

