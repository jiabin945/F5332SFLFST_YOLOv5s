# 批量修改文件名，对一级文件夹下的多个二级文件夹中的jpg以及txt文件，默认操作为将图片按1，2，3，，，顺序重命名
#如果只有一个文件夹需要修改重命名，那么在外面新建一个文件夹，pathdir写到新建的这个文件夹路径就行
#对同一个文件夹中的同名不同格式（jpg.txt）的文件，重命名后按照序号排的名字相同，格式还是原来格式
#具体思路：遍历母文件夹下的各个子文件夹中的文件，
# 如果当前是.jpg格式的文件的话，找到与它同名的txt文件，且按照规定顺序将他们排序；
#如果是.xml文件的话，则删除（不用删除其他的文件了，因为按道理说只剩下一个classes.txt了）
import os
from os import path

pathdir = "E:/ai/数据集/新建文件夹 (2)"  # 待批量重命名的文件夹
jpg_name = ".jpg"  # 重命名后的文件名后缀
txt_name =".txt"
#最外层文件夹中的子文件夹列表
file_in1 = os.listdir(pathdir)  # 返回path指定的文件夹包含的文件(包括后缀)或文件夹的名字的列表。
num_file_in1 = len(file_in1)  # 获取文件数目
print(file_in1, num_file_in1)  # 输出修改前的文件名

num=1
#遍历各个子文件夹中的txt与jpg文件
for i in range(0,num_file_in1):
    filepath=pathdir + "/" + file_in1[i]
    file_in2 = os.listdir(pathdir+"/"+file_in1[i])
    num_file_in2 = len(file_in2)
    #对第一个子文件夹中的文件
    for j in file_in2:
        list=j.split('.')
        if list[1]=="jpg":
            x_same=""
            for x in file_in2:
                if x.split('.')[0]==list[0] and x.split('.')[1]=='txt':
                    x_same=x
            newPicName = "outdoor_3950_" + str(num) + '.' + list[1];
            oldPicPath = path.join(filepath, j)
            #oldPicPath = file_in2+"/"+j
            newPicPath = path.join(filepath, newPicName)
            if x_same:
                newTxtName = "outdoor_3950_" + str(num) + '.' + 'txt';
                oldTxtPath = path.join(filepath, x_same)
                newTxtPath = path.join(filepath, newTxtName)

                newNameJpg=os.rename(oldPicPath,newPicPath)
                newNameTxt=os.rename(oldTxtPath,newTxtPath)
                num += 1
            else:
                os.remove(path.join(filepath, j))
        elif list[1]=="xml":
            os.remove(path.join(filepath, j))


