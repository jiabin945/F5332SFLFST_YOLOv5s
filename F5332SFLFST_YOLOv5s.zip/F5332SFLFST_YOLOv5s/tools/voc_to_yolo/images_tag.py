# 该脚本文件需要修改第11-12行，设置train、val、test的切分的比率
#该脚本用于生成imagenamesets文件夹（可自动生成）且里面含有按比例分类的txt，txt中含有的是按比例分的xml的名字，；
# 提取xml文件中的文件前缀，并且把这些xml文件中图片名字按比率分别写入到D:/模型轻量化/自己用的数据集/brc/imagenamesets中的
#trainval.txt、test.txt、train.txt、val.txt
import os
import random
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--xml_path', default='E:/ai/数据集/新建文件夹/边境白天 - 副本/voc', type=str, help='input xml label path')
# 在这个文件夹下存放四个txt文件，分别存放按比例分的图片的名字（这个文件夹没有会自动创建）
parser.add_argument('--txt_path', default='E:/ai/数据集/新建文件夹/边境白天 - 副本/imagenamesets', type=str, help='output txt label path')
opt = parser.parse_args()

trainval_percent = 0.9
train_percent = 0.88 #这里的train_percent 是指占trainval_percent中的
xmlfilepath = opt.xml_path
txtsavepath = opt.txt_path
#返回指定的文件夹包含的所有文件或者文件夹的列表，这个列表是以字母顺序排序的。
total_xml = os.listdir(xmlfilepath)
if not os.path.exists(txtsavepath):
    os.makedirs(txtsavepath)

num = len(total_xml)
list_index = range(num)
#训练集验证集的数量
tv = int(num * trainval_percent)
#训练集的数量
tr = int(tv * train_percent)
#random.sample：从指定序列中随机获取指定长度的片断并随机排列,结果以列表的形式返回。
trainval = random.sample(list_index, tv)
train = random.sample(trainval, tr)

#open：需要把数据永久存储起来，随时使用随时读取，主要用于数据的读取。
file_trainval = open(txtsavepath + '/trainval.txt', 'w')
file_test = open(txtsavepath + '/test.txt', 'w')
file_train = open(txtsavepath + '/train.txt', 'w')
file_val = open(txtsavepath + '/val.txt', 'w')

for i in list_index:
    # i就是标签所在total_xml的索引号  [:-4]表示从此索引的第一个字符开始，到倒数第四个字符（倒数第四个字符不包括）
    # 即xml前面文件名不需要文件后缀“.xml”
    name = total_xml[i][:-4] + '\n'
    #将
    if i in trainval:
        file_trainval.write(name)
        if i in train:
            file_train.write(name)
        else:
            file_val.write(name)
    else:
        file_test.write(name)

file_trainval.close()
file_train.close()
file_val.close()
file_test.close()



# # 该脚本文件需要修改第11-12行，设置train、val、test的切分的比率
# #该脚本用于生成的分类txt；提取xml文件中的文件前缀，并且把这些xml文件中图片名字按比率分别写入到D:/模型轻量化/自己用的数据集/brc/Imagesets中的
# #trainval.txt、test.txt、train.txt、val.txt
# import os
# import random
# import argparse
#
# parser = argparse.ArgumentParser()
# parser.add_argument('--xml_path', default='D:/模型轻量化/自己用的数据集/brc/voc', type=str, help='input xml label path')
# 在这个文件夹下存放四个txt文件（train、test\val\trainval），分别存放按比例分的图片的名字
# parser.add_argument('--txt_path', default='D:/模型轻量化/自己用的数据集/brc/imagenamesets', type=str, help='output txt label path')
# opt = parser.parse_args()
#
# trainval_percent = 0.9
# train_percent = 0.89 #这里的train_percent 是指占trainval_percent中的
# xmlfilepath = opt.xml_path
# txtsavepath = opt.txt_path
# #返回指定的文件夹包含的所有文件或者文件夹的列表，这个列表是以字母顺序排序的。
# total_xml = os.listdir(xmlfilepath)
# if not os.path.exists(txtsavepath):
#     os.makedirs(txtsavepath)
#
# num = len(total_xml)
# list_index = range(num)
# #训练集验证集的数量
# tv = int(num * trainval_percent)
# #训练集的数量
# tr = int(tv * train_percent)
# #random.sample：从指定序列中随机获取指定长度的片断并随机排列,结果以列表的形式返回。
# trainval = random.sample(list_index, tv)
# train = random.sample(trainval, tr)
#
# #open：需要把数据永久存储起来，随时使用随时读取，主要用于数据的读取。
# file_trainval = open(txtsavepath + '/trainval.txt', 'w')
# file_test = open(txtsavepath + '/test.txt', 'w')
# file_train = open(txtsavepath + '/train.txt', 'w')
# file_val = open(txtsavepath + '/val.txt', 'w')
#
# for i in list_index:
#     # i就是标签所在total_xml的索引号  [:-4]表示从此索引的第一个字符开始，到倒数第四个字符（倒数第四个字符不包括）
#     # 即xml前面文件名不需要文件后缀“.xml”
#     name = total_xml[i][:-4] + '\n'
#     #将
#     if i in trainval:
#         file_trainval.write(name)
#         if i in train:
#             file_train.write(name)
#         else:
#             file_val.write(name)
#     else:
#         file_test