#将yolo格式的txt文件中序号为2（就像v5检测出来的种类car），改为序号1
import os
pathdir="E:/ai/数据集/label"
files=os.listdir(pathdir)
num_file=len(files)
# print(files,num_file)
# print(files[0])
for i in range(0,num_file):
    lines=""
    with open(pathdir+"/"+files[i],"r+",encoding="utf-8") as f:
        for line in f:
            #print(line)
            if(line[0]=="2"):
                line=line.replace(line[0],"1")
            lines+=line
    with open(pathdir+"/"+files[i], "w", encoding="utf-8") as f:
        f.write(lines)
