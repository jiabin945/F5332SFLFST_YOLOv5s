#这种方式：读取Imagesets中的每个txt文档中存在的图片名称，然后去相应的图片数据集中找到这些名称的图片，然后
#创建几个与Imagesets下的txt名字相同的文件夹，把对应的图片传入到里面
#即：比如Imagesets/train.txt中找到名字后，到图片集中去找图片，然后放到D:/模型轻量化/自己用的数据集/brc/train文件夹中，其他
# 类似,只是这样循环得到test、val、trainval等文件夹中的图片
#缺点：速度慢（可能if与for循环的原因）
#优点：速度快
import shutil
import numpy as np
import os
data = []
path='D:/模型轻量化/自己用的数据集/brc/Imagesets'
folders = os.listdir(path)
# print(folders)
for f in folders:
    print(f)
    fg = True
    for line in open(path+'/'+f, "r"):
         data.append(line)
         for a in data:
            # print(a)
            srcfile_path = 'D:/模型轻量化/自己用的数据集/brc/images/{}'.format(a[:-1]) + '.jpg'
            if(fg):
                fg = False
                os.mkdir(r'D:/模型轻量化/自己用的数据集/brc/'+str(f)[0:-4])
            tarfile_path = 'D:/模型轻量化/自己用的数据集/brc/'+str(f)[0:-4]   #新创建一个文件夹
            shutil.copy(srcfile_path, tarfile_path)




