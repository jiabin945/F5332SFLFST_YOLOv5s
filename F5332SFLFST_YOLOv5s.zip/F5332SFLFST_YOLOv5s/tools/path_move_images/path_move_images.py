#把D:/模型轻量化/自己用的数据集/brc/Imagesets/test.txt中存在的图片名称从图片数据集中找出来，然后复制到
#目标路径中
#优点：速度快
#缺点：有几个部分（比如train\val等）就得手动修改原路径与目标路径，麻烦
import shutil
import numpy as np
import os
data = []
#找到对应集中图片/标签名字
for line in open("D:/模型轻量化/自己用的数据集/brc/imagenamesets/train.txt", "r"):
    data.append(line)
#print(data)  # data中得到了txt文件的所有图像的名称

for a in data:
    #print(a)
    srcfile_path = 'D:/模型轻量化/自己用的数据集/brc/yolo/{}'.format(a[:-1]) + '.txt'
    tarfile_path = 'D:/模型轻量化/自己用的数据集/brc/labels/train'   #新创建一个文件夹
    shutil.copy(srcfile_path, tarfile_path)







# #把D:/模型轻量化/自己用的数据集/brc/Imagesets/test.txt中存在的图片名称从图片数据集中找出来，然后复制到
# #目标路径中
# #优点：速度快
# #缺点：有几个部分（比如train\val等）就得手动修改原路径与目标路径，麻烦
# import shutil
# import numpy as np
# import os
# data = []
# for line in open("D:/模型轻量化/自己用的数据集/brc/Imagesets/test.txt", "r"):
#     data.append(line)
# #print(data)  # data中得到了txt文件的所有图像的名称
#
# for a in data:
#     #print(a)
#     srcfile_path = 'D:/模型轻量化/自己用的数据集/brc/images/{}'.format(a[:-1]) + '.jpg'
#     tarfile_path = 'D:/模型轻量化/自己用的数据集/brc/testimg'   #新创建一个文件夹
#     shutil.copy(srcfile_path, tarfile_path)






# # coding=utf-8
# import os
# import shutil
#
# #目标文件夹，此处为相对路径，也可以改为绝对路径
# determination = 'D:/模型轻量化/自己用的数据集/brc/testimg'
# if not os.path.exists(determination):
#     os.makedirs(determination)
#
# #源文件夹路径
# path = 'D:/模型轻量化/自己用的数据集/brc/test'
# folders = os.listdir(path)
# for folder in folders:
#     dir = path + '/' + str(folder)
#     files = os.listdir(dir)
#     for file in files:
#         source = dir + '/' + str(file)
#         deter = determination + '/' + str(file)
#         shutil.copyfile(source, deter)