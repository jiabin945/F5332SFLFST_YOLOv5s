# 该脚本文件需要修改第11-12行，设置images、txt文件对应train、val、test的切分的比率，并放入到文件夹中
import os
import random
import argparse
import shutil

parser = argparse.ArgumentParser()
#存放总的labels路径
parser.add_argument('--total_labels_path', default='/home/lhcz/sdb/jiabin/jb_project/datasets/xinjian/labels', type=str, help='input xml label path')
#存放总的图片路径
parser.add_argument('--total_images_path', default='/home/lhcz/sdb/jiabin/jb_project/datasets/xinjian/xunlian', type=str, help='output txt label path')
#要复制到分割好的总的标签路径（其中包括trainval\train\val\test）
parser.add_argument('--labels_path', default='/home/lhcz/sdb/jiabin/jb_project/datasets/xinjian/labelss', type=str, help='output txt label path')
#要复制到分割好的总的图片路径（其中包括trainval\train\val\test）
parser.add_argument('--images_path', default='/home/lhcz/sdb/jiabin/jb_project/datasets/xinjian/imgss', type=str, help='output txt label path')
opt = parser.parse_args()

trainval_percent = 0.9
train_percent = 0.89 #这里的train_percent 是指占trainval_percent中的
total_labels_path = opt.total_labels_path
total_images_path = opt.total_images_path
labels_path=opt.labels_path
images_path=opt.images_path
#返回指定的文件夹包含的所有文件或者文件夹的列表，这个列表是以字母顺序排序的。
total_labels = os.listdir(total_labels_path)
total_images = os.listdir(total_images_path)
if not os.path.exists(labels_path):
    os.makedirs(labels_path)
if not os.path.exists(images_path):
    os.makedirs(images_path)
num = len(total_labels)
list_index = range(num)
#训练集验证集的数量
tv = int(num * trainval_percent)
#训练集的数量
tr = int(tv * train_percent)
#random.sample：从指定序列中随机获取指定长度的片断并随机排列,结果以列表的形式返回。
trainval = random.sample(list_index, tv)
train = random.sample(trainval, tr)

#因为不需要trainval,所以暂时注释
# if not os.path.exists(labels_path+"/"+"trainval"):
#     txt_trainval =os.mkdir(labels_path+"/"+"trainval")
if not os.path.exists(labels_path+"/"+"test"):
    txt_test = os.mkdir(labels_path+"/"+"test")
if not os.path.exists(labels_path+"/"+"train"):
    txt_train = os.mkdir(labels_path+"/"+"train")
if not os.path.exists(labels_path+"/"+"val"):
    txt_val = os.mkdir(labels_path+"/"+"val")
#txt_trainval_path=labels_path+"/"+"trainval"
txt_test_path=labels_path+"/"+"test"
txt_train_path=labels_path+"/"+"train"
txt_val_path=labels_path+"/"+"val"

#因为不需要trainval,所以暂时注释
# if not os.path.exists(images_path+"/"+"trainval"):
#     images_trainval =os.mkdir(images_path+"/"+"trainval")
if not os.path.exists(images_path+"/"+"test"):
    images_test = os.mkdir(images_path+"/"+"test")
if not os.path.exists(images_path+"/"+"train"):
    images_train = os.mkdir(images_path+"/"+"train")
if not os.path.exists(images_path+"/"+"val"):
    images_val = os.mkdir(images_path+"/"+"val")
#images_trainval_path=images_path+"/"+"trainval"
images_test_path=images_path+"/"+"test"
images_train_path=images_path+"/"+"train"
images_val_path=images_path+"/"+"val"


for i in list_index:
    # i就是标签所在total_xml的索引号  [:-4]表示从此索引的第一个字符开始，到倒数第四个字符（倒数第四个字符不包括）
    # 即xml前面文件名不需要文件后缀“.xml”
    list_labels_name = total_labels[i].split(".")[0]
    if i in trainval:
        ##因为不需要trainval,所以暂时注释
        # shutil.copy(total_labels_path+"/"+list_labels_name+".txt",txt_trainval_path)
        # shutil.copy(total_images_path+"/"+list_labels_name+".jpg", images_trainval_path)
        if i in train:
            shutil.copy(total_labels_path +"/"+ list_labels_name+".txt", txt_train_path)
            shutil.copy(total_images_path +"/"+ list_labels_name+".jpg", images_train_path)
        else:
            shutil.copy(total_labels_path + "/"+list_labels_name+".txt", txt_val_path)
            shutil.copy(total_images_path + "/"+list_labels_name+".jpg", images_val_path)
    else:
        shutil.copy(total_labels_path + "/"+list_labels_name+".txt", txt_test_path)
        shutil.copy(total_images_path + "/"+list_labels_name+".jpg", images_test_path)



