import torch
from torch import nn

sigmoid=nn.Sigmoid()
x = torch.arange(0,30,1).view(2,3,5)
print('x:\n',x)
max_value,index = torch.max(x,dim=0) #返回的是两个值，一个是每一行最大值的tensor组，另一个是最大值所在的位置
print(max_value,index)
print(max_value.size())
a=x.permute(1,0,2)
print(a.size())