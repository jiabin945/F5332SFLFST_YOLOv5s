from PIL import Image, ImageEnhance

# 打开原图像
img = Image.open('/home/lhcz/sdb/jiabin/jb_project/datasets/VisDroneOther/VisDrone2019-DET-train/images/9999953_00000_d_0000112.jpg')

# 设置增强因子
enhancer = ImageEnhance.Sharpness(img)
factor = 2.0

# 增强图片
img_enhanced = enhancer.enhance(factor)

# 保存增强后的图像
img_enhanced.save('/home/lhcz/sdb/jiabin/jb_project/datasets/test/9999953_00000_d_0000112xin.jpg')