# YOLOv5 🚀 by Ultralytics, GPL-3.0 license
"""
AutoAnchor utils
"""
#  在Yolov3、Yolov4中，训练不同的数据集时，计算初始锚框的值是通过单独的程序k-means聚类运行的。但Yolov5中将此功能
#  嵌入到代码中，每次训练时，自适应的计算不同训练集中的最佳锚框值。
import random

import numpy as np
import torch
import yaml
from tqdm import tqdm

from utils.general import LOGGER, colorstr, emojis

PREFIX = colorstr('AutoAnchor: ')


def check_anchor_order(m):
    # Check anchor order against stride order for YOLOv5 Detect() module m, and correct if necessary
    a = m.anchors.prod(-1).view(-1)  # anchor area
    da = a[-1] - a[0]  # delta a
    ds = m.stride[-1] - m.stride[0]  # delta s
    if da.sign() != ds.sign():  # same order
        LOGGER.info(f'{PREFIX}Reversing anchor order')
        m.anchors[:] = m.anchors.flip(0)

# 自动计算最佳锚框(AutoAnchor)
"""
计算默认锚框anchor与数据集标签框的宽高比值
标签的高h宽w与anchor的高h_a宽w_a的比值, 即h/h_a, w/w_a都要在(1/hyp['anchor_t'], hyp['anchor_t'])是可以接受的
如果bpr(best possible recall)小于98%，则根据k-means算法聚类新的锚框。
Autoanchor only runs when the best possible recall (BPR) is under threshold(0.98)
"""
#thr=4.0阈值默认4.0，是从超参的anchor_t得到的，界定anchor与label匹配程度的阈值
def check_anchors(dataset, model, thr=4.0, imgsz=640):
    # Check anchor fit to data, recompute if necessary
    """ 函数会在train.py中调用
            通过bpr确定是否需要改变anchors 需要就调用k-means重新计算anchors

            Check anchor fit to data, recompute if necessary
            :params dataset: 自定义数据集LoadImagesAndLabels返回的数据集
            :params model: 初始化的模型
            :params thr: 超参中得到  界定anchor与label匹配程度的阈值
            :params imgsz: 图片尺寸 默认640
        """
    #-1：model的最后一层取出来，即detect层
    m = model.module.model[-1] if hasattr(model, 'module') else model.model[-1]  # Detect()
    #shape表示训练集中的16551个数据集的图片大小，将数据集图片的最长边缩放到img_size, 较小边相应缩放 得到新的所有数据集图片的宽高 [N, 2]
    shapes = imgsz * dataset.shapes / dataset.shapes.max(1, keepdims=True)
    #产生0.9到1.1的随机数
    ## 考虑到数据有随机增强，对dataset的所有bbox进行随机变换，
    scale = np.random.uniform(0.9, 1.1, size=(shapes.shape[0], 1))  # augment scale
    #这个张量就是从数据集的标签里的得到的宽高值*s：s是shapes * scale值，因为标签的宽高值是0到1之间
    #乘以shapes * scale就不是0到1的值了。这个也不是原图上的数值，因为经过随机化的scale处理
    #wh40058个
    #变量wh用来存储训练数据中所有gt框的宽高，是一个shape为(N,2)的tensor，这里的2自然就是表示的宽和高，N为gt框的总的个数。
    wh = torch.tensor(np.concatenate([l[:, 3:5] * s for s, l in zip(shapes * scale, dataset.labels)])).float()  # wh

    #metric根据默认anchor和wh来具体计算bpr,aat(anchors above threshold)两个指标。
    #输入参数k存储anchors，调用时被reshape后的尺寸为(9,2)。
    def metric(k):  # compute metric（度量）
        """用在check_anchors函数中  compute metric
                        根据数据集的所有图片的wh和当前所有anchors k计算 bpr(best possible recall) 和 aat(anchors above threshold)
                        :params k: anchors [9, 2]  wh: [N, 2]
                        :return bpr: best possible recall 最多能被召回(通过thr)的gt框数量 / 所有gt框数量   小于0.98 才会用k-means计算anchor
                        :return aat: anchors above threshold 每个target平均有多少个anchors
                        """
        #k是锚框网格尺寸的宽高，k=9表示每个grid在三个尺度上有九个锚框
        #k={Tensor:9}tensor([[ 10.,  13.],[ 16.,  30.],[ 33.,  23.],[ 30.,  61.],[ 62.,  45.],[ 59., 119.],[116.,  90.],[156., 198.],[373., 326.]])
        # r:40058个
        #计算每个gt框的宽高和所有这9个anchor的宽高的比例值，得到的r其shape为(N,9,2)。
        r = wh[:, None] / k[None]
        #w_gt/w_anchor或者h_gt/h_anchor这个比例值可能大于1也可能小于1，通过torch.min(r,1./r)的方式
        # 统一到<=1的情形，然后再从中选取宽比和高比较小的这个值。得到的x其shape为(n,9)，
        x = torch.min(r, 1 / r).min(2)[0]  # ratio metric 求出宽比和高比的最小值  目的是往wh方向找最小值（即w或h那个方向最小）
        # #为每个gt框选择匹配所有anchors宽高比例值最好的那一个比值
        #max(1)：表示选出每一行中的最大值
        best = x.max(1)[0]  # best_x
        # aat(anchors above threshold)  每个target平均有多少个anchors
        # 当x > 1 / thr的时候，求的是每一行元素的和然后求均值
        #tensor(3.98605)代表每个目标平均有3.98个锚框而不是9个锚框，因为9个锚框要满足一定条件，因此会筛选掉一部分锚框
        aat = (x > 1 / thr).float().sum(1).mean()  # anchors above threshold，即大于1/4的anchor,要求一个均值
        #计算出来的bpr不小于0.98就会重新聚类，否则就返回默认的anchor设定
        # bpr(best possible recall) = 最多能被召回(通过thr)的gt框数量 / 所有gt框数量   小于0.98 才会用k-means计算anchor
        bpr = (best > 1 / thr).float().mean()  # best possible recall
        return bpr, aat

    anchors = m.anchors.clone() * m.stride.to(m.anchors.device).view(-1, 1, 1)  # current anchors
    bpr, aat = metric(anchors.cpu().view(-1, 2))
    s = f'\n{PREFIX}{aat:.2f} anchors/target, {bpr:.3f} Best Possible Recall (BPR). '
    # # 考虑这9类anchor的宽高和gt框的宽高之间的差距,
    # 如果bpr<0.98(说明当前anchor不能很好的匹配数据集gt框)就会根据k-means算法重新聚类新的anchor
    if bpr > 0.98:  # threshold to recompute
        LOGGER.info(emojis(f'{s}Current anchors are a good fit to dataset ✅'))
    else:
        LOGGER.info(emojis(f'{s}Anchors are a poor fit to dataset ⚠️, attempting to improve...'))
        na = m.anchors.numel() // 2  # number of anchors
        try:
            #通过kmean_anchors从新计算出anchors大小
            # 如果bpr<0.98(最大为1 越大越好) 使用k-means + 遗传进化算法选择出与数据集更匹配的anchors框  [9, 2]
            anchors = kmean_anchors(dataset, n=na, img_size=imgsz, thr=thr, gen=1000, verbose=False)
        except Exception as e:
            LOGGER.info(f'{PREFIX}ERROR: {e}')
        #通过新得到的anchors计算metric得到new_bpr
        new_bpr = metric(anchors)[0]
        # 比较k-means + 遗传进化算法进化后的anchors的new_bpr和原始anchors的bpr
        # 注意: 这里并不一定进化后的bpr必大于原始anchors的bpr
        #           因为两者的衡量标注是不一样的  进化算法的衡量标准是适应度 而这里比的是bpr
        if new_bpr > bpr:  # replace anchors
            anchors = torch.tensor(anchors, device=m.anchors.device).type_as(m.anchors)
            # 替换m的anchors(相对各个feature map)
            m.anchors[:] = anchors.clone().view_as(m.anchors) / m.stride.to(m.anchors.device).view(-1, 1, 1)  # loss
            # 检查anchor顺序和stride顺序是否一致 不一致就调整
            # 因为我们的m.anchors是相对各个feature map 所以必须要顺序一致 否则效果会很不好
            check_anchor_order(m)
            LOGGER.info(f'{PREFIX}New anchors saved to model. Update model *.yaml to use these anchors in the future.')
        else:
            LOGGER.info(f'{PREFIX}Original anchors better than new anchors. Proceeding with original anchors.')

# 对anchors做kmeans聚类
#n=9：一个网格可能有九个锚框
def kmean_anchors(dataset='./data/coco128.yaml', n=9, img_size=640, thr=4.0, gen=1000, verbose=True):
    """ Creates kmeans-evolved anchors from training dataset

        Arguments:
            dataset: path to data.yaml, or a loaded dataset
            n: number of anchors
            img_size: image size used for training
            thr: anchor-label wh ratio threshold hyperparameter hyp['anchor_t'] used for training, default=4.0
            gen: generations to evolve anchors using genetic algorithm
            verbose: print all results

        Return:
            k: kmeans evolved anchors

        Usage:
            from utils.autoanchor import *; _ = kmean_anchors()
    """
    """
            这个函数才是这个这个文件的核心函数，功能：使用K-means + 遗传算法 算出更符合当前数据集的anchors。
            使用了k-means聚类，还使用了Genetic Algorithm遗传算法，在k-means聚类的结果上进行mutation变异。

            在check_anchors中调用
            使用K-means + 遗传算法 算出更符合当前数据集的anchors
            Creates kmeans-evolved anchors from training dataset
            :params path: 数据集的路径/数据集本身
            :params n: anchor框的个数
            :params img_size: 数据集图片约定的大小
            :params thr: 阈值 由hyp['anchor_t']参数控制
            :params gen: 遗传算法进化迭代的次数(突变 + 选择)
            :params verbose: 是否打印所有的进化(成功的)结果 默认传入是Fasle的 只打印最佳的进化结果即可
            :return k: k-means + 遗传算法进化 后的anchors
        """

    """
        1、载入数据集，得到数据集中所有数据的wh
        2、将每张图片中wh的最大值等比例缩放到指定大小img_size，较小边也相应缩放
        3、将bboxes从相对坐标改成绝对坐标（乘以缩放后的wh）
        4、筛选bboxes，保留wh都大于等于两个像素的bboxes
        5、使用k-means聚类得到n个anchors（掉k-means包，涉及一个白化操作）
        6、使用遗传算法随机对anchors的wh进行变异，
                变异结果用使用anchor_fitness方法计算得到的fitness（适应度）进行评估
                如果变异后效果变得更好，就将变异后的结果赋值给anchors，
                如果变异后效果变差就跳过，默认变异1000次
    """
    from scipy.cluster.vq import kmeans

    npr = np.random
    #1/4
    thr = 1 / thr
    #metric同上面的check_anchors中的metric方法
    def metric(k, wh):  # compute metrics,计算指标的函数
        """
                        用于print_results函数和anchor_fitness函数
                        计算ratio metric: 整个数据集的gt框与anchor对应宽比和高比即:gt_w/k_w,gt_h/k_h + x + best_x  用于后续计算bpr+aat
                        注意我们这里选择的metric是gt框与anchor对应宽比和高比
                                        而不是常用的iou 这点也与nms的筛选条件对应，是yolov5中使用的新方法

                        :params k: anchor框（九个锚框大小）
                        :params wh: 传进来的图片大小整个数据集的wh [N, 2]
                        :return x: [N, 9] N个gt框与所有anchor框的宽比或高比(两者之中较小者)
                        :return x.max(1)[0]: [N] N个gt框与所有anchor框中的最大宽比或高比(两者之中较小者)
                """
        r = wh[:, None] / k[None]
        x = torch.min(r, 1 / r).min(2)[0]  # ratio metric
        # x = wh_iou(wh, torch.tensor(k))  # iou metric
        return x, x.max(1)[0]  # x, best_x

    #计算变异的适应度
    def anchor_fitness(k):  # mutation fitness
        """
                        用于kmean_anchors函数
                        适应度计算 优胜劣汰 用于遗传算法中衡量突变是否有效的标注 如果有效就进行选择操作 没效就继续下一轮的突变
                        :params k: [9, 2] k-means生成的9个anchors     wh: [N, 2]: 数据集的所有gt框的宽高
                        :return (best * (best > thr).float()).mean()=适应度计算公式 [1] 注意和bpr有区别 这里是自定义的一种适应度公式
                                返回的是输入此时anchor k 对应的适应度
                """
        #求出best
        _, best = metric(torch.tensor(k, dtype=torch.float32), wh)
        #best > thr,即best>4时，才会乘以best,然后求均值才会是适应度
        return (best * (best > thr).float()).mean()  # fitness

    #打印中间结果
    def print_results(k, verbose=True):
        """
                        用于kmean_anchors函数中打印k-means计算相关信息
                        计算bpr、aat=>打印信息: 阈值+bpr+aat  anchor个数+图片大小+metric_all+best_mean+past_mean+Kmeans聚类出来的anchor框(四舍五入)
                        :params k: k-means得到的anchor k
                        :return k: input
                """
        # 将k-means得到的anchor k按面积从小到大进行排序
        k = k[np.argsort(k.prod(1))]  # sort small to large
        #   x: [N, 9] N个gt框与所有anchor框的宽比或高比(两者之中较小者)
        #   best: [N] N个gt框与所有anchor框中的最大 宽比或高比(两者之中较小者)
        x, best = metric(k, wh0)
        #   (best > thr).float(): True=>1.  False->0.  .mean(): 求均值
        #  bpr(best possible recall): 最多能被召回(通过thr)的gt框数量 / 所有gt框数量  [1] 0.96223  小于0.98 才会用k-means计算anchor
        #  aat(anchors above threshold): [1] 3.54360 每个target平均有多少个anchors
        bpr, aat = (best > thr).float().mean(), (x > thr).float().mean() * n  # best possible recall, anch > thr
        s = f'{PREFIX}thr={thr:.2f}: {bpr:.4f} best possible recall, {aat:.2f} anchors past thr\n' \
            f'{PREFIX}n={n}, img_size={img_size}, metric_all={x.mean():.3f}/{best.mean():.3f}-mean/best, ' \
            f'past_thr={x[x > thr].mean():.3f}-mean: '
        for i, x in enumerate(k):
            s += '%i,%i, ' % (round(x[0]), round(x[1]))
        if verbose:
            LOGGER.info(s[:-2])
        return k

    # 载入数据集
    if isinstance(dataset, str):  # *.yaml file
        with open(dataset, errors='ignore') as f:
            #从yaml文件中返回一个data_dict
            data_dict = yaml.safe_load(f)  # model dict
        from utils.datasets import LoadImagesAndLabels
        #通过data_dict传进去通过LoadImagesAndLabels（自定义数据集）实例化以后得到dataset
        dataset = LoadImagesAndLabels(data_dict['train'], augment=True, rect=True)

    # Get label wh
    # 得到数据集中所有数据的wh
    # 将数据集图片的最长边缩放到img_size, 较小边相应缩放
    shapes = img_size * dataset.shapes / dataset.shapes.max(1, keepdims=True)
    # wh0;未做随机化尺度变化（与上面的wh比较）
    # 将原本数据集中gt boxes归一化的wh缩放到shapes尺度
    wh0 = np.concatenate([l[:, 3:5] * s for s, l in zip(shapes, dataset.labels)])  # wh

    # Filter，过滤
    # 统计gt boxes中宽或者高小于3个像素的个数, 目标太小 发出警告
    i = (wh0 < 3.0).any(1).sum()
    if i:
        LOGGER.info(f'{PREFIX}WARNING: Extremely small objects found. {i} of {len(wh0)} labels are < 3 pixels in size.')
    # 筛选出label大于2个像素的框拿来聚类,[...]内的相当于一个筛选器,为True的留下
    wh = wh0[(wh0 >= 2.0).any(1)]  # filter > 2 pixels
    # wh = wh * (npr.rand(wh.shape[0], 1) * 0.9 + 0.1)  # multiply by random scale 0-1

    # Kmeans calculation
    # Kmeans聚类方法: 使用欧式距离来进行聚类
    LOGGER.info(f'{PREFIX}Running kmeans for {n} anchors on {len(wh)} points...')
    #std()：求标准差，为了白化使用
    s = wh.std(0)  # sigmas for whitening
    #K是聚类以后锚框的值
    # 开始聚类,仍然是聚成n类,返回聚类后的anchors k(这个anchor k是白化后数据的anchor框)
    # 另外还要注意的是这里的kmeans使用欧式距离来计算的
    # 运行k-means的次数为30次  obs: 传入的数据必须先白化处理 'whiten operation'
    # 白化处理: 新数据的标准差=1 降低数据之间的相关度，不同数据所蕴含的信息之间的重复性就会降低，网络的训练效率就会提高
    # 白化操作博客: https://blog.csdn.net/weixin_37872766/article/details/102957235
    k = kmeans(wh / s, n, iter=30)[0] * s  # points   kmean distance; 使用scipy包的kmeans函数
    if len(k) != n:  # kmeans may return fewer points than requested if wh is insufficient or too similar
        LOGGER.warning(f'{PREFIX}WARNING: scipy.cluster.vq.kmeans returned only {len(k)} of {n} requested points')
        k = np.sort(npr.rand(n * 2)).reshape(n, 2) * img_size  # random init
    #就是上面的i = (wh0 < 3.0).any(1).sum() if i:这部分
    wh = torch.tensor(wh, dtype=torch.float32)  # filtered
    wh0 = torch.tensor(wh0, dtype=torch.float32)  # unfiltered
    # 输出新算的anchors k 相关的信息
    k = print_results(k, verbose=False)

    # Plot
    # k, d = [None] * 20, [None] * 20
    # for i in tqdm(range(1, 21)):
    #     k[i-1], d[i-1] = kmeans(wh / s, i)  # points, mean distance
    # fig, ax = plt.subplots(1, 2, figsize=(14, 7), tight_layout=True)
    # ax = ax.ravel()
    # ax[0].plot(np.arange(1, 21), np.array(d) ** 2, marker='.')
    # fig, ax = plt.subplots(1, 2, figsize=(14, 7))  # plot wh
    # ax[0].hist(wh[wh[:, 0]<100, 0],400)
    # ax[1].hist(wh[wh[:, 1]<100, 1],400)
    # fig.savefig('wh.png', dpi=200)

    # Evolve进化过程
    #调用计算变异的适应度函数
    f, sh, mp, s = anchor_fitness(k), k.shape, 0.9, 0.1  # fitness, generations, mutation prob, sigma
    #gen：迭代代数
    pbar = tqdm(range(gen), desc=f'{PREFIX}Evolving anchors with Genetic Algorithm:')  # progress bar
    # 根据聚类出来的n个点采用遗传算法生成新的anchor
    for _ in pbar:
        v = np.ones(sh)# v [9, 2] 全是1
        #一直做变异，直到有变化。即一直做循环，直至V不为1
        while (v == 1).all():  # mutate until a change occurs (prevent duplicates)
            v = ((npr.random(sh) < mp) * random.random() * npr.randn(*sh) * s + 1).clip(0.3, 3.0)
        # 变异(改变这一时刻之前的最佳适应度对应的anchor k)
        #聚类后的锚框k乘以v，再做clip,
        kg = (k.copy() * v).clip(min=2.0)
        # 计算变异后的anchor kg的适应度
        fg = anchor_fitness(kg)
        #变异后的适应度是不是比原来的f（即原来的锚框）更好的话
        if fg > f:
            #使用进化后的锚框值
            # 选择变异后的anchor kg为最佳的anchor k 变异后的适应度fg为最佳适应度f
            #即使用变异后的k(即新anchor)
            f, k = fg, kg.copy()
            pbar.desc = f'{PREFIX}Evolving anchors with Genetic Algorithm: fitness = {f:.4f}'
            if verbose:
                print_results(k, verbose)

    return print_results(k)
#自动锚框步骤总结：
# 载入数据集，得到数据集中所有数据的wh;
# 将每张图片中wh的最大值等比例缩放到指定大小img_size，较小边也相应缩放;
# 将bboxes从相对坐标改成绝对坐标（乘以缩放后的wh）;
# 筛选bboxes，保留wh都大于等于两个像素的bboxes;
# 使用k-means聚类得到n个anchors（掉k-means包 涉及一个白化操作）;
# 使用遗传算法随机对anchors的wh进行变异，如果变异后效果变得更好（使用anchor_fitness方法计算得
# 到的fitness（适应度）进行评估）就将变异后的结果赋值给anchors，如果变异后效果变差就跳过，
# 默认变异1000次;