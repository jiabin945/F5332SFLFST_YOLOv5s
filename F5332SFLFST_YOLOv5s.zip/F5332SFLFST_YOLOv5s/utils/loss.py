# YOLOv5 🚀 by Ultralytics, GPL-3.0 license
"""
Loss functions
"""

import torch
import torch.nn as nn
from utils.metrics import bbox_iou_xiou, bbox_alphafocal_iou, bbox_wiou, bbox_iou

#from utils.metrics import bbox_iou
from utils.torch_utils import de_parallel
#这篇博文介绍loss挺好的：https://blog.csdn.net/yang332233/article/details/120480811

from utils.metrics import bbox_alpha_iou
from data.tricks.varifocalLoss import VFLoss

def smooth_BCE(eps=0.1):  # https://github.com/ultralytics/yolov3/issues/238#issuecomment-598028441
    # return positive, negative label smoothing BCE targets
    return 1.0 - 0.5 * eps, 0.5 * eps


#二元交叉熵损失函数，blur 意为模糊 据下行原版注释是减少了错失标签带来的影响
class BCEBlurWithLogitsLoss(nn.Module):
    """
            函数功能：BCE函数的一个替代，是yolov5作者的一个实验性的函数

            源码地址：https://github.com/ultralytics/yolov5/issues/1030
            被调用：用在ComputeLoss类的__init__

        """
    """
        The idea was to reduce the effects of false negatives (missing labels) 就是认为不是没有这个目标，其实图片还是有的
    """
    # BCEwithLogitLoss() with reduced missing label effects.
    def __init__(self, alpha=0.05):
        super().__init__()
        # 这个BCEWithLogitsLoss类是将sigmoid函数和bceloss（二进制交叉熵损失）集合到一个类
        # 这里BCEWithLogitsLoss 是输入的每一个元素带入sigmoid函数之后 再同标签计算BCE loss
        self.loss_fcn = nn.BCEWithLogitsLoss(reduction='none')  # must be nn.BCEWithLogitsLoss()
        self.alpha = alpha#这个应该算是一个模糊系数吧 默认为0.05

    def forward(self, pred, true):
        #使用上面定义的nn.BCEWithLogitsLoss，
        # 得到了预测值和标签值（真实值）的BCE loss 注：预测值是经过sigmoid函数处理再计算BCE的
        loss = self.loss_fcn(pred, true)
        pred = torch.sigmoid(pred)  # prob from logits,预测值使用激活函数处理归一化 数学意义为每一位对应类别出现的概率
        dx = pred - true  # reduce only missing label effects仅减少缺失的标签（fp）
        # 如果采样绝对值的话 会减轻pred和gt差异过大而造成的影响
        # dx = (pred - true).abs()  # reduce missing label and false label effects
        """
                        torch.exp()函数就是求e的多少次方  输入tensor每一个元素经过计算之后返回对应的tensor
                        根据下式 对于正常的较大概率的样本 dx对应值为绝对值较小一个负数 假设为-0.12，则-1为-1.12除0.05 为-22.4，
                        -22.4 指数化之后为一个很小很小的正数，1-该正数之后得到的值较大 再在loss中乘上之后影响微乎其微
                        而对于missing的样本 dx对应为一个稍大的正数 如0.3 减去1之后为-0.7 除以0.05 为 -14
                        -14相比-22.4值为指数级增大，因此对应的alpha_factor相比正常样本显著减小 在loss中较小考虑
                        """
        # Q:有一个问题，为什么yolov5要对missing的样本有这样的容忍度，而不是选择直接屏蔽掉对应样本呢？
        #下面两行的原因reduce the effects of false negatives (缺失的 labels) 就是认为不是没有这个目标，其实图片还是有的，减少这种效果
        #因为比如coco数据集中没有标注的情况，即有一些目标标签缺失的情况
        alpha_factor = 1 - torch.exp((dx - 1) / (self.alpha + 1e-4))
        loss *= alpha_factor
        # 这个mean的意义应该为对一批batch中的每一个样本得到的BCE loss求均值作为返回值
        return loss.mean()

# Focal loss主要是为了解决one-stage目标检测中正负样本比例严重失衡的问题。该损失函数降低了大量简单负样本在训练中所占的权重。
class FocalLoss(nn.Module):
    # Wraps focal loss around existing loss_fcn(), i.e. criteria = FocalLoss(nn.BCEWithLogitsLoss(), gamma=1.5)
    def __init__(self, loss_fcn, gamma=1.5, alpha=0.25):
        super().__init__()
        self.loss_fcn = loss_fcn  # must be nn.BCEWithLogitsLoss()
        self.gamma = gamma
        self.alpha = alpha
        self.reduction = loss_fcn.reduction
        self.loss_fcn.reduction = 'none'  # required to apply FL to each element

    def forward(self, pred, true):
        loss = self.loss_fcn(pred, true)
        # p_t = torch.exp(-loss)
        # loss *= self.alpha * (1.000001 - p_t) ** self.gamma  # non-zero power for gradient stability

        # TF implementation https://github.com/tensorflow/addons/blob/v0.7.1/tensorflow_addons/losses/focal_loss.py
        pred_prob = torch.sigmoid(pred)  # prob from logits
        p_t = true * pred_prob + (1 - true) * (1 - pred_prob)
        alpha_factor = true * self.alpha + (1 - true) * (1 - self.alpha)
        modulating_factor = (1.0 - p_t) ** self.gamma
        loss *= alpha_factor * modulating_factor

        if self.reduction == 'mean':
            return loss.mean()
        elif self.reduction == 'sum':
            return loss.sum()
        else:  # 'none'
            return loss

#3.0这个位置应该是标签平滑的，这里出现了新的函数
class QFocalLoss(nn.Module):
    """
            函数功能：用来代替FocalLoss
            论文地址: https://arxiv.org/abs/2006.04388
            被调用：在ComputeLoss中代替FocalLoss即可
        """
    # Wraps Quality focal loss around existing loss_fcn(), i.e. criteria = FocalLoss(nn.BCEWithLogitsLoss(), gamma=1.5)
    def __init__(self, loss_fcn, gamma=1.5, alpha=0.25):
        super().__init__()
        self.loss_fcn = loss_fcn  # must be nn.BCEWithLogitsLoss()
        self.gamma = gamma
        self.alpha = alpha
        self.reduction = loss_fcn.reduction
        self.loss_fcn.reduction = 'none'  # required to apply FL to each element

    def forward(self, pred, true):
        loss = self.loss_fcn(pred, true)

        pred_prob = torch.sigmoid(pred)  # prob from logits
        alpha_factor = true * self.alpha + (1 - true) * (1 - self.alpha)
        modulating_factor = torch.abs(true - pred_prob) ** self.gamma
        loss *= alpha_factor * modulating_factor

        if self.reduction == 'mean':
            return loss.mean()
        elif self.reduction == 'sum':
            return loss.sum()
        else:  # 'none'
            return loss

# 计算损失（分类损失+置信度损失+框坐标回归损失）  修改IOU的地方
class ComputeLoss:
    """
            函数功能：定义一些后面要用到的变量，参数，函数等。
            被调用：这个函数会用在train.py中进行损失计算
        """
    # Compute losses
    def __init__(self, model, autobalance=False):
        self.sort_obj_iou = False# 后面筛选置信度损失正样本的时候是否先对iou排序
        device = next(model.parameters()).device  # get model device
        h = model.hyp  # hyperparameters 获得超参数

        # Define criteria
        #预设的BCEBlurWithLogitsLoss（作者预设未使用）
        # BCEcls = BCEBlurWithLogitsLoss()
        # BCEobj = BCEBlurWithLogitsLoss()
        # 定义类别和目标性得分损失函数，可以看到用的都是BCEWithLogitsLoss
        # 即使用损失函数相同，都是经过激活函数与bceloss之后得到的
        # 看到两个超参在hyp.scratch.yaml中都为1.0
        # h['obj_pw']=h['cls_pw']=1  即二者BCEWithLogitsLoss默认的正样本权重也是1
        BCEcls = nn.BCEWithLogitsLoss(pos_weight=torch.tensor([h['cls_pw']], device=device))
        BCEobj = nn.BCEWithLogitsLoss(pos_weight=torch.tensor([h['obj_pw']], device=device))

        # Class label smoothing https://arxiv.org/pdf/1902.04103.pdf eqn 3
        # 类别标签平滑  eps=0代表不做标签平滑-> cp=1 cn=0  eps!=0代表做标签平滑
        #cp代表positive的标签值1，cn代表negative的标签值0
        #eps默认为0，表示标签平滑没用上
        self.cp, self.cn = smooth_BCE(eps=h.get('label_smoothing', 0.0))  # positive, negative BCE targets

        # # Focal loss  g=0 代表不用focal loss
        g = h['fl_gamma']  # focal loss gamma 在配置文件中为0.0
        if g > 0:
            # g>0 将分类损失和置信度损失(BCE)都换成focalloss损失函数
            BCEcls, BCEobj = FocalLoss(BCEcls, g), FocalLoss(BCEobj, g)

            #改进实验中，将上面bce改为varifocalLoss
            #BCEcls, BCEobj = VFLoss(BCEcls, g), VFLoss(BCEobj, g)
            # BCEcls, BCEobj = QFocalLoss(BCEcls, g), QFocalLoss(BCEobj, g)  # 调用QFocalLoss来代替FocalLoss

        # det: 返回的是模型的检测头 Detector 3个 分别对应产生三个输出feature map
        det = de_parallel(model).model[-1]  # Detect() module

        # balance用来设置三个feature map对应输出的置信度损失系数(平衡三个feature map的置信度损失)
        # 从左到右分别对应大feature map(检测小目标,系数大，可能因为比较难检测)到小feature map(检测大目标)
        #       一般来说，检测小物体的难度大一点，所以会增加大特征图的损失系数，让模型更加侧重小物体的检测
        # 如果det.nl=3就返回[4.0, 1.0, 0.4]否则返回[4.0, 1.0, 0.25, 0.06, .02]
        # self.balance = {3: [4.0, 1.0, 0.4], 4: [4.0, 1.0, 0.25, 0.06], 5: [4.0, 1.0, 0.25, 0.06, .02]}[det.nl]
        self.balance = {3: [4.0, 1.0, 0.4]}.get(det.nl, [4.0, 1.0, 0.25, 0.06, 0.02])  # P3-P7

        # 三个预测头的下采样率det.stride: [8, 16, 32]  .index(16): 求出下采样率stride=16的索引
        # 这个参数会用来自动计算更新3个feature map的置信度损失系数self.balance
        #获取各个特征层 stride相关参数
        self.ssi = list(det.stride).index(16) if autobalance else 0  # stride 16 index

        # self.BCEcls: 类别损失函数   self.BCEobj: 置信度损失函数   self.hyp: 超参数
        # self.gr: 计算真实框的置信度标准的iou比率    self.autobalance: 是否自动更新各feature map的置信度损失平衡系数  默认False
        #即：将各个LOSS加入到类公共变量中
        self.BCEcls, self.BCEobj, self.gr, self.hyp, self.autobalance = BCEcls, BCEobj, 1.0, h, autobalance

        # na: number of anchors  每个grid_cell的anchor数量 = 3
        # nc: number of classes  数据集的总类别 = 80
        # nl: number of detection layers   Detect的个数 = 3
        # anchors: [3, 3, 2]  3个feature map 每个feature map上有3个anchor(w,h) 这里的anchor尺寸是相对feature map的
        #参数获取
        for k in 'na', 'nc', 'nl', 'anchors':
            #函数的功能相对比较复杂，它最基础的功能是修改类实例对象中的属性值。
            #即把名字为k的赋值为各个检测层中的 'na', 'nc', 'nl', 'anchors'
            setattr(self, k, getattr(det, k))

    """
        Args:
            p: 网络输出，List[torch.tensor * 3], p[i].shape = (b, 3, h, w, nc+5), hw分别为特征图的长宽,b为batch-size
            targets: targets.shape = (nt, 6) , 6=icxywh,i=0表示第一张图片，c为类别，然后为坐标xywh
            是这个bat中16幅图片标注的目标框的信息
            model: 模型

        Returns:

        """
    #p是一个列表，有三个元素-三个不同特征图尺度，每个都是tensor，每个tensor维度为16（即一个bat） p[i].shape = (b, 3, h, w, nc+5)
    #targets：预测框，表示有多少个目标，这里【107，6】，107表示一个bat目标个数,6表示6=icxywh,i=0表示第一张图片，c为类别，然后为坐标xywh
    def __call__(self, p, targets,category_iou = None):  # predictions, targets, model
        """
                   函数功能：相当于forward函数，在这个函数中进行损失函数的前向传播。
                   被调用：train.py初始化损失函数类：
               """
        device = targets.device
        # 初始化lcls, lbox, lobj三种损失值  tensor([0.])
        lcls, lbox, lobj = torch.zeros(1, device=device), torch.zeros(1, device=device), torch.zeros(1, device=device)
        #tcls 获得标签分类：列表三个元素258，585，582表示每个边界框tbox对应所属的class index
        # tbox:边框，xywh 其中xy为这个target对当前grid_cell左上角的偏移量
        #其列表有三个元素：258，585，582表示不同尺度的预测框有多少个
        # 索引，
          # b: 表示这个target属于的image index
          # a: 表示这个target使用的anchor index
          # gj: 经过筛选后确定某个target在某个网格中进行预测(计算损失)  gj表示这个网格的左上角y坐标
          # gi: 表示这个网格的左上角x坐标
        # anch: 表示这个target所使用anchor的尺度（相对于这个feature map）  注意可能一个target会使用大小不同anchor进行计算
        tcls, tbox, indices, anchors = self.build_targets(p, targets)  # targets

        # 依次遍历三个feature map(80*80,40*40,20*20)，一层一层处理，预测输出pi loss
        for i, pi in enumerate(p):  # layer index(第一个80*80,二40*40,三20*20), layer predictions  #pi [4,3,80,80,25]  [4,3,40,40,25]  [4,3,20,20,25]
            # 根据indices获取索引，获取扩充正样本target(build_target中两个步骤符合条件的bbox)
            #一个bat(16)的图片号、anchor序号、网格位置
            b, a, gj, gi = indices[i]  # image, anchor, gridy, gridx
            #tobj初始化为0 ,即初始化target置信度(先全是负样本 后面再筛选正样本赋值)
            #pi[..., 0]获取最后一维的第一维，最后一维表示每一个目标的七个标签，所以这里维数表示表示的即是总数是当前输出层的targets总数
            # tobj  [16,3,80,80]   pi:torch.Size([16, 3, 80, 80, 25]),25表示5（置信度+中心坐标+宽高）+种类20
            tobj = torch.zeros_like(pi[..., 0], device=device)  # target obj

            #对应层的这个bat的预测框个数
            n = b.shape[0]  # number of targets 正样本总数
            if n:
                # 精确得到第b张图片的第a个feature map的grid_cell(gi, gj)对应的预测值
                # 用这个预测值与我们筛选的这个grid_cell的真实框进行预测(计算损失)
                # 找到对应网格的输出, 取出对应位置预测值
                #pi的torch.Size([16, 3, 80, 80, 25])，即ps对应80*80上的数据
                #ps:[258,25],即258个预测狂对应的中心点坐标、宽高、所属种类
                # 这里需要仔细看下，这里pi是网络输出的值，
                # 而b,a,gj,gi都是目标gt的信息
                # 所以这里就是为了让网络输出的值相应位置也要和gt一样！
                ps = pi[b, a, gj, gi]  # prediction subset corresponding to targets：目标对应的预测子集

                # Regression
                # 对输出xywh做反算，使用目标框回归公式，通过偏移值求出框真正的bx、by、bw、bh而不是偏移值了
                pxy = ps[:, :2].sigmoid() * 2 - 0.5
                pwh = (ps[:, 2:4].sigmoid() * 2) ** 2 * anchors[i]
                pbox = torch.cat((pxy, pwh), 1)  # predicted box


                # #芒果wiou
                # if category_iou == 'wise_iou':
                #     loss, iou = bbox_iou(pbox.T, tbox[i], x1y1x2y2=False, WIoU=True)  # iou(prediction, target)
                #     lbox += loss.mean()  # iou loss
                # else:
                #     iou = bbox_iou(pbox.T, tbox[i], x1y1x2y2=False, CIoU=True)  # iou(prediction, target)
                #     lbox += (1.0 - iou).mean()  # iou loss
                #loss, iou = bbox_iou(pbox.T, tbox[i], x1y1x2y2=False, WIoU=True)  # iou(prediction, target)
                #lbox += loss.mean()  # iou loss


                # 计算边框损失，注意这个CIoU=True，计算的是ciou损失，注意tbox[i]里面为gt
                #iou = bbox_iou(pbox.T, tbox[i], x1y1x2y2=False, CIoU=True)  # iou(prediction, target)
                #1改进α-iou
                #iou = bbox_alpha_iou(pbox.T, tbox[i], x1y1x2y2=False, CIoU=True)
                #iou = bbox_alpha_iou(pbox.T, tbox[i], x1y1x2y2=False, CIoU=True,Focal=True)
                #2siou
                #iou = bbox_iou(pbox.T, tbox[i], x1y1x2y2=False, SIoU=True)
                #elou
                #iou = bbox_iou(pbox.T, tbox[i], x1y1x2y2=False, EIoU=True)
                #4xiou
                #iou = bbox_iou_xiou(pbox.T, tbox[i], x1y1x2y2=False, XIoU=True)

                # v3版本的iou(除了wiou)
                #iou = bbox_iou(pbox, tbox[i], EIoU=True, Focal=True)  # iou(prediction, target)
                #wiou ,还需要改monotonous,当v1时候，scale=False，其它scale=True
                #iou = bbox_wiou(pbox, tbox[i], WIoU=True, scale=True)

                #test版本中的iou(focal+alpha)
                iou = bbox_alphafocal_iou(pbox.T, tbox[i], x1y1x2y2=False,EIoU=True,Focal=True,scale=False)
                #mpdiou
                #iou = bbox_alphafocal_iou(pbox.T, tbox[i], x1y1x2y2=False, MPDIoU=True, scale=True)

                #通过iou计算出iou loss
                #lbox += (1.0 - iou).mean()  # iou loss 定位损失
                #上面此处计算的iou为：预测框与三个负责预测的网格（其宽高为gtbox的宽高）的CIoU


                #v3,test版本的lbox#通过iou计算出iou loss
                if type(iou) is tuple:
                    if len(iou)==2:
                            #squeeze():去除size为1的维度，包括行和列。当维度大于等于2时，squeeze()无作用。
                        lbox += (iou[1].detach().squeeze() * (1 - iou[0].squeeze())).mean() #detach()函数来切断一些分支的反向传播,# 会将requires_grad 属性设置为False
                        iou = iou[0].squeeze()
                    else:
                        lbox+=(iou[0]*iou[1]).mean()
                        iou=iou[2].squeeze()
                else:
                    #lbox += (1.0 - iou).mean()  # iou loss 定位损失.就直接使用原有的lbox，并没有使用使用迪菲的
                    lbox += (1.0 - iou.squeeze()).mean()  # iou loss
                    iou = iou.squeeze()



                # Objectness
                # iou.detach()  不会更新iou梯度  iou并不是反向传播的参数 所以不需要反向传播梯度信息
                # 获取target所对应的obj,网格中存在gt目标的会被标记为iou与gt的交并比
                #感觉是通过对iou进行不更新梯度、必须大于等于0等操作得到iou
                score_iou = iou.detach().clamp(0).type(tobj.dtype)# .clamp(0)必须大于等于0
                #因为对iou排序函数sort_obj_iou为false，所以跳过if
                if self.sort_obj_iou:# 可以看下官方的解释 我也不是很清楚为什么这里要对iou排序？？？
                    # https://github.com/ultralytics/yolov5/issues/3605
                    #在具有密集目标的场景中计算ComputeLoss时，可能有多个GT匹配同一锚点
                    sort_id = torch.argsort(score_iou)
                    b, a, gj, gi, score_iou = b[sort_id], a[sort_id], gj[sort_id], gi[sort_id], score_iou[sort_id]
                #人为给出真实框信息置信度，因为是obj损失函数中的c(上三角)
                # （自己感觉，上面计算完定位损失，因为下面分类和置信度BCEWithLogitsLoss-即经过sig后使用bce(即二值交叉熵损失函数)因为要拿标准的gt与目标框对比，所以
                # 真实框gt也要需要置信度）
                # 预测信息有置信度 但是真实框信息是没有置信度的 所以需要我们人为的给一个标准置信度
                # self.gr是iou ratio [0, 1]  self.gr越大置信度越接近iou  self.gr越小置信度越接近1(人为加大训练难度)
                tobj[b, a, gj, gi] = (1.0 - self.gr) + self.gr * score_iou  # iou ratio

                # Classification  只计算所有正样本的分类损失
                # 设置如果类别数大于1才计算分类损失
                if self.nc > 1:  # cls loss (only if multiple classes)
                    # targets 原本负样本是0  这里使用smooth label 就是cn（负样本标签值，上面求出来为0）
                    #full_like：像ps那样的形状一样，ps中的元素值都为cn（即0），得到t为【258，20】，即值为cn，形状为ps[:, 5:]
                    #t相当于把ps(即预测的分类)复制过来，先为0，后设置为1，表示gt框
                    t = torch.full_like(ps[:, 5:], self.cn, device=device)  # targets
                    #n表示预测框个数，因为上面t为【258，20】，所以下面表示第一个维度取所有，即第i层输出的正样本数据（第一次循环为258）
                    #第2维取出第i层输出数据的标签，都设为cp=1。，即把每个目标的相应类别位置赋值为1，相当于one-hot格式的gt
                    t[range(n), tcls[i]] = self.cp

                    #分类损失
                    '''
                                        t [95,20]

                                        ## ps [95,25]
                                        ps[:, 5:]  -->[95,20]

                                        '''
                    #即把预测的框258个的后20（即预测框的种类属于哪一类）与gt框真实的分类（因为都为1，所以百分百正确）
                    # 进行计算分类损失
                    lcls += self.BCEcls(ps[:, 5:], t)  # BCE 对每个类单独计算Loss

                # Append targets to text file
                # with open('targets.txt', 'a') as file:
                #     [file.write('%11.5g ' * 4 % tuple(x) + '\n') for x in torch.cat((txy[i], twh[i]), 1)]


            # # 计算交叉熵 正样本与特征图上提的特征计算交叉熵 这个算的是objectness置信度的loss值
            # Objectness loss step2 置信度损失是用所有样本(正样本 + 负样本)一起计算损失的
            #pi:torch.Size([16, 3, 80, 80, 25])  pi[..., 4]  -->[16,3,80,80]
            #这里说下85含义，    x,y,w,h,is_obj,class_0,class_1,...,class_79
            # 所以，4就代表是否是目标这类
            obji = self.BCEobj(pi[..., 4], tobj)
            # 每个feature map的置信度损失权重不同  要乘以相应的权重系数self.balance[i]
            # 一般来说，检测小物体的难度大一点，所以会增加大特征图的损失系数，让模型更加侧重小物体的检测
            lobj += obji * self.balance[i]  # obj loss
            if self.autobalance:
                # 自动更新各个feature map的置信度损失系数
                self.balance[i] = self.balance[i] * 0.9999 + 0.0001 / obji.detach().item()

        if self.autobalance:
            self.balance = [x / self.balance[self.ssi] for x in self.balance]
        # 根据超参中的损失权重参数 对各个损失进行平衡  防止总损失被某个损失所左右
        #在hyp.scratch.yaml文件中（6.1版本中在hyp.scratch_low.yaml系数与视频一致）
        lbox *= self.hyp['box']
        lobj *= self.hyp['obj']
        lcls *= self.hyp['cls']
        bs = tobj.shape[0]  # batch size
        # loss * bs: 整个batch的总损失，*bat16是因为一个bat有16张图片
        # .detach()  利用损失值进行反向传播 利用梯度信息更新的是损失函数的参数 而对于损失这个值是不需要梯度反向传播的
        #返回到train.py中的loss，loss_item=compute_loss(pred,target,...)
        return (lbox + lobj + lcls) * bs, torch.cat((lbox, lobj, lcls)).detach()

#build_targets用于用于获得在训练时计算loss函数所需要的目标框（bbox），即被认为是正样本
    '''
    build_targets函数用于获得在训练时计算loss函数所需要的目标框，即被认为是正样本
    与yolov3/v4的不同：yolov5支持跨网格预测
    对于任何一个bbox，三个输出预测特征层都可能有先验框anchors匹配；
    该函数输出的正样本框比传入的targets（GT框）数目多
    具体处理过程：
    (1)对于任何一层计算当前bbox和当前层anchor的匹配程度，不采用iou，而是shape比例；
       如果anchor和bbox的宽高比差距大于4，则认为不匹配，此时忽略相应的bbox，即当做背景；
    (2)然后对(1)中正样本bbox计算落在的网格所有anchors都计算loss(并不是直接和GT框比较计算loss，而是通过另外一个函数
    compute loss计算build_target做返回的正样本框做比较计算loss)
      注意此时落在网格不再是一个，而是附近的多个，这样就增加了正样本数，可能存在有些bbox在三个尺度都预测的情况；
      另外，yolov5也没有conf分支忽略阈值(ignore_thresh)的操作，而yolov3/v4有。
    '''

    """
            :params p: 预测框 由模型构建中的三个检测头Detector返回的三个yolo层的输出
                       tensor格式 list列表 存放三个tensor 对应的是三个yolo层的输出
                       如: [4, 3, 112, 112, 85]、[4, 3, 56, 56, 85]、[4, 3, 28, 28, 85]
                       [bs, anchor_num, grid_h, grid_w, xywh+class+classes]
                       可以看出来这里的预测值p是三个yolo层每个grid_cell(每个grid_cell有三个预测值)的预测值,后面肯定要进行正样本筛选
            :params targets: 数据增强后的真实框 [63, 6] [num_target,  image_index+class+xywh] xywh为归一化后的框的中心点与宽高都已经处理到0到1区间
            :return tcls: 表示这个target所属的class index
                    tbox: xywh 其中xy为这个target对当前grid_cell左上角的偏移量
                    indices: b: 表示这个target属于的image index
                             a: 表示这个target使用的anchor index
                            gj: 经过筛选后确定某个target在某个网格中进行预测(计算损失)  gj表示这个网格的左上角y坐标
                            gi: 表示这个网格的左上角x坐标
                    anch: 表示这个target所使用anchor的尺度（相对于这个feature map）  注意可能一个target会使用大小不同anchor进行计算
            """
    #p:三个预测特征层网络输出，reshape之后的，即（bat,3,h,w,nc+5）,但是在这里作为输入
    # target:gt框,targets.shape = (nt, 6) , 6=icxywh,i表示第i+1张图片，c为类别，然后为坐标xywh
    def build_targets(self, p, targets):
        #v5中3.0在general中通过module.model[-1]引入的检测层，但是这里独立出一个py，self就是检测层
        # Build targets for compute_loss(), input targets(image,class,x,y,w,h)
        #举例：p中第0个shape为torch.Size([16, 3, 80, 80, 25])（bat,三个尺度，宽，高，预测出来的目标框信息）
        #p中第0个shape为torch.Size([16, 3, 40, 40, 25])（bat,三个尺度，宽，高，预测出来的目标框信息）
        #na:anchor数目 调试3   nt:gt框数目：调试107，这里是指一个batch总的gt框数目，且都经过数据增强后的
        na, nt = self.na, targets.shape[0]  # number of anchors, targets（一个batch训练中经过mosaic数据增强的gt框，其中为bbox）注：这里是检测层
        #初始化tcls tbox indices anch，得到空列表（类别、便捷盒、索引、锚框）
        tcls, tbox, indices, anch = [], [], [], []
        #gain是为了后面将targets=[na,nt,7]中的归一化了的xywh映射到相对feature map尺度
        gain = torch.ones(7, device=targets.device)  # normalized to gridspace gain
        # anchor索引，后面有用，用于表示当前bbox和当前层的哪个anchor匹配
        ai = torch.arange(na, device=targets.device).float().view(na, 1).repeat(1, nt)  # same as .repeat_interleave(nt)
        # 先repeat targets和当前层anchor个数一样，即将targets复制3份，每份分配一个anchor编号，如0,1,2. 也就是每个anchor分配一份targets。
        #torch.Size([3, 107, 7])，原来shape是[107,7],现在因为重复三次，多了一个3的维度
        targets = torch.cat((targets.repeat(na, 1, 1), ai[:, :, None]), 2)  # append anchor indices
        # 设置网格中心偏移量
        g = 0.5  # bias
        # 附近的4个网格，下面因为*g所以偏移的都是0.5
        #因为每个图片坐标以左上角为原点，往右是x增加方向，往下是y增加的方向，调试出来的[0.5,0]
        #是往右偏移0.5，[0,0.5]是往下偏移0.5.出现负号即为往左或者下偏移0.5
        #这里即得到一个网格上下左右临近网格的偏移量
        off = torch.tensor([[0, 0],
                            [1, 0], [0, 1], [-1, 0], [0, -1],  # j,k,l,m
                            # [1, 1], [1, -1], [-1, 1], [-1, -1],  # jk,jm,lk,lm
                            ], device=targets.device).float() * g  # offsets
        # 对每个检测层进行处理
        # 遍历三个feature 筛选每个feature map(包含batch张图片)的每个anchor的正样本===》正采样
        for i in range(self.nl):# 三个尺度的预测特征图输出分支，nl表示第几个特征图
            #打印出此层的三个anchors，比如其中【1.25，1.625】是除以stride(这里为8)之后的值
            anchors, shape = self.anchors[i], p[i].shape
            # p是网络输出值  tensor([ 1.,  1., 80., 80., 80., 80.,  1.], device='cuda:0')
            # 7: image_index+class+xywh+anchor_index
            # gain: 保存每个输出feature map的宽高 -> gain[2:6]=gain[whwh]，即为当前特征层大小，第一个循环为80*80
            gain[2:6] = torch.tensor(p[i].shape)[[3, 2, 3, 2]]  # xyxy gain

            # 将标签框的xywh从基于0~1映射到基于特征图；targets的xywh本身是归一化尺度，故需要变成特征图尺度
            #原来targets信息在【0，1】之间，乘以gain以后变为特征图尺度
            t = targets * gain
            # 对每个输出层单独匹配
            # 首先将targets变成anchor尺度，方便计算；
            # 然后将target wh shape和anchor的wh计算比例，如果比例过大，则说明匹配度不高，将该bbox过滤，在当前层认为是bg
            if nt:
                """
                           预测的wh与anchor的wh做匹配，筛选掉比值大于hyp['anchor_t']的，从而更好的回归。
                           作者采用新的wh回归方式: (wh.sigmoid() * 2) ** 2 * anchors[i]
                           原来yolov3/v4为anchors[i] * exp(wh)。
                           将标签框与anchor的倍数控制在0~4之间；hyp.scratch.yaml中的超参数anchor_t=4，用于判定anchors与标签框契合度；
                           """
                # 计算当前target的wh和anchor的wh比例值
                # 如果最大比例大于预设值model.hyp['anchor_t']=4，则当前target和anchor匹配度不高，不强制回归，而把target丢弃
                # 计算比值ratio
                r = t[:, :, 4:6] / anchors[:, None]  # wh ratio
                ## 筛选满足1 / hyp['anchor_t'] < targets_wh/anchor_wh < hyp['anchor_t']的框;
                j = torch.max(r, 1 / r).max(2)[0] < self.hyp['anchor_t']  # compare
                # j = wh_iou(anchors, t[:, 4:6]) > model.hyp['iou_t']  # iou(3,n)=wh_iou(anchors(3,2), gwh(n,2))
                # 筛选过后的t.shape = (M, 7),M为筛选过后的数量
                #发现t的数量比刚开始的gt框数量nt（包括数据增强的）少了（原来是107，现在86），
                # 是因为上面某些bbox框和anchor匹配度不高，就会筛选掉
                t = t[j]  # filter

                ### 正采样  https://blog.csdn.net/wxd1233/article/details/126148680做了比较好的描述
                ### 提高正样本比例的操作【正采样】
                # Offsets 筛选当前格子周围格子 找到2个离target中心最近的两个格子  可能周围的格子也预测到了高质量的样本 我们也要把这部分的预测信息加入正样本中
                # 除了target所在的当前格子外, 还有2个格子对目标进行检测(计算损失) 也就是说一个目标需要3个格子去预测(计算损失)
                # 首先当前格子是其中1个 再从当前格子的上下左右四个格子中选择2个 用这三个格子去预测这个目标(计算损失)
                gxy = t[:, 2:4]  # grid xy label的中心点坐标(相对于以左上角为坐标原点的坐标)
                # 得到中心点相对于当前特征图的坐标, (M, 2)
                #gxi这里通过gain[[2,3]]-gxy正好取了个反，表示的是以特征图右下角为零点的gt box的(x,y)坐标信息，gain[[2, 3]]为当前featuremap的wh
                gxi = gain[[2, 3]] - gxy  # inverse
                # 对于筛选后的gtbox，计算其落在哪个网格内，同时找出邻近的网格，将这些网格都认为是负责预测该gtbox的网格
                #这两个条件可以用来选择靠近的两个邻居网格,把相对于各个网格左上角x<0.5,y<0.5和相对于右下角的x<0.5,y<0.5的框提取出来,就是j,k,l,m
                # jk和lm是判断gxy的中心点更偏向哪里
                # （左上方）筛选中心坐标 距离当前grid_cell的左、上方偏移小于g=0.5 且中心坐标必须大于1(坐标不能在边上，此时就没有4个格子了)
                # j: [126] bool 如果是True表示当前target中心点所在的格子的左边格子也对该target进行回归(后续进行计算损失)
                # k: [126] bool 如果是True表示当前target中心点所在的格子的上边格子也对该target进行回归(后续进行计算损失)
                # j，k分别是否满足要求的x与y的坐标的序列，即由True与Flase的两个x与y的列表
                j, k = ((gxy % 1 < g) & (gxy > 1)).T# 取所有x与y对1取模所在的行列小于g 且 x与y坐标都需要大于1 的点，
                # （右下方）筛选中心坐标 距离当前grid_cell的右、下方偏移小于g=0.5 且 中心坐标必须大于1(坐标不能在边上 此时就没有4个格子了)
                # l: [126] bool 如果是True表示当前target中心点所在的格子的右边格子也对该target进行回归(后续进行计算损失)
                # m: [126] bool 如果是True表示当前target中心点所在的格子的下边格子也对该target进行回归(后续进行计算损失)
                l, m = ((gxi % 1 < g) & (gxi > 1)).T  # 取所有x与y对1取模所在的行列小于g 且 x与y坐标都需要大于1 的点，
                # j.shape = (5, M)  # 5是因为预设的off是5个
                # j: [5, 86]  torch.ones_like(j): 当前格子, 不需要筛选全是True（因为这里当前格子是经过增加正样本的第一个步骤得到的）
                # j, k, l, m: 左上右下格子的筛选结果 可以看到对应gt box一定是有3个网格与之匹配。（结果就是当前格子为true,对应另外四个方向一定有两个为true）
                j = torch.stack((torch.ones_like(j), j, k, l, m))
                # yolov5不仅用目标中心点所在的网格预测该目标，还采用了距目标中心点的最近两个网格# 所以有五种情况，网格本身，上下左右，这就是repeat函数第一个参数为5的原因
                # 得到筛选后所有格子的正样本 格子数<=3*86 当gt中心点都不在边上时等号成立
                # t: [86, 7] -> 复制5份target[5, 86, 7]  分别对应当前格子和左上右下格子5个格子
                # j: [5, 86] + t: [5, 86, 7] => t: [258, 7] 理论上是小于等于3倍的86,即挑一些网格出来，从上下左右挑离他最近的两个网格 当且仅当没有边界的格子等号成立
                #步骤一得到的t，即过滤后的bbox，使用j方法来过滤
                t = t.repeat((5, 1, 1))[j]#这里将t复制5个，然后使用j来过滤# 第一个t是保留所有的gtbox，因为上一步里面增加了一个全为true的维度，# 第二个t保留了靠近方格左边的gtbox，# 第三个t保留了靠近方格上方的gtbox，# 第四个t保留了靠近方格右边的gtbox，# 第五个t保留了靠近方格下边的gtbox

                # 添加偏移量。对gxy加上off   offsets: 每个框中心点的偏移值，这258个都认为是在当前尺度的正样本
                ## 选择出最近的3个（包括自己）（感觉就是通过【0.5，1.5】这个距离算的）
                offsets = (torch.zeros_like(gxy)[None] + off[:, None])[j]
            else:
                t = targets[0]
                offsets = 0
#上述经过两个步骤筛选得到的258个都是正样本了
            # Define
            """
                    对每个gtbox找出对应的正样本anchor，
                    其中包括b表示当前gtbox属于batch内部的第几张图片，
                    a表示当前bbox和当前层的第几个anchor匹配上，
                    gi,gj是对应的负责预测该bbox的网格坐标，
                    gxy是不考虑offset或者说yolov3/v4里面设定的该bbox的负责预测网格中心点坐标xy，
                    gwh是对应的bbox wh，
                    c是该bbox类别
                    """
            #b表示当前bbox属于batch内部的第几张图片，c是该bbox类别
            b, c = t[:, :2].long().T  # image, class
            gxy = t[:, 2:4]  # grid xy #经过两次筛选的bbox中心点坐标的xy
            gwh = t[:, 4:6]  # grid wh # 经过两次筛选的bbox的wh
            gij = (gxy - offsets).long() #当前label目标框落在哪个网格上(注意整个网格大小80*80)
            gi, gj = gij.T  # grid xy indices（索引值）； 分别得到gridx，gridy

            # Append
            a = t[:, 6].long()  # anchor 索引
            # 添加索引，方便计算损失的时候取出对应位置的输出
            # b: image index  a: anchor index  gj: 网格的左上角y坐标  gi: 网格的左上角x坐标
            indices.append((b, a, gj.clamp_(0, shape[2] - 1), gi.clamp_(0, shape[3] - 1)))  # image,anchor,grid
            #indices.append((b, a, gj.clamp_(0, gain[3] - 1), gi.clamp_(0, gain[2] - 1)))  # image, anchor, grid indices
            # tbix: xywh 其中xy为这个target相对于当前grid_cell左上角的偏移量
            tbox.append(torch.cat((gxy - gij, gwh), 1))  #预测框box坐标值，为tbox
            #当前预测层的锚框的尺寸，虽然是重复的，但是为了与预测框一一对应，也会把258框对应的anchor值都放在这个列表中
            anch.append(anchors[a])  # # anchors 尺寸  对应的所有anchors
            #把类别c也添加到tcls列表中
            tcls.append(c)  # class
            #然后再次循环，这次对80*80处理，下次对40*40进行处理
        #当三个尺度（80，40，20）都完成之后，返回到train中，然后调用损失函数计算损失
        #tcls：当前目标框bbox类别列表 tbox：经过两次筛选bbox的中心点坐标、宽高信息
        # indices：包含image、index、anchor、indexgj: 网格的左上角y坐标gi: 网格的左上角x坐标的索引
        #anch：anchor尺寸
        return tcls, tbox, indices, anch
# class ComputeLoss:
#     # Compute losses
#     def __init__(self, model, autobalance=False):
#         self.sort_obj_iou = False
#         device = next(model.parameters()).device  # get model device
#         h = model.hyp  # hyperparameters
#
#         # Define criteria
#         BCEcls = nn.BCEWithLogitsLoss(pos_weight=torch.tensor([h['cls_pw']], device=device))
#         BCEobj = nn.BCEWithLogitsLoss(pos_weight=torch.tensor([h['obj_pw']], device=device))
#
#         # Class label smoothing https://arxiv.org/pdf/1902.04103.pdf eqn 3
#         self.cp, self.cn = smooth_BCE(eps=h.get('label_smoothing', 0.0))  # positive, negative BCE targets
#
#         # Focal loss
#         g = h['fl_gamma']  # focal loss gamma
#         if g > 0:
#             BCEcls, BCEobj = FocalLoss(BCEcls, g), FocalLoss(BCEobj, g)
#
#         det = de_parallel(model).model[-1]  # Detect() module
#         self.balance = {3: [4.0, 1.0, 0.4]}.get(det.nl, [4.0, 1.0, 0.25, 0.06, 0.02])  # P3-P7
#         self.ssi = list(det.stride).index(16) if autobalance else 0  # stride 16 index
#         self.BCEcls, self.BCEobj, self.gr, self.hyp, self.autobalance = BCEcls, BCEobj, 1.0, h, autobalance
#         for k in 'na', 'nc', 'nl', 'anchors':
#             setattr(self, k, getattr(det, k))
#
#     def __call__(self, p, targets, category_iou=None):  # predictions, targets, model
#         device = targets.device
#         lcls, lbox, lobj = torch.zeros(1, device=device), torch.zeros(1, device=device), torch.zeros(1, device=device)
#         tcls, tbox, indices, anchors = self.build_targets(p, targets)  # targets
#
#         # Losses
#         for i, pi in enumerate(p):  # layer index, layer predictions
#             b, a, gj, gi = indices[i]  # image, anchor, gridy, gridx
#             tobj = torch.zeros_like(pi[..., 0], device=device)  # target obj
#
#             n = b.shape[0]  # number of targets
#             if n:
#                 ps = pi[b, a, gj, gi]  # prediction subset corresponding to targets
#
#                 # Regression
#                 pxy = ps[:, :2].sigmoid() * 2 - 0.5
#                 pwh = (ps[:, 2:4].sigmoid() * 2) ** 2 * anchors[i]
#                 pbox = torch.cat((pxy, pwh), 1)  # predicted box
#                 if category_iou == 'wise_iou':
#                     loss, iou = bbox_iou(pbox.T, tbox[i], x1y1x2y2=False, WIoU=True)  # iou(prediction, target)
#                     lbox += loss.mean()  # iou loss
#                 else:
#                     iou = bbox_iou(pbox.T, tbox[i], x1y1x2y2=False, CIoU=True)  # iou(prediction, target)
#                     lbox += (1.0 - iou).mean()  # iou loss
#
#                 # Objectness
#                 score_iou = iou.detach().clamp(0).type(tobj.dtype)
#                 if self.sort_obj_iou:
#                     sort_id = torch.argsort(score_iou)
#                     b, a, gj, gi, score_iou = b[sort_id], a[sort_id], gj[sort_id], gi[sort_id], score_iou[sort_id]
#                 tobj[b, a, gj, gi] = (1.0 - self.gr) + self.gr * score_iou  # iou ratio
#
#                 # Classification
#                 if self.nc > 1:  # cls loss (only if multiple classes)
#                     t = torch.full_like(ps[:, 5:], self.cn, device=device)  # targets
#                     t[range(n), tcls[i]] = self.cp
#                     lcls += self.BCEcls(ps[:, 5:], t)  # BCE
#
#                 # Append targets to text file
#                 # with open('targets.txt', 'a') as file:
#                 #     [file.write('%11.5g ' * 4 % tuple(x) + '\n') for x in torch.cat((txy[i], twh[i]), 1)]
#
#             obji = self.BCEobj(pi[..., 4], tobj)
#             lobj += obji * self.balance[i]  # obj loss
#             if self.autobalance:
#                 self.balance[i] = self.balance[i] * 0.9999 + 0.0001 / obji.detach().item()
#
#         if self.autobalance:
#             self.balance = [x / self.balance[self.ssi] for x in self.balance]
#         lbox *= self.hyp['box']
#         lobj *= self.hyp['obj']
#         lcls *= self.hyp['cls']
#         bs = tobj.shape[0]  # batch size
#
#         return (lbox + lobj + lcls) * bs, torch.cat((lbox, lobj, lcls)).detach()
#
#     def build_targets(self, p, targets):
#         # Build targets for compute_loss(), input targets(image,class,x,y,w,h)
#         na, nt = self.na, targets.shape[0]  # number of anchors, targets
#         tcls, tbox, indices, anch = [], [], [], []
#         gain = torch.ones(7, device=targets.device)  # normalized to gridspace gain
#         ai = torch.arange(na, device=targets.device).float().view(na, 1).repeat(1, nt)  # same as .repeat_interleave(nt)
#         targets = torch.cat((targets.repeat(na, 1, 1), ai[:, :, None]), 2)  # append anchor indices
#
#         g = 0.5  # bias
#         off = torch.tensor([[0, 0],
#                             [1, 0], [0, 1], [-1, 0], [0, -1],  # j,k,l,m
#                             # [1, 1], [1, -1], [-1, 1], [-1, -1],  # jk,jm,lk,lm
#                             ], device=targets.device).float() * g  # offsets
#
#         for i in range(self.nl):
#             anchors = self.anchors[i]
#             gain[2:6] = torch.tensor(p[i].shape)[[3, 2, 3, 2]]  # xyxy gain
#
#             # Match targets to anchors
#             t = targets * gain
#             if nt:
#                 # Matches
#                 r = t[:, :, 4:6] / anchors[:, None]  # wh ratio
#                 j = torch.max(r, 1 / r).max(2)[0] < self.hyp['anchor_t']  # compare
#                 # j = wh_iou(anchors, t[:, 4:6]) > model.hyp['iou_t']  # iou(3,n)=wh_iou(anchors(3,2), gwh(n,2))
#                 t = t[j]  # filter
#
#                 # Offsets
#                 gxy = t[:, 2:4]  # grid xy
#                 gxi = gain[[2, 3]] - gxy  # inverse
#                 j, k = ((gxy % 1 < g) & (gxy > 1)).T
#                 l, m = ((gxi % 1 < g) & (gxi > 1)).T
#                 j = torch.stack((torch.ones_like(j), j, k, l, m))
#                 t = t.repeat((5, 1, 1))[j]
#                 offsets = (torch.zeros_like(gxy)[None] + off[:, None])[j]
#             else:
#                 t = targets[0]
#                 offsets = 0
#
#             # Define
#             b, c = t[:, :2].long().T  # image, class
#             gxy = t[:, 2:4]  # grid xy
#             gwh = t[:, 4:6]  # grid wh
#             gij = (gxy - offsets).long()
#             gi, gj = gij.T  # grid xy indices
#
#             # Append
#             a = t[:, 6].long()  # anchor indices
#             indices.append((b, a, gj.clamp_(0, gain[3] - 1), gi.clamp_(0, gain[2] - 1)))  # image, anchor, grid indices
#             tbox.append(torch.cat((gxy - gij, gwh), 1))  # box
#             anch.append(anchors[a])  # anchors
#             tcls.append(c)  # class
#
#         return tcls, tbox, indices, anch