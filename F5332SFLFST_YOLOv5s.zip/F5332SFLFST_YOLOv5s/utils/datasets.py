# YOLOv5 🚀 by Ultralytics, GPL-3.0 license
"""
Dataloaders and dataset utils
"""

import glob
import hashlib
import json
import math
import os
import random
import shutil
import time
from itertools import repeat
from multiprocessing.pool import Pool, ThreadPool
from pathlib import Path
from threading import Thread
from zipfile import ZipFile

import cv2
import numpy as np
import torch
import torch.nn.functional as F
import yaml
from PIL import ExifTags, Image, ImageOps
from torch.utils.data import DataLoader, Dataset, dataloader, distributed
from tqdm import tqdm

#from acelightenhance import getPara, zmIceFast, zmIce, stretchImage, zmIceColor
from utils.augmentations import Albumentations, augment_hsv, copy_paste, letterbox, mixup, random_perspective
from utils.general import (DATASETS_DIR, LOGGER, NUM_THREADS, check_dataset, check_requirements, check_yaml, clean_str,
                           segments2boxes, xyn2xy, xywh2xyxy, xywhn2xyxy, xyxy2xywhn)
from utils.torch_utils import torch_distributed_zero_first

# Parameters
HELP_URL = 'https://github.com/ultralytics/yolov5/wiki/Train-Custom-Data'
# 支持的图像格式
IMG_FORMATS = ['bmp', 'dng', 'jpeg', 'jpg', 'mpo', 'png', 'tif', 'tiff', 'webp']  # include image suffixes
# 支持的视频格式
VID_FORMATS = ['asf', 'avi', 'gif', 'm4v', 'mkv', 'mov', 'mp4', 'mpeg', 'mpg', 'wmv']  # include video suffixes

# Get orientation exif tag
'''
可交换图像文件格式（Exchangeable image file format，简称Exif），
是专门为数码相机的照片设定的，可以记录数码照片的属性信息和拍摄数据。
'''
#orientation表示根据方向可以横拍，可以树立拍
for orientation in ExifTags.TAGS.keys():
    if ExifTags.TAGS[orientation] == 'Orientation':
        break

# 返回文件列表的hash值
def get_hash(paths):
    # Returns a single hash value of a list of paths (files or dirs)
    #获得每个文件的哈希值做相加运算，作为多个列表哈希值
    size = sum(os.path.getsize(p) for p in paths if os.path.exists(p))  # sizes
    h = hashlib.md5(str(size).encode())  # hash sizes
    h.update(''.join(paths).encode())  # hash paths
    return h.hexdigest()  # return hash

# 获取图片的宽、高信息
def exif_size(img):
    # Returns exif-corrected PIL size
    s = img.size  # (width, height)
    try:
        rotation = dict(img._getexif().items())[orientation]# 调整数码相机照片方向
        if rotation == 6:  # rotation 270
            s = (s[1], s[0])
        elif rotation == 8:  # rotation 90
            s = (s[1], s[0])
    except Exception:
        pass

    return s


def exif_transpose(image):
    """
    Transpose a PIL image accordingly if it has an EXIF Orientation tag.
    Inplace version of https://github.com/python-pillow/Pillow/blob/master/src/PIL/ImageOps.py exif_transpose()

    :param image: The image to transpose.
    :return: An image.
    """
    exif = image.getexif()
    orientation = exif.get(0x0112, 1)  # default 1
    if orientation > 1:
        method = {2: Image.FLIP_LEFT_RIGHT,
                  3: Image.ROTATE_180,
                  4: Image.FLIP_TOP_BOTTOM,
                  5: Image.TRANSPOSE,
                  6: Image.ROTATE_270,
                  7: Image.TRANSVERSE,
                  8: Image.ROTATE_90,
                  }.get(orientation)
        if method is not None:
            image = image.transpose(method)
            del exif[0x0112]
            image.info["exif"] = exif.tobytes()
    return image

#利用自定义的数据集(LoadImagesAndLabels)创建dataloader
def create_dataloader(path, imgsz, batch_size, stride, single_cls=False, hyp=None, augment=False, cache=False, pad=0.0,
                      rect=False, rank=-1, workers=8, image_weights=False, quad=False, prefix='', shuffle=False):
    """
        参数解析：
        path：包含图片路径的txt文件或者包含图片的文件夹路径
        imgsz：网络输入图片大小
        batch_size: 批次大小
        stride：网络下采样步幅
        opt：调用train.py时传入的参数，这里主要用到opt.single_cls，是否是单类数据集
        hyp：网络训练时的一些超参数，包括学习率等，这里主要用到里面一些关于数据增强(旋转、平移等)的系数
        augment：是否进行数据增强(Mosaic以外)
        cache：是否提前缓存图片到内存，以便加快训练速度
        pad：设置矩形训练的shape时进行的填充
        rect：是否进行ar排序矩形训练（为True不做Mosaic数据增强）
        """
    #即在DDP进程的第一个线程实例化数据集，后面的话可以用缓存就行
    #有多个gpu训练的话，可以用这个DDP模式
    # Make sure only the first process in DDP(DistributedDataParallel) process the dataset first,
    # and the following others can use the cache.
    # # 如果采用矩形训练 那就不能打乱
    if rect and shuffle:
        LOGGER.warning('WARNING: --rect is incompatible with DataLoader shuffle, setting shuffle=False')
        shuffle = False
    #因为视频中只使用一个GPU,所以rank为-1
    with torch_distributed_zero_first(rank):  # init dataset *.cache only once if DDP
        #使用自定义数据集，相关参数传进去，返回一个实例化数据集对象dataset
        dataset = LoadImagesAndLabels(path, imgsz, batch_size,
                                      augment=augment,  # augmentation
                                      hyp=hyp,  # hyperparameters
                                      rect=rect,  # rectangular batches
                                      cache_images=cache,
                                      single_cls=single_cls,
                                      stride=int(stride),
                                      pad=pad,
                                      image_weights=image_weights,
                                      prefix=prefix)

    batch_size = min(batch_size, len(dataset))
    nd = torch.cuda.device_count()  # number of CUDA devices
    #多线程数目，下面三者比较的最小值，为8
    nw = min([os.cpu_count() // max(nd, 1), batch_size if batch_size > 1 else 0, workers])  # number of workers
    # 给每个rank对应的进程分配训练的样本索引
    #如果rank == -1，即只有一个gpu的话，则sampler=none;否则使用distributed.DistributedSampler采样datasets
    #数据被平分到几个gpu上，每个epoch被分配到每块gpu上的数据都一样。
    sampler = None if rank == -1 else distributed.DistributedSampler(dataset, shuffle=shuffle)
    # 实例化InfiniteDataLoader
    #因为默认传入image_weights为false,所以loader为InfiniteDataLoader类的实例化对象
    #把dataset数据集传进来，然后通过InfiniteDataLoader这个类实例化loader对象
    loader = DataLoader if image_weights else InfiniteDataLoader  # only DataLoader allows for attribute updates
    return loader(dataset,
                  batch_size=batch_size,
                  shuffle=shuffle and sampler is None,
                  num_workers=nw,
                  sampler=sampler,#if rank == -1 即使用一块gpu
                  pin_memory=True,#置pin_memory=True，则意味着生成的Tensor数据最开始是属于内存中的锁页内存，这样将内存的Tensor转义到GPU的
                  # 显存就会更快一些。
                  #pytorch的dataloader打包一个batch数据集时进过此函数打包，通过重写此函数实现标签与图片对应的划分
                  #一个batch中哪些标签属于第一张图片，属于第二张图片
                  collate_fn=LoadImagesAndLabels.collate_fn4 if quad else LoadImagesAndLabels.collate_fn), dataset


#因为dataloader在每一个epoch启动会花费一定时间，所以只在第一个epoch通过InfiniteDataLoader类初始化
#一次就可以了
class InfiniteDataLoader(dataloader.DataLoader):
    """ Dataloader that reuses workers

    Uses same syntax as vanilla DataLoader
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        object.__setattr__(self, 'batch_sampler', _RepeatSampler(self.batch_sampler))
        self.iterator = super().__iter__()

    def __len__(self):
        return len(self.batch_sampler.sampler)

    def __iter__(self):
        for i in range(len(self)):
            yield next(self.iterator)

# 定义生成器 _RepeatSampler，无穷次重复
class _RepeatSampler:
    """ Sampler that repeats forever

    Args:
        sampler (Sampler)
    """

    def __init__(self, sampler):
        self.sampler = sampler
    #因为while True:总是为真，所以会不断地调用iter返回采样到的样本
    def __iter__(self):
        while True:
            #yield函数在下一次迭代时，从上一次迭代遇到的yield后面的代码(下一行)开始执行
            #yield：即是一个生成器
            yield from iter(self.sampler)

# 定义迭代器 LoadImages；用于detect.py
class LoadImages:
    # YOLOv5 image/video dataloader, i.e. `python detect.py --source image.jpg/vid.mp4`
    def __init__(self, path, img_size=640, stride=32, auto=True):
        #实例化Path类的对象并将其转换为字符串
        #.resolve()该方法将一些的 路径/路径段 解析为绝对路径。
        p = str(Path(path).resolve())  # os-agnostic absolute path
        #glob用它可以查找符合特定规则的文件路径名。查找文件只用到三个匹配符：”*”, “?”, “[]”；
        # ”*”匹配0个或多个字符；”?”匹配单个字符；”[]”匹配指定范围内的字符，如：[0-9]匹配数字；
        # glob.glob返回所有匹配的文件路径列表。它只有一个参数pathname，定义了文件路径匹配规则，这里可以是绝对路径，也可以是相对路径
        # # 如果采用正则化表达式提取图片/视频，可使用glob获取文件路径
        if '*' in p:
            files = sorted(glob.glob(p, recursive=True))  # glob
        elif os.path.isdir(p):# 如果path是一个文件夹，使用glob获取全部文件路径
            #提取图片后还做了排序
            files = sorted(glob.glob(os.path.join(p, '*.*')))  # dir
        elif os.path.isfile(p): # 如果是文件则直接获取
            files = [p]  # files
        else:
            raise Exception(f'ERROR: {p} does not exist')

        # os.path.splitext分离文件名和后缀(后缀包含.)
        # 分别提取图片和视频文件路径   IMG_FORMATS：判断图片类型是否为支持的类型
        images = [x for x in files if x.split('.')[-1].lower() in IMG_FORMATS]
        videos = [x for x in files if x.split('.')[-1].lower() in VID_FORMATS]
        ni, nv = len(images), len(videos)

        self.img_size = img_size# 输入图片size
        self.stride = stride
        self.files = images + videos# 整合图片和视频路径到一个列表
        self.nf = ni + nv  # number of files总的文件数量
        # 设置判断是否为视频的bool变量，方便后面单独对视频进行处理
        self.video_flag = [False] * ni + [True] * nv
        # 初始化模块信息，代码中对于mode=images与mode=video有不同处理
        self.mode = 'image'
        self.auto = auto
        # 如果包含视频文件，则初始化opencv中的视频模块，cap=cv2.VideoCapture等
        if any(videos):
            self.new_video(videos[0])  # new video
        else:
            ##都是图片的话就不需要self.cap
            self.cap = None
        # nf如果小于0，则打印提示信息
        assert self.nf > 0, f'No images or videos found in {p}. ' \
                            f'Supported formats are:\nimages: {IMG_FORMATS}\nvideos: {VID_FORMATS}'
    #因为是迭代器，所以会定义下面两个方法
    def __iter__(self):
        self.count = 0
        return self

    def __next__(self):
        #count:0  nf:2,所以不执行
        if self.count == self.nf:
            raise StopIteration
        #获取文件路径（首先为第一个）
        path = self.files[self.count]

        if self.video_flag[self.count]:# 如果该文件为视频
            # Read video
            self.mode = 'video'# 修改mode为video
            # 获取当前帧画面，ret_val为一个bool变量，直到视频读取完毕之前都为True
            #调用的是opencv中的函数读取的
            ret_val, img0 = self.cap.read()
            while not ret_val:
                self.count += 1
                self.cap.release()
                if self.count == self.nf:  # last video
                    raise StopIteration
                else:
                    path = self.files[self.count]
                    self.new_video(path)
                    ret_val, img0 = self.cap.read()

            self.frame += 1
            s = f'video {self.count + 1}/{self.nf} ({self.frame}/{self.frames}) {path}: '

        #如果是图片的话
        else:
            # Read image
            self.count += 1
            #读到对这样图片的bgr格式
            img0 = cv2.imread(path)  # 因为opencv读取的numpy格式的，所以是BGR
            assert img0 is not None, f'Image Not Found {path}'
            s = f'image {self.count}/{self.nf} {path}: '

        # Padded resize
        # 对图片进行resize+pad（缩放填充）
        img = letterbox(img0, self.img_size, stride=self.stride, auto=self.auto)[0]

        # Convert
        # opencv读入的图像BGR->RGB操作; BGR转为RGB格式，并且把channel轴换到前面
        # img[：，：，：：-1]的作用就是实现RGB到BGR通道的转换；对于列表img进行img[:,:,::-1]的作用是列表数组左右翻转
        # torch.Tensor 高维矩阵的表示： （nSample）x C x H x W
        # numpy.ndarray 高维矩阵的表示： H x W x C
        # 把channel轴换到前面使用transpose() 方法 。
        img = img.transpose((2, 0, 1))[::-1]  # HWC to CHW, BGR to RGB
        ## 将数组转为内存连续，提高运行速度
        img = np.ascontiguousarray(img)

        # 返回：路径，resize+pad的图片，原始图片，视频对象
        return path, img, img0, self.cap, s

    def new_video(self, path):
        self.frame = 0# frame用来记录帧数
        self.cap = cv2.VideoCapture(path)# 初始化视频对象
        self.frames = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT))# 视频文件中的总帧数

    def __len__(self):
        return self.nf  # number of files

# 定义迭代器 LoadWebcam； 未使用
class LoadWebcam:  # for inference
    # YOLOv5 local webcam dataloader, i.e. `python detect.py --source 0`
    def __init__(self, pipe='0', img_size=640, stride=32):
        self.img_size = img_size
        self.stride = stride
        self.pipe = eval(pipe) if pipe.isnumeric() else pipe
        self.cap = cv2.VideoCapture(self.pipe)  # video capture object
        self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 3)  # set buffer size

    def __iter__(self):
        self.count = -1
        return self

    def __next__(self):
        self.count += 1
        if cv2.waitKey(1) == ord('q'):  # q to quit
            self.cap.release()
            cv2.destroyAllWindows()
            raise StopIteration

        # Read frame
        ret_val, img0 = self.cap.read()
        img0 = cv2.flip(img0, 1)  # flip left-right

        # Print
        assert ret_val, f'Camera Error {self.pipe}'
        img_path = 'webcam.jpg'
        s = f'webcam {self.count}: '

        # Padded resize
        img = letterbox(img0, self.img_size, stride=self.stride)[0]

        # Convert
        img = img.transpose((2, 0, 1))[::-1]  # HWC to CHW, BGR to RGB
        img = np.ascontiguousarray(img)

        return img_path, img, img0, None, s

    def __len__(self):
        return 0

#这里v5用到了
# 定义迭代器 LoadStreams;用于detect.py
"""
cv2视频读取函数：
cap.grap() 从设备或视频获取下一帧，获取成功返回true否则false
cap.retrieve(frame) 在grab后使用，对获取到的帧进行解码，也返回true或false
cap.read(frame) 结合grab和retrieve的功能，抓取下一帧并解码
"""
#处理多个 IP或者RTSP摄像头读取的数据
class LoadStreams:
    # YOLOv5 streamloader, i.e. `python detect.py --source 'rtsp://example.com/media.mp4'  # RTSP, RTMP, HTTP streams`
    def __init__(self, sources='streams.txt', img_size=640, stride=32, auto=True):
        self.mode = 'stream' # 初始化mode为images
        #获取传入的img_size大小
        self.img_size = img_size
        self.stride = stride

        # 如果sources为一个保存了多个视频流的文件
        # 获取每一个视频流，保存为一个列表
        if os.path.isfile(sources):
            #读文件
            with open(sources) as f:
                #读取文件中的每一行
                sources = [x.strip() for x in f.read().strip().splitlines() if len(x.strip())]
        else:
            #把sources构造成一个列表
            sources = [sources]

        n = len(sources)
        self.imgs, self.fps, self.frames, self.threads = [None] * n, [0] * n, [0] * n, [None] * n
        self.sources = [clean_str(x) for x in sources]  # clean source names for later
        self.auto = auto
        for i, s in enumerate(sources):  # index, source
            # Start thread to read frames from video stream
            st = f'{i + 1}/{n}: {s}... '
            if 'youtube.com/' in s or 'youtu.be/' in s:  # if source is YouTube video
                check_requirements(('pafy', 'youtube_dl==2020.12.2'))
                import pafy
                s = pafy.new(s).getbest(preftype="mp4").url  # YouTube URL
            #如果source=0则打开摄像头，否则打开视频流地址
            s = eval(s) if s.isnumeric() else s  # i.e. s = '0' local webcam
            cap = cv2.VideoCapture(s)
            assert cap.isOpened(), f'{st}Failed to open {s}'
            w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))# 获取视频的宽度信息
            h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))# 获取视频的高度信息
            fps = cap.get(cv2.CAP_PROP_FPS)  # warning: may return 0 or nan# 获取视频的帧率
            self.frames[i] = max(int(cap.get(cv2.CAP_PROP_FRAME_COUNT)), 0) or float('inf')  # infinite stream fallback
            self.fps[i] = max((fps if math.isfinite(fps) else 0) % 100, 0) or 30  # 30 FPS fallback

            _, self.imgs[i] = cap.read()  # guarantee first frame
            # 创建多线程读取视频流，daemon=True表示主线程结束时子线程也结束
            self.threads[i] = Thread(target=self.update, args=([i, cap, s]), daemon=True)
            LOGGER.info(f"{st} Success ({self.frames[i]} frames {w}x{h} at {self.fps[i]:.2f} FPS)")
            #启动多线程
            self.threads[i].start()
        LOGGER.info('')  # newline

        # check for common shapes
        # 获取进行resize+pad之后的shape，letterbox函数默认(参数auto=True)是按照矩形推理形状进行填充
        # check for common shapes
        # inference shapes
        s = np.stack([letterbox(x, self.img_size, stride=self.stride, auto=self.auto)[0].shape for x in self.imgs])
        self.rect = np.unique(s, axis=0).shape[0] == 1  # rect inference if all shapes equal
        if not self.rect:
            LOGGER.warning('WARNING: Stream shapes differ. For optimal performance supply similarly-shaped streams.')

    #读取下一个stream
    def update(self, i, cap, stream):
        # Read stream `i` frames in daemon thread
        n, f, read = 0, self.frames[i], 1  # frame number, frame array, inference every 'read' frame
        while cap.isOpened() and n < f:
            n += 1
            # _, self.imgs[index] = cap.read()
            #获取一帧
            cap.grab()
            if n % read == 0:
                #整除read的时候读取一次
                success, im = cap.retrieve()
                if success:
                    self.imgs[i] = im
                else:
                    LOGGER.warning('WARNING: Video stream unresponsive, please check your IP camera connection.')
                    self.imgs[i] = np.zeros_like(self.imgs[i])
                    cap.open(stream)  # re-open stream if signal was lost
            time.sleep(1 / self.fps[i])  # wait time

    def __iter__(self):
        self.count = -1
        return self

    #获取下一帧图片
    def __next__(self):
        self.count += 1
        #如果按q键即为退出
        if not all(x.is_alive() for x in self.threads) or cv2.waitKey(1) == ord('q'):  # q to quit
            cv2.destroyAllWindows()
            raise StopIteration

        # Letterbox
        # 对图片进行resize+pad（缩放填充）
        img0 = self.imgs.copy()
        img = [letterbox(x, self.img_size, stride=self.stride, auto=self.rect and self.auto)[0] for x in img0]

        # Stack
        img = np.stack(img, 0)# 将读取的图片拼接到一起

        # Convert
        img = img[..., ::-1].transpose((0, 3, 1, 2))  # BGR to RGB, BHWC to BCHW
        ## 将数组转为内存连续，提高运行速度
        img = np.ascontiguousarray(img)

        return self.sources, img, img0, None, ''

    def __len__(self):
        return len(self.sources)  # 1E12 frames = 32 streams at 30 FPS for 30 years

#img_path表示传过来的图片路径的字符串
def img2label_paths(img_paths):
    # Define label paths as a function of image paths
    sa, sb = os.sep + 'images' + os.sep, os.sep + 'labels' + os.sep  # /images/, /labels/ substrings
    return [sb.join(x.rsplit(sa, 1)).rsplit('.', 1)[0] + '.txt' for x in img_paths]

# 自定义的数据集
# 定义LoadImagesAndLabels类， 继承Dataset, 重写抽象方法：__len()__, __getitem()__
class LoadImagesAndLabels(Dataset):
    # YOLOv5 train_loader/val_loader, loads images and labels for training and validation
    cache_version = 0.6  # dataset labels *.cache version

    #1、获取参数
    def __init__(self, path, img_size=640, batch_size=16, augment=False, hyp=None, rect=False, image_weights=False,
                 cache_images=False, single_cls=False, stride=32, pad=0.0, prefix=''):
        self.img_size = img_size# 输入图片分辨率大小
        self.augment = augment# 数据增强,这里为true
        #超参的yaml文件读取出来，构造成一个字典赋给这个类的变量hyp
        self.hyp = hyp# 超参数
        self.image_weights = image_weights#图片采样权重,若为true,则图片采样时，有的类别可以多一点，有的可以少一点
        self.rect = False if image_weights else rect# 矩形训练，这里为false
        # mosaic数据增强,这里为true
        self.mosaic = self.augment and not self.rect  # load 4 images at a time into a mosaic (only during training)
        # mosaic增强的边界值,得到-320，-320的一个列表
        self.mosaic_border = [-img_size // 2, -img_size // 2]
        self.stride = stride# 模型下采样的步长，这里为32，即v5做了32倍下采样
        self.path = path
        self.albumentations = Albumentations() if augment else None

        #获取图片路径，与标注路径
        #判断路径是文件夹还是文件：
        #1）若为文件夹，采用glob.glob获取文件夹下及其子文件夹下所有图片的路径2）若为文件，直接读取文件内的信息
        try:
            f = []  # image files
            #调试可以发现传入的path是/home/lhcz/sdb/jiabin/jb_project/datasets/VOC/images/
            #的训练集与验证集，遍历的是这个路径下的文件
            for p in path if isinstance(path, list) else [path]:
                # 获取数据集路径path，包含图片路径的txt文件或者包含图片的文件夹路径
                # 使用pathlib.Path生成与操作系统无关的路径，因为不同操作系统路径的‘/’会有所不同
                p = Path(p)  # os-agnostic，字符串的路径转换为poxis路径
                #如果p是目录，或者文件夹
                if p.is_dir():  # dir，如果是文件夹，则将文件夹中的，以及其子文件夹中的文件路径保存到一个列表中
                    #f就得到指定路径文件夹中的所有图片，recursive=True是是否采取递归的方式
                    # glob.iglob() 函数获取一个可遍历对象，使用它可以逐个获取匹配的文件路径名。
                    # 与glob.glob()的区别是：glob.glob()可同时获取所有的匹配路径，而glob.iglob()一次只能获取一个匹配路径。
                    f += glob.glob(str(p / '**' / '*.*'), recursive=True)
                    # f = list(p.rglob('*.*'))  # pathlib
                #如果是文件，则将文件中的所有路径都读到列表中
                elif p.is_file():  # file 如果路径path为包含图片路径的txt文件
                    with open(p) as t:
                        t = t.read().strip().splitlines()# 获取图片路径，更换相对路径
                        # 获取数据集路径的上级父目录，os.sep为路径里的分隔符(不同系统路径分隔符不同，os.sep根据系统自适应)、
                        #这里parent就是/home/lhcz/sdb/jiabin/jb_project/datasets/VOC/images/
                        # 系统路径中的分隔符：Windows系统通过是“\\”，Linux类系统如Ubuntu的分隔符是“/”，而苹果Mac OS系统中是“:”。
                        # os.sep即是/，p.parent是p的父目录，str(p.parent)将其转换为字符串形式
                        parent = str(p.parent) + os.sep
                        f += [x.replace('./', parent) if x.startswith('./') else x for x in t]  # local to global path
                        # f += [p.parent / x.lstrip(os.sep) for x in t]  # local to global path (pathlib)
                else:
                    raise Exception(f'{prefix}{p} does not exist')
            # 分隔符替换为os.sep，x.split('.')将文件名与扩展名分开并返回一个列表
            # #查看所有路径是不是目标格式，如果是则保存，并对其排序
            #replace('/', os.sep) 表示把'/'换成os.sep,即'\\'
            self.img_files = sorted(x.replace('/', os.sep) for x in f if x.split('.')[-1].lower() in IMG_FORMATS)
            # self.img_files = sorted([x for x in f if x.suffix[1:].lower() in IMG_FORMATS])  # pathlib
            assert self.img_files, f'{prefix}No images found'
        except Exception as e:
            raise Exception(f'{prefix}Error loading data from {path}: {e}\nSee {HELP_URL}')

        # Check cache
        #注意这里默认图片文件夹与标签文件夹在同一路径下，即 train/images   train/labels，其中images中储存所有图片，labels中存储所有标注信息
        #images换成labels,.jpg换成.txt
        self.label_files = img2label_paths(self.img_files)  # labels #将图片路径转换为标签路径
        #得到一个缓存路径，比如/home/lhcz/sdb/jiabin/jb_project/datasets/VOC/labels/train2007.cache
        #其实执行完train，这个文件就存在了，其实就是标签文件的缓存文件，就是把标签文件加载到内存中，当
        #训练时不需要读每一个的txt文件了，这样会加快处理速度
        #self.label_files[0]).parent就得到标签文件的父路径，如/labels/train2007.cache    with_suffix('.cache')表示以.cache结尾
        cache_path = (p if p.is_file() else Path(self.label_files[0]).parent).with_suffix('.cache')
        try:
            #尝试load这个cache_path，看看之前是否有保存
            cache, exists = np.load(cache_path, allow_pickle=True).item(), True  # load dict
            #因为保存cache是保存有version和hash看看二者是否能对应上，如果不能对应上就会执行except Exception:
            #重新load
            assert cache['version'] == self.cache_version  # same version
            assert cache['hash'] == get_hash(self.label_files + self.img_files)  # same hash 判断hash值是否改变
        except Exception:
            #如果之前没有保存就会重新load读所有的文件，并把它保存起来
            #感觉这里另一种想法是，同3.0一样，如果数据集改变了的情况，labels的version或者hash值也会改变
            # 即try中那两个语句也不会匹配，则也会进入这里执行下面语句重新生成cache文件
            #（总结：如果之前没有保存cache或者数据集发生改变导致hash不匹配，都会执行下面操作）
            cache, exists = self.cache_labels(cache_path, prefix), False  # cache

        # Display cache
        #因为cache是一个dict,把result拿出来，就知道cache里面的具体情况
        nf, nm, ne, nc, n = cache.pop('results')  # found, missing, empty, corrupt, total
        #如果cache存在，就把具体情况打印
        if exists:
            d = f"Scanning '{cache_path}' images and labels... {nf} found, {nm} missing, {ne} empty, {nc} corrupt"
            tqdm(None, desc=prefix + d, total=n, initial=n)  # display cache results
            if cache['msgs']:
                LOGGER.info('\n'.join(cache['msgs']))  # display warnings
        assert nf > 0 or not augment, f'{prefix}No labels in {cache_path}. Can not train without labels. See {HELP_URL}'

        # Read cache
        #把'hash', 'version', 'msgs'pop出去
        [cache.pop(k) for k in ('hash', 'version', 'msgs')]  # remove items
        #labels记录了voc中16551训练标签，还有每个标签对应图片的bounding box数量
        #shape为每个图片大小
        #segments为空，因为数据中没有这个
        labels, shapes, self.segments = zip(*cache.values())
        #表示把label从tuple变成list类型
        self.labels = list(labels)
        #shape变成array类型
        self.shapes = np.array(shapes, dtype=np.float64)
        self.img_files = list(cache.keys())  # update
        self.label_files = img2label_paths(cache.keys())  # update
        n = len(shapes)  # number of images
        #np.floor返回不大于输入参数的最大整数
        #batchindex,其实算哪些图片属于同一个batch
        bi = np.floor(np.arange(n) / batch_size).astype(np.int)  # batch index
        #batch数量：batch索引+1，因为从0开始
        nb = bi[-1] + 1  # number of batches
        self.batch = bi  # batch index of image
        self.n = n #图片数量？
        #下标
        self.indices = range(n)

        # Update labels（比3.0多的）
        #过滤label，使得仅包含这些label
        include_class = []  # filter labels to include only these classes (optional)
        include_class_array = np.array(include_class).reshape(1, -1)
        #zip()是Python的一个内建函数，它接受一系列可迭代的对象作为参数，将对象中对应的元素打包成一个个tuple(元组)，然后返回由这些tuples组成的list(列表)。
        #有了zip,迭代出来的东西的第一项i为第一项的索引，第二项(label, segment) 为索引下的内容
        for i, (label, segment) in enumerate(zip(self.labels, self.segments)):
            #如果include_class不为空
            if include_class:
                #就把这些想要的labels取出来，放到label里边
                j = (label[:, 0:1] == include_class_array).any(1)
                #赋值给第i个albel
                self.labels[i] = label[j]
                if segment:
                    self.segments[i] = segment[j]
            if single_cls:  # single-class training, merge all classes into 0
                self.labels[i][:, 0] = 0
                if segment:
                    self.segments[i][:, 0] = 0

        # Rectangular Training
        #这里判断是否做ar排序矩形训练
        if self.rect:
            # Sort by aspect ratio
            s = self.shapes  # wh
            #高宽比
            ar = s[:, 1] / s[:, 0]  # aspect ratio
            #从下面这些都是小到大排序
            irect = ar.argsort()
            # 根据索引排序数据集与标签路径、shape、h/w
            self.img_files = [self.img_files[i] for i in irect]
            self.label_files = [self.label_files[i] for i in irect]
            self.labels = [self.labels[i] for i in irect]
            self.shapes = s[irect]  # wh
            ar = ar[irect]

            # Set training image shapes
            # 初始化shapes，nb为一轮批次batch的数量
            shapes = [[1, 1]] * nb
            for i in range(nb):
                #比如i=0，则把bi为0的索引，即第一个batch拿出来
                ari = ar[bi == i]
                #找此索引对应的batch中的高宽比最小的与最大的
                mini, maxi = ari.min(), ari.max()
                # 如果一个batch中最大的h/w小于1，则此batch的shape为(img_size*maxi, img_size)
                #即把所有的width规整为1，即640，
                if maxi < 1:#height<weight
                    shapes[i] = [maxi, 1]
                #如果一个batch中最小的h/w大于1，则此batch的shape为(img_size, img_size/mini)
                #即把height卡为640
                elif mini > 1:#height>weight
                    shapes[i] = [1, 1 / mini]
            #经过一些处理返回batch_shapes
            #self.batch_shapes里面存放的就是每个batch最终输入网络的图像的shape，这个shape是已经经过计算补充了无效像素的shape。
            self.batch_shapes = np.ceil(np.array(shapes) * img_size / stride + pad).astype(np.int) * stride

        #相比v3增添的内容
        # Cache images into RAM/disk for faster training (WARNING: large datasets may exceed system resources)
        self.imgs, self.img_npy = [None] * n, [None] * n
        if cache_images:#缓存图片
            if cache_images == 'disk':#将图片缓存到disk中
                #保存到disk中去
                self.im_cache_dir = Path(Path(self.img_files[0]).parent.as_posix() + '_npy')#图片缓存文件夹
                #将图片缓存成npy文件
                self.img_npy = [self.im_cache_dir / Path(f).with_suffix('.npy').name for f in self.img_files]
                self.im_cache_dir.mkdir(parents=True, exist_ok=True)#创建文件夹缓存文件
            gb = 0  # Gigabytes of cached images统计大小
            #img_hw0表示初始的height与weight；img_hw表示resize后的height与weight，都初始了n个大小
            self.img_hw0, self.img_hw = [None] * n, [None] * n
            #把self.load_image与range(n)做了一个map,
            #多进程加载图片，并将图片resize，返回resize后图片与原始图片的长宽比
            results = ThreadPool(NUM_THREADS).imap(self.load_image, range(n))
            #然后包装成一个tqdm的进度条，以进度条形式显示出来
            pbar = tqdm(enumerate(results), total=n)
            for i, x in pbar:
                if cache_images == 'disk':
                    if not self.img_npy[i].exists():#npy文件不存在，重新保存
                        np.save(self.img_npy[i].as_posix(), x[0])
                    #把numpy大小算一下，加起来
                    #当设置了本地保存时，保存为本地.npy文件
                    gb += self.img_npy[i].stat().st_size#文件大小
                else:  # 'ram'
                    #self.imgs[i]：放了所有的img;img_hw0[i]:resize前的hw;img_hw[i]:resize后的hw
                    self.imgs[i], self.img_hw0[i], self.img_hw[i] = x  # im, hw_orig, hw_resized = load_image(self, i)
                    #在ram中，则据集中所有图像读取进来，并等比缩放，保存到self.imgs里
                    gb += self.imgs[i].nbytes
                pbar.desc = f'{prefix}Caching images ({gb / 1E9:.1f}GB {cache_images})'
            pbar.close()

    def cache_labels(self, path=Path('./labels.cache'), prefix=''):
        # Cache dataset labels, check images and read shapes
        x = {}  # dict
        nm, nf, ne, nc, msgs = 0, 0, 0, 0, []  # number missing, found, empty, corrupt, messages
        desc = f"{prefix}Scanning '{path.parent / path.stem}' images and labels..."
        #pool：python中多进程的一个子模块，可提供指定数量进程给用户使用，一般用于需要执行目标很多
        #而手动限制进程数量又繁琐时，如果目标少且不用控制进程数量时，用process类
        with Pool(NUM_THREADS) as pool:
            #tqdm:进度条显示 pool.imap 输入函数、迭代器，返回iterable
            #verify_image_label：验证图片与label可读，并将label转成统一格式，供后面使用
            pbar = tqdm(pool.imap(verify_image_label, zip(self.img_files, self.label_files, repeat(prefix))),
                        desc=desc, total=len(self.img_files))
            for im_file, lb, shape, segments, nm_f, nf_f, ne_f, nc_f, msg in pbar:
                nm += nm_f
                nf += nf_f
                ne += ne_f
                nc += nc_f
                if im_file:
                    x[im_file] = [lb, shape, segments]
                if msg:
                    msgs.append(msg)
                pbar.desc = f"{desc}{nf} found, {nm} missing, {ne} empty, {nc} corrupt"

        pbar.close()
        if msgs:
            LOGGER.info('\n'.join(msgs))
        if nf == 0:
            LOGGER.warning(f'{prefix}WARNING: No labels found in {path}. See {HELP_URL}')
        x['hash'] = get_hash(self.label_files + self.img_files)
        x['results'] = nf, nm, ne, nc, len(self.img_files)
        x['msgs'] = msgs  # warnings
        x['version'] = self.cache_version  # cache version
        try:
            np.save(path, x)  # save cache for next time
            path.with_suffix('.cache.npy').rename(path)  # remove .npy suffix
            LOGGER.info(f'{prefix}New cache created: {path}')
        except Exception as e:
            LOGGER.warning(f'{prefix}WARNING: Cache directory {path.parent} is not writeable: {e}')  # not writeable
        return x

    #需要重写的抽象函数返回的是图片路径（img_files）的元素个数，
    #若对训练集来说，返回的就是训练集的图片个数
    def __len__(self):
        return len(self.img_files)

    # def __iter__(self):
    #     self.count = -1
    #     print('ran dataset iter')
    #     #self.shuffled_vector = np.random.permutation(self.nF) if self.augment else np.arange(self.nF)
    #     return self

    #index:是本次要取数据的index，它的长度是0到整个数据的长度
    def __getitem__(self, index):
        #获取新的下标
        index = self.indices[index]  # linear, shuffled, or image_weights

        #超参数赋值过来,即获取超参字典
        hyp = self.hyp
        #若mosaic为true,且所取rqandom小于mosaic这个超参时，就做mosaic
        mosaic = self.mosaic and random.random() < hyp['mosaic']
        if mosaic:
            # Load mosaic
            #即根据这张图片索引再从数据集中抽取三张图片组成四张图片，最后形成img与labels
            # 使用mosaic数据增强方式加载图片和标签
            img, labels = self.load_mosaic(index)
            shapes = None

            #还要判断要不要做MixUp数据增强
            # MixUp augmentation
            #吧一些图片进行混合，如把两张图片混合成一张图片增加任务难度
            if random.random() < hyp['mixup']:
                img, labels = mixup(img, labels, *self.load_mosaic(random.randint(0, self.n - 1)))

        else:
            #若不做mosaic，就把当前的图片load进来，后面就是做数据增广操作l
            # Load image 加载图片并根据设定的输入大小与图片原大小的比例ratio进行resize
            #返回图片，图片原始宽高以及裁剪后的宽高
            img, (h0, w0), (h, w) = self.load_image(index)

            # Letterbox
            #获取shape值，即图片大小
            shape = self.batch_shapes[self.batch[index]] if self.rect else self.img_size  # final letterboxed shape
            #返回Letterbox处理后的img, ratio, pad
            img, ratio, pad = letterbox(img, shape, auto=False, scaleup=self.augment)
            shapes = (h0, w0), ((h / h0, w / w0), pad)  # for COCO mAP rescaling

            labels = self.labels[index].copy()
            if labels.size:  # normalized xywh to pixel xyxy format
                labels[:, 1:] = xywhn2xyxy(labels[:, 1:], ratio[0] * w, ratio[1] * h, padw=pad[0], padh=pad[1])

            if self.augment:
                #需要做数据增强但没使用mosaic:则随机对图片进行旋转，平移，缩放，裁剪
                img, labels = random_perspective(img, labels,
                                                 degrees=hyp['degrees'],
                                                 translate=hyp['translate'],
                                                 scale=hyp['scale'],
                                                 shear=hyp['shear'],
                                                 perspective=hyp['perspective'])

        #若nl=2表示图片上有两个目标
        nl = len(labels)  # number of labels
        if nl: # 调整框的标签，xyxy->xywh（归一化）
            labels[:, 1:5] = xyxy2xywhn(labels[:, 1:5], w=img.shape[1], h=img.shape[0], clip=True, eps=1E-3)

        #数据增广
        if self.augment:
            # Albumentations，开源库，利用它，把img, labels得到增广后的img, labels
            img, labels = self.albumentations(img, labels)
            nl = len(labels)  # update after albumentations

            # HSV color-space，在hsv空间做一个增强
            #Hue（调整色调、色相）、Saturation（调整饱和度、色彩纯净度）和 Value（调整明度）
            augment_hsv(img, hgain=hyp['hsv_h'], sgain=hyp['hsv_s'], vgain=hyp['hsv_v'])

            # Flip up-down，翻转数据增强
            #如果产生随机数小于超参数中设置的flipud值，会调用np.flipud进行随机上下翻转
            if random.random() < hyp['flipud']:
                img = np.flipud(img)
                if nl:
                    #翻转后，labels也要进行调整
                    labels[:, 2] = 1 - labels[:, 2]

            # Flip left-right翻转数据增强
            if random.random() < hyp['fliplr']:
                img = np.fliplr(img)
                if nl:
                    labels[:, 1] = 1 - labels[:, 1]

            # Cutouts
            # labels = cutout(img, labels, p=0.5)
            # nl = len(labels)  # update after cutout

        # 初始化标签框对应的图片序号，配合下面的collate_fn使用
        #labels_out初始化为0
        labels_out = torch.zeros((nl, 6))
        if nl:
            #from_numpy()用来将数组array转换为张量Tensor
            #就是由五个值得numpy数组变成了有六个值得张量（开始多了一个0）
            #变成六个值是为了配合下面的collate_fn使用
            labels_out[:, 1:] = torch.from_numpy(labels)

        # Convert
        #需要对图片进行处理，如果使用cv2的图片,是BGR格式，但是我们希望是rgb格式
        # Convert
        #img[:,:,::-1]就是我们任意不改变width维的方式，也不改变height维的方式，仅仅改变channel维的方式，并且是倒序排列，原本的bgr排列方式经过倒序就变成了rgb的排列方式。
        # img[：，：，：：-1]的作用就是实现BGR到RGB通道的转换; 对于列表img进行img[:,:,::-1]的作用是列表数组左右翻转
        # channel轴换到前面
        # torch.Tensor 高维矩阵的表示： （nSample）x C x H x W
        # numpy.ndarray 高维矩阵的表示： H x W x C
        img = img.transpose((2, 0, 1))[::-1]  # HWC to CHW, BGR to RGB
        img = np.ascontiguousarray(img)
        #最后把训练的数据返回
        #首先把img转换成torch.tesor格式，labels_out看上面知也是tensorg格式，
        #self.img_files[index]表示img_files的名称，shape
        return torch.from_numpy(img), labels_out, self.img_files[index], shapes


    #为yolov5网络增加亮度数据增强方法
    # def gamma_trans(self,img, gamma):
    #     '''
    #     首先归一化到0-1范围，然后gamma作为指数值求出新的像素值再还原
    #     '''
    #     gamma_table = [np.power(x / 255.0, gamma) * 255.0 for x in range(256)]
    #     gamma_table = np.round(np.array(gamma_table)).astype(np.uint8)
    #
    #     return cv2.LUT(img, gamma_table)  # 作为一个查表的映射

    #ace增强
    # def stretchImage(data, s=0.005, bins=2000):  # 线性拉伸，去掉最大最小0.5%的像素值，然后线性拉伸至[0,1]
    #     ht = np.histogram(data, bins);
    #     d = np.cumsum(ht[0]) / float(data.size)
    #     lmin = 0;
    #     lmax = bins - 1
    #     while lmin < bins:
    #         if d[lmin] >= s:
    #             break
    #         lmin += 1
    #     while lmax >= 0:
    #         if d[lmax] <= 1 - s:
    #             break
    #         lmax -= 1
    #     return np.clip((data - ht[1][lmin]) / (ht[1][lmax] - ht[1][lmin]), 0, 1)
    #
    # g_para = {}
    #
    # def getPara(radius=5):  # 根据半径计算权重参数矩阵
    #     global g_para
    #     m = g_para.get(radius, None)
    #     if m is not None:
    #         return m
    #     size = radius * 2 + 1
    #     m = np.zeros((size, size))
    #     for h in range(-radius, radius + 1):
    #         for w in range(-radius, radius + 1):
    #             if h == 0 and w == 0:
    #                 continue
    #             m[radius + h, radius + w] = 1.0 / math.sqrt(h ** 2 + w ** 2)
    #     m /= m.sum()
    #     g_para[radius] = m
    #     return m
    #
    # def zmIce(I, ratio=4, radius=300):  # 常规的ACE实现
    #     para = getPara(radius)
    #     height, width = I.shape
    #     zh, zw = [0] * radius + list(range(height)) + [height - 1] * radius, [0] * radius + list(range(width)) + [
    #         width - 1] * radius
    #     Z = I[np.ix_(zh, zw)]
    #     res = np.zeros(I.shape)
    #     for h in range(radius * 2 + 1):
    #         for w in range(radius * 2 + 1):
    #             if para[h][w] == 0:
    #                 continue
    #             res += (para[h][w] * np.clip((I - Z[h:h + height, w:w + width]) * ratio, -1, 1))
    #     return res
    #
    # def zmIceFast(I, ratio, radius):  # 单通道ACE快速增强实现
    #     height, width = I.shape[:2]
    #     if min(height, width) <= 2:
    #         return np.zeros(I.shape) + 0.5
    #     Rs = cv2.resize(I, ((width + 1) // 2, (height + 1) // 2))
    #     Rf = zmIceFast(Rs, ratio, radius)  # 递归调用
    #     Rf = cv2.resize(Rf, (width, height))
    #     Rs = cv2.resize(Rs, (width, height))
    #
    #     return Rf + zmIce(I, ratio, radius) - zmIce(Rs, ratio, radius)
    #
    # def zmIceColor(I, ratio=4, radius=3):  # rgb三通道分别增强，ratio是对比度增强因子，radius是卷积模板半径
    #     res = np.zeros(I.shape)
    #     for k in range(3):
    #         res[:, :, k] = stretchImage(zmIceFast(I[:, :, k], ratio, radius))
    #     return res



    # Ancillary functions --------------------------------------------------------------------------------------------------
    # load_image加载图片并根据设定的输入大小与图片原大小的比例ratio进行resize
    def load_image(self, i):
        #从数据集加载图片并返回im\最初的宽高、裁剪后的宽高
        # loads 1 image from dataset index 'i', returns (im, original hw, resized hw)
        # 获取该索引的图片
        im = self.imgs[i]
        if im is None:  # not cached in RAM（没有在内存中缓存）判断一下图片是否有缓存，即有没有缩放处理过
            #先去对应文件夹中找
            npy = self.img_npy[i]
            #找到了我们就加载这张图片
            if npy and npy.exists():  # load npy
                im = np.load(npy)
            #否则 从文件夹中找不到找不到图片就读取原本这张图的路径
            else:  # read image
                #文件路径
                f = self.img_files[i]
                #要读入图片的完整路径
                im = cv2.imread(f)  # BGR
                # 报错找不到这张图
                assert im is not None, f'Image Not Found {f}'

            # # gamma变换数据增强
            # im = self.gamma_trans(im, random.uniform(0.5, 2.0))

            #ace数据增强
            #im = zmIceColor(cv2.imread(str(im)) / 255.0) * 255

            h0, w0 = im.shape[:2]  # orig hw
            # 读取这张图的原始高宽
            r = self.img_size / max(h0, w0)  # ratio
            # 设定resize比例
            #一般是进行向下的resize，但是做数据增强时，可以向上进行resize
            if r != 1:  # if sizes are not equal
                # 实现缩放
                im = cv2.resize(im,
                                (int(w0 * r), int(h0 * r)),
                                interpolation=cv2.INTER_LINEAR if (self.augment or r > 1) else cv2.INTER_AREA)
            #返回resize后的img和最初宽高，以及resize以后的宽高
            return im, (h0, w0), im.shape[:2]  # im, hw_original, hw_resized
        #如果有：即缩放处理过，直接返回这张图片，原始高宽和缩放后的高宽啦
        else:
            return self.imgs[i], self.img_hw0[i], self.img_hw[i]  # im, hw_original, hw_resized

    #Mosaic数据增强则采用了4张图片，随机缩放、裁剪、排布再进行拼接。
    # 生成一个mosaic增强的图片.index为要增强的图片索引
    # self是自定义数据集对象，index是要进行数据增强的索引
    def load_mosaic(self, index):
        # YOLOv5 4-mosaic loader. Loads 1 image + 3 random images into a 4-image mosaic
        labels4, segments4 = [], []
        # 从自定义数据集获取到的图片大小为640
        s = self.img_size
        # 步骤一：随机取mosaic中心点，下面*2表示宽高都要扩大一倍，然后再取它的随机抽的中心点
        yc, xc = (int(random.uniform(-x, 2 * s + x)) for x in self.mosaic_border)  # mosaic center x, y
        # 随机取其它三张图片的索引，与输入的index对应的图片进行相加
        #步骤二：选择1张主图，和训练集中随机三张图片
        indices = [index] + random.choices(self.indices, k=3)  # 3 additional image indices
        #步骤三：将indices打乱，不再区分主次图
        random.shuffle(indices)
        for i, index in enumerate(indices):
            # Load image
            # load_image加载图片并根据设定的输入大小与图片原大小的比例ratio进行resize
            #假如设定图片大小640,原始图片大小可能不是640，所以他会进行一定而resize,返回resize以后的img
            #hw是resize以后的高宽
            img, _, (h, w) = self.load_image(index)
            #步骤四：遍历这四张图，计算选取图片区域及在组合图中的坐标
            # place img in img4（把图片放在大图上）
            if i == 0:  # top left
                # 创建组合图像
                # 初始化大图，s * 2才会把图片面积扩大四倍，四个小图才能放上去
                img4 = np.full((s * 2, s * 2, img.shape[2]), 114, dtype=np.uint8)  # base image with 4 tiles
                # # 设置大图上的位置（左上角），即第一张图放在左上角，根据下面公式求出位置
                # 计算第一张图片在组合图像中的位置(右下角为组合图像中心cxcy)
                x1a, y1a, x2a, y2a = max(xc - w, 0), max(yc - h, 0), xc, yc  # xmin, ymin, xmax, ymax (large image)
                # 选取小图上的位置（其实根据调试知这就是小图的大小，即为小图左上角与右下角的位置）
                # 计算第一张图片中选取的区域(右下角还是原本右下角坐标w,h， 根据在组合图中位置计算左上角坐标)
                x1b, y1b, x2b, y2b = w - (x2a - x1a), h - (y2a - y1a), w, h  # xmin, ymin, xmax, ymax (small image)
            elif i == 1:  # top right
                # 第二张图片在右上角，同样先计算在组合图的位置，再计算取第二张图像的区域位置
                x1a, y1a, x2a, y2a = xc, max(yc - h, 0), min(xc + w, s * 2), yc
                x1b, y1b, x2b, y2b = 0, h - (y2a - y1a), min(w, x2a - x1a), h
            elif i == 2:  # bottom left
                # 第三张图片在左下角
                x1a, y1a, x2a, y2a = max(xc - w, 0), yc, xc, min(s * 2, yc + h)
                x1b, y1b, x2b, y2b = w - (x2a - x1a), 0, w, min(y2a - y1a, h)
            elif i == 3:  # bottom right
                # 第四张图片在右下角
                x1a, y1a, x2a, y2a = xc, yc, min(xc + w, s * 2), min(s * 2, yc + h)
                x1b, y1b, x2b, y2b = 0, 0, min(w, x2a - x1a), min(y2a - y1a, h)
            #将选取的图片区域放置进组合图中，即把小图上截取的部分贴到大图中去
            img4[y1a:y2a, x1a:x2a] = img[y1b:y2b, x1b:x2b]  # img4[ymin:ymax, xmin:xmax]
            #若存在小尺寸图片则填充
            # 计算小图到大图上时所产生的偏移，用来计算mosaic增强后的标签框的位置
            padw = x1a - x1b
            padh = y1a - y1b

            #总：处理目标框，计算出目标框的位置信息，然后把目标框加到labels4中
            #获取图片bboxlabel以及分割lable - segment(YOLO格式转换)
            # Labels就是目标框信息
            #调试得到而labels第一列代表物体的id，比如14就是代表人；二三四五列表示目标框的信息
            labels, segments = self.labels[index].copy(), self.segments[index].copy()
            # 重新调整标签框的位置，重新计算在大图中目标框的位置
            #由于目标框坐标信息是yolo格式的，所以需要进行转换，并且要加上偏移padw, padh
            #这样就得到新的labels信息
            #如果这张图片有bounding box，需要把坐标做一次转换
            if labels.size:
                labels[:, 1:] = xywhn2xyxy(labels[:, 1:], w, h, padw, padh)  # normalized xywh to pixel xyxy format
                segments = [xyn2xy(x, w, h, padw, padh) for x in segments]
            #把labels添加到labels4这个列表中
            labels4.append(labels)
            segments4.extend(segments)

        #连接所有bboxlabel和分割label,并将所有坐标限制在组合图像范围内(除去未显示目标的标签)
        #还要对labels进行处理，要把目标框调整到图片内部，因为目标框可能跑到图片的外边去
        #首先将列表进行拼接，发现labels4不再是一个列表，而是ndarray
        # Concat/clip labels
        # 调整标签框在图片内部
        #拼接后，相当于labels4是一张大图中所有的labels
        labels4 = np.concatenate(labels4, 0)
        for x in (labels4[:, 1:], *segments4):
            #吧label做clip时候，不要超过0到2s之间
            np.clip(x, 0, 2 * s, out=x)  # clip when using random_perspective()
        # img4, labels4 = replicate(img4, labels4)  # replicate

        # 进行mosaic的时候将四张图片整合到一起之后shape为[2*img_size, 2*img_size]
        # 对mosaic整合的图片进行随机旋转、平移、缩放、裁剪，并resize为输入大小img_size,即debug刚开始的640
        # Augment
        #主要哦意思就是把一些labelscopy一份到图像的其他位置上去。这里因为hyp['copy_paste']=0.0，所以不执行
        img4, labels4, segments4 = copy_paste(img4, labels4, segments4, p=self.hyp['copy_paste'])
        #数据增广
        img4, labels4 = random_perspective(img4, labels4, segments4,
                                           #这些参数从超参的文件中进行获取，而超参文件中，其实可看出来数据增强后处理，只用了translate和scale
                                           degrees=self.hyp['degrees'],#比如degree,即不需要做rotation;
                                           translate=self.hyp['translate'],#比如0.1,即做图像偏移
                                           scale=self.hyp['scale'],#0.5，即img尺度调整，大小缩放
                                           shear=self.hyp['shear'],#0 裁剪
                                           perspective=self.hyp['perspective'],#0
                                           border=self.mosaic_border)  # border to remove

        #返回数据增强后的图片与标签信息
        return img4, labels4

    def load_mosaic9(self, index):
        # YOLOv5 9-mosaic loader. Loads 1 image + 8 random images into a 9-image mosaic
        labels9, segments9 = [], []
        s = self.img_size
        indices = [index] + random.choices(self.indices, k=8)  # 8 additional image indices
        random.shuffle(indices)
        hp, wp = -1, -1  # height, width previous
        for i, index in enumerate(indices):
            # Load image
            img, _, (h, w) = self.load_image(index)

            # place img in img9
            if i == 0:  # center
                img9 = np.full((s * 3, s * 3, img.shape[2]), 114, dtype=np.uint8)  # base image with 4 tiles
                h0, w0 = h, w
                c = s, s, s + w, s + h  # xmin, ymin, xmax, ymax (base) coordinates
            elif i == 1:  # top
                c = s, s - h, s + w, s
            elif i == 2:  # top right
                c = s + wp, s - h, s + wp + w, s
            elif i == 3:  # right
                c = s + w0, s, s + w0 + w, s + h
            elif i == 4:  # bottom right
                c = s + w0, s + hp, s + w0 + w, s + hp + h
            elif i == 5:  # bottom
                c = s + w0 - w, s + h0, s + w0, s + h0 + h
            elif i == 6:  # bottom left
                c = s + w0 - wp - w, s + h0, s + w0 - wp, s + h0 + h
            elif i == 7:  # left
                c = s - w, s + h0 - h, s, s + h0
            elif i == 8:  # top left
                c = s - w, s + h0 - hp - h, s, s + h0 - hp

            padx, pady = c[:2]
            x1, y1, x2, y2 = (max(x, 0) for x in c)  # allocate coords

            # Labels
            labels, segments = self.labels[index].copy(), self.segments[index].copy()
            if labels.size:
                labels[:, 1:] = xywhn2xyxy(labels[:, 1:], w, h, padx, pady)  # normalized xywh to pixel xyxy format
                segments = [xyn2xy(x, w, h, padx, pady) for x in segments]
            labels9.append(labels)
            segments9.extend(segments)

            # Image
            img9[y1:y2, x1:x2] = img[y1 - pady:, x1 - padx:]  # img9[ymin:ymax, xmin:xmax]
            hp, wp = h, w  # height, width previous

        # Offset
        yc, xc = (int(random.uniform(0, s)) for _ in self.mosaic_border)  # mosaic center x, y
        img9 = img9[yc:yc + 2 * s, xc:xc + 2 * s]

        # Concat/clip labels
        labels9 = np.concatenate(labels9, 0)
        labels9[:, [1, 3]] -= xc
        labels9[:, [2, 4]] -= yc
        c = np.array([xc, yc])  # centers
        segments9 = [x - c for x in segments9]

        for x in (labels9[:, 1:], *segments9):
            np.clip(x, 0, 2 * s, out=x)  # clip when using random_perspective()
        # img9, labels9 = replicate(img9, labels9)  # replicate

        # Augment
        img9, labels9 = random_perspective(img9, labels9, segments9,
                                           degrees=self.hyp['degrees'],
                                           translate=self.hyp['translate'],
                                           scale=self.hyp['scale'],
                                           shear=self.hyp['shear'],
                                           perspective=self.hyp['perspective'],
                                           border=self.mosaic_border)  # border to remove

        return img9, labels9

    # 在create_dataloader中生成dataloader时调用
    @staticmethod
    def collate_fn(batch):
        """
               整理函数  将image和label整合到一起
               pytorch的DataLoader打包一个batch的数据集时要经过此函数进行打包 通过重写此函数实现标签与图片对应的划分，
               一个batch中哪些标签属于哪一张图片,形如
                   [[0, 6, 0.5, 0.5, 0.26, 0.35],
                    [0, 6, 0.5, 0.5, 0.26, 0.35],
                    [1, 6, 0.5, 0.5, 0.26, 0.35],
                    [2, 6, 0.5, 0.5, 0.26, 0.35],]
                    图片编号、labels类别编号 xywh
               """
        img, label, path, shapes = zip(*batch)  # transposed
        for i, lb in enumerate(label):
            lb[:, 0] = i  # add target image index for build_targets()
        return torch.stack(img, 0), torch.cat(label, 0), path, shapes

    @staticmethod
    #pytorch的dataloader打包一个batch数据集时进过此函数打包，通过重写此函数实现标签与图片对应的划分
    #一个batch中哪些标签属于第一张图片，属于第二张图片
    def collate_fn4(batch):
        #这个函数会在create_dataloader中生成dataloader时调用：
        #整理函数，将image与labels整合到一起
        img, label, path, shapes = zip(*batch)  # transposed
        n = len(shapes) // 4
        img4, label4, path4, shapes4 = [], [], path[:n], shapes[:n]

        ho = torch.tensor([[0.0, 0, 0, 1, 0, 0]])
        wo = torch.tensor([[0.0, 0, 1, 0, 0, 0]])
        s = torch.tensor([[1, 1, 0.5, 0.5, 0.5, 0.5]])  # scale
        for i in range(n):  # zidane torch.zeros(16,3,720,1280)  # BCHW
            i *= 4
            if random.random() < 0.5:
                im = F.interpolate(img[i].unsqueeze(0).float(), scale_factor=2.0, mode='bilinear', align_corners=False)[
                    0].type(img[i].type())
                lb = label[i]
            else:
                im = torch.cat((torch.cat((img[i], img[i + 1]), 1), torch.cat((img[i + 2], img[i + 3]), 1)), 2)
                lb = torch.cat((label[i], label[i + 1] + ho, label[i + 2] + wo, label[i + 3] + ho + wo), 0) * s
            img4.append(im)
            label4.append(lb)

        for i, lb in enumerate(label4):
            lb[:, 0] = i  # add target image index for build_targets()

        return torch.stack(img4, 0), torch.cat(label4, 0), path4, shapes4


# Ancillary functions --------------------------------------------------------------------------------------------------
def create_folder(path='./new'):
    # Create folder
    if os.path.exists(path):
        shutil.rmtree(path)  # delete output folder
    os.makedirs(path)  # make new output folder


def flatten_recursive(path=DATASETS_DIR / 'coco128'):
    # Flatten a recursive directory by bringing all files to top level
    new_path = Path(str(path) + '_flat')
    create_folder(new_path)
    for file in tqdm(glob.glob(str(Path(path)) + '/**/*.*', recursive=True)):
        shutil.copyfile(file, new_path / Path(file).name)


def extract_boxes(path=DATASETS_DIR / 'coco128'):  # from utils.datasets import *; extract_boxes()
    # Convert detection dataset into classification dataset, with one directory per class
    path = Path(path)  # images dir
    shutil.rmtree(path / 'classifier') if (path / 'classifier').is_dir() else None  # remove existing
    files = list(path.rglob('*.*'))
    n = len(files)  # number of files
    for im_file in tqdm(files, total=n):
        if im_file.suffix[1:] in IMG_FORMATS:
            # image
            im = cv2.imread(str(im_file))[..., ::-1]  # BGR to RGB
            h, w = im.shape[:2]

            # labels
            lb_file = Path(img2label_paths([str(im_file)])[0])
            if Path(lb_file).exists():
                with open(lb_file) as f:
                    lb = np.array([x.split() for x in f.read().strip().splitlines()], dtype=np.float32)  # labels

                for j, x in enumerate(lb):
                    c = int(x[0])  # class
                    f = (path / 'classifier') / f'{c}' / f'{path.stem}_{im_file.stem}_{j}.jpg'  # new filename
                    if not f.parent.is_dir():
                        f.parent.mkdir(parents=True)

                    b = x[1:] * [w, h, w, h]  # box
                    # b[2:] = b[2:].max()  # rectangle to square
                    b[2:] = b[2:] * 1.2 + 3  # pad
                    b = xywh2xyxy(b.reshape(-1, 4)).ravel().astype(np.int)

                    b[[0, 2]] = np.clip(b[[0, 2]], 0, w)  # clip boxes outside of image
                    b[[1, 3]] = np.clip(b[[1, 3]], 0, h)
                    assert cv2.imwrite(str(f), im[b[1]:b[3], b[0]:b[2]]), f'box failure in {f}'


def autosplit(path=DATASETS_DIR / 'coco128/images', weights=(0.9, 0.1, 0.0), annotated_only=False):
    """ Autosplit a dataset into train/val/test splits and save path/autosplit_*.txt files
    Usage: from utils.datasets import *; autosplit()
    Arguments
        path:            Path to images directory
        weights:         Train, val, test weights (list, tuple)
        annotated_only:  Only use images with an annotated txt file
    """
    path = Path(path)  # images dir
    files = sorted(x for x in path.rglob('*.*') if x.suffix[1:].lower() in IMG_FORMATS)  # image files only
    n = len(files)  # number of files
    random.seed(0)  # for reproducibility
    indices = random.choices([0, 1, 2], weights=weights, k=n)  # assign each image to a split

    txt = ['autosplit_train.txt', 'autosplit_val.txt', 'autosplit_test.txt']  # 3 txt files
    [(path.parent / x).unlink(missing_ok=True) for x in txt]  # remove existing

    print(f'Autosplitting images from {path}' + ', using *.txt labeled images only' * annotated_only)
    for i, img in tqdm(zip(indices, files), total=n):
        if not annotated_only or Path(img2label_paths([str(img)])[0]).exists():  # check label
            with open(path.parent / txt[i], 'a') as f:
                f.write('./' + img.relative_to(path.parent).as_posix() + '\n')  # add image to txt file


def verify_image_label(args):
    # Verify one image-label pair
    im_file, lb_file, prefix = args
    nm, nf, ne, nc, msg, segments = 0, 0, 0, 0, '', []  # number (missing, found, empty, corrupt), message, segments
    try:
        # verify images
        im = Image.open(im_file)
        im.verify()  # PIL verify
        shape = exif_size(im)  # image size
        assert (shape[0] > 9) & (shape[1] > 9), f'image size {shape} <10 pixels'
        assert im.format.lower() in IMG_FORMATS, f'invalid image format {im.format}'
        if im.format.lower() in ('jpg', 'jpeg'):
            with open(im_file, 'rb') as f:
                f.seek(-2, 2)
                if f.read() != b'\xff\xd9':  # corrupt JPEG
                    ImageOps.exif_transpose(Image.open(im_file)).save(im_file, 'JPEG', subsampling=0, quality=100)
                    msg = f'{prefix}WARNING: {im_file}: corrupt JPEG restored and saved'

        # verify labels
        if os.path.isfile(lb_file):
            nf = 1  # label found
            with open(lb_file) as f:
                lb = [x.split() for x in f.read().strip().splitlines() if len(x)]
                if any([len(x) > 8 for x in lb]):  # is segment
                    classes = np.array([x[0] for x in lb], dtype=np.float32)
                    segments = [np.array(x[1:], dtype=np.float32).reshape(-1, 2) for x in lb]  # (cls, xy1...)
                    lb = np.concatenate((classes.reshape(-1, 1), segments2boxes(segments)), 1)  # (cls, xywh)
                lb = np.array(lb, dtype=np.float32)
            nl = len(lb)
            if nl:
                assert lb.shape[1] == 5, f'labels require 5 columns, {lb.shape[1]} columns detected'
                assert (lb >= 0).all(), f'negative label values {lb[lb < 0]}'
                assert (lb[:, 1:] <= 1).all(), f'non-normalized or out of bounds coordinates {lb[:, 1:][lb[:, 1:] > 1]}'
                _, i = np.unique(lb, axis=0, return_index=True)
                if len(i) < nl:  # duplicate row check
                    lb = lb[i]  # remove duplicates
                    if segments:
                        segments = segments[i]
                    msg = f'{prefix}WARNING: {im_file}: {nl - len(i)} duplicate labels removed'
            else:
                ne = 1  # label empty
                lb = np.zeros((0, 5), dtype=np.float32)
        else:
            nm = 1  # label missing
            lb = np.zeros((0, 5), dtype=np.float32)
        return im_file, lb, shape, segments, nm, nf, ne, nc, msg
    except Exception as e:
        nc = 1
        msg = f'{prefix}WARNING: {im_file}: ignoring corrupt image/label: {e}'
        return [None, None, None, None, nm, nf, ne, nc, msg]


def dataset_stats(path='coco128.yaml', autodownload=False, verbose=False, profile=False, hub=False):
    """ Return dataset statistics dictionary with images and instances counts per split per class
    To run in parent directory: export PYTHONPATH="$PWD/yolov5"
    Usage1: from utils.datasets import *; dataset_stats('coco128.yaml', autodownload=True)
    Usage2: from utils.datasets import *; dataset_stats('path/to/coco128_with_yaml.zip')
    Arguments
        path:           Path to data.yaml or data.zip (with data.yaml inside data.zip)
        autodownload:   Attempt to download dataset if not found locally
        verbose:        Print stats dictionary
    """

    def round_labels(labels):
        # Update labels to integer class and 6 decimal place floats
        return [[int(c), *(round(x, 4) for x in points)] for c, *points in labels]

    def unzip(path):
        # Unzip data.zip TODO: CONSTRAINT: path/to/abc.zip MUST unzip to 'path/to/abc/'
        if str(path).endswith('.zip'):  # path is data.zip
            assert Path(path).is_file(), f'Error unzipping {path}, file not found'
            ZipFile(path).extractall(path=path.parent)  # unzip
            dir = path.with_suffix('')  # dataset directory == zip name
            return True, str(dir), next(dir.rglob('*.yaml'))  # zipped, data_dir, yaml_path
        else:  # path is data.yaml
            return False, None, path

    def hub_ops(f, max_dim=1920):
        # HUB ops for 1 image 'f': resize and save at reduced quality in /dataset-hub for web/app viewing
        f_new = im_dir / Path(f).name  # dataset-hub image filename
        try:  # use PIL
            im = Image.open(f)
            r = max_dim / max(im.height, im.width)  # ratio
            if r < 1.0:  # image too large
                im = im.resize((int(im.width * r), int(im.height * r)))
            im.save(f_new, 'JPEG', quality=75, optimize=True)  # save
        except Exception as e:  # use OpenCV
            print(f'WARNING: HUB ops PIL failure {f}: {e}')
            im = cv2.imread(f)
            im_height, im_width = im.shape[:2]
            r = max_dim / max(im_height, im_width)  # ratio
            if r < 1.0:  # image too large
                im = cv2.resize(im, (int(im_width * r), int(im_height * r)), interpolation=cv2.INTER_AREA)
            cv2.imwrite(str(f_new), im)

    zipped, data_dir, yaml_path = unzip(Path(path))
    with open(check_yaml(yaml_path), errors='ignore') as f:
        data = yaml.safe_load(f)  # data dict
        if zipped:
            data['path'] = data_dir  # TODO: should this be dir.resolve()?
    check_dataset(data, autodownload)  # download dataset if missing
    hub_dir = Path(data['path'] + ('-hub' if hub else ''))
    stats = {'nc': data['nc'], 'names': data['names']}  # statistics dictionary
    for split in 'train', 'val', 'test':
        if data.get(split) is None:
            stats[split] = None  # i.e. no test set
            continue
        x = []
        dataset = LoadImagesAndLabels(data[split])  # load dataset
        for label in tqdm(dataset.labels, total=dataset.n, desc='Statistics'):
            x.append(np.bincount(label[:, 0].astype(int), minlength=data['nc']))
        x = np.array(x)  # shape(128x80)
        stats[split] = {'instance_stats': {'total': int(x.sum()), 'per_class': x.sum(0).tolist()},
                        'image_stats': {'total': dataset.n, 'unlabelled': int(np.all(x == 0, 1).sum()),
                                        'per_class': (x > 0).sum(0).tolist()},
                        'labels': [{str(Path(k).name): round_labels(v.tolist())} for k, v in
                                   zip(dataset.img_files, dataset.labels)]}

        if hub:
            im_dir = hub_dir / 'images'
            im_dir.mkdir(parents=True, exist_ok=True)
            for _ in tqdm(ThreadPool(NUM_THREADS).imap(hub_ops, dataset.img_files), total=dataset.n, desc='HUB Ops'):
                pass

    # Profile
    stats_path = hub_dir / 'stats.json'
    if profile:
        for _ in range(1):
            file = stats_path.with_suffix('.npy')
            t1 = time.time()
            np.save(file, stats)
            t2 = time.time()
            x = np.load(file, allow_pickle=True)
            print(f'stats.npy times: {time.time() - t2:.3f}s read, {t2 - t1:.3f}s write')

            file = stats_path.with_suffix('.json')
            t1 = time.time()
            with open(file, 'w') as f:
                json.dump(stats, f)  # save stats *.json
            t2 = time.time()
            with open(file) as f:
                x = json.load(f)  # load hyps dict
            print(f'stats.json times: {time.time() - t2:.3f}s read, {t2 - t1:.3f}s write')

    # Save, print and return
    if hub:
        print(f'Saving {stats_path.resolve()}...')
        with open(stats_path, 'w') as f:
            json.dump(stats, f)  # save stats.json
    if verbose:
        print(json.dumps(stats, indent=2, sort_keys=False))
    return stats
